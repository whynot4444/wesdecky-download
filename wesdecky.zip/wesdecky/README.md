# Wesdecky by Weirdstore.vn – plugin Decky Loader

**Tải về:** <https://github.com/whynot4444/wesdecky-download/releases/latest> (repo public, chỉ có file `wesdecky.zip`). Repo này là mã nguồn, để private.

Một plugin gộp 3 công cụ cho SteamOS, mỗi công cụ là một tab trong menu Quick Access (`...` → Decky → **Wesdecky**):

| Tab | Làm gì |
|---|---|
| **Việt hóa** | Tìm, tải, cài và gỡ bản Việt hóa cho game Steam |
| **eGPU** | Cho game chạy bằng eGPU khi đang cắm, tự về GPU trong máy khi rút |
| **DNS** | Đổi DNS cho Wi-Fi/Ethernet (Cloudflare, Google, hoặc bộ DNS tự lưu) |

Plugin chạy bằng quyền root (eGPU cần ghi `/sys`, DNS cần `nmcli`). Phần Việt hóa vẫn ghi file với chủ là người dùng `deck`, để Steam cập nhật và xác minh game bình thường. Trình cài `.exe` chạy qua Proton cũng chạy bằng user `deck`.

### Chuyển từ plugin cũ (All in 1 hoặc 3 plugin riêng lẻ)

Wesdecky là tên mới của plugin "All in 1 by Weirdstore.vn". Dữ liệu của bản All in 1 (sao lưu Việt hóa, bộ DNS) được tự chuyển sang giống như dưới đây; sau đó gỡ plugin All in 1.

1. Cài `wesdecky.zip`, mở plugin một lần. Plugin tự chuyển sang:
   - sao lưu Việt hóa (để vẫn gỡ được bản đã cài) và danh sách nguồn từ `~/homebrew/data/viet-hoa/`;
   - các bộ DNS đã lưu từ plugin DNS Changer cũ.
   eGPU Switcher dùng chung wrapper và cấu hình trong `~/.config/egpu-switcher/`, game đã gắn không cần gắn lại.
2. Sau đó gỡ 3 plugin cũ (Viet Hoa, eGPU Switcher, DNS Changer by Weirdstore.vn). Gỡ DNS Changer cũ sẽ trả DNS về mặc định, nên chọn lại DNS ở tab **DNS** sau khi gỡ.

## Tab Việt hóa

- Tự đọc thư viện Steam (kể cả thẻ nhớ), chọn sẵn game đang chạy.
- **Nhiều nguồn**: The Red Team, Cánh Cụt Team, Phù Sa Team, các trang bạn tự thêm, và tìm trên web (DuckDuckGo/Bing). Kết quả từ trang lạ được đánh dấu ⚠ và **chỉ được tải về, không tự cài**, vì file từ trang lạ có thể chứa virus. Có thể bật/tắt từng nguồn ở mục *Nguồn tìm Việt hóa*.
- **Tải & cài thẳng vào game**: chọn game là plugin tự tìm bản Việt hóa, bấm một nút là plugin tải, giải nén rồi cài vào đúng game:
  - Bản Việt hóa dạng file (zip/7z/rar): chép đè vào thư mục game, **sao lưu file gốc**.
  - Bản Việt hóa dạng trình cài `.exe`/`.msi`: Steam chạy trình cài bằng **đúng Proton và prefix của game**, nên cửa sổ hiện ngay trong Game Mode, không cần Desktop Mode. Plugin tạm đổi Launch Options của game và tự trả lại như cũ ngay sau khi trình cài mở. Wrapper chỉ chạy một lần: lần bật game sau là game bình thường.
- **Kho chung**: bản lưu các bản Việt hóa miễn phí trên Google Drive, có danh sách `index.json` trên GitHub. Plugin tra theo AppID của Steam, kiểm tra mã SHA-256, và ghi nguồn là nhóm dịch gốc. Link gốc của nhóm luôn được thử trước, kho chung chỉ dùng khi link gốc lỗi. Mẫu repo kho chung nằm ở `mirror-template/`.
- **Tự chọn link tải được**: nút *Tải & cài (tự chọn link tải được)* thử lần lượt mọi link của các nhóm dịch, theo thứ tự link trực tiếp → MediaFire → Google Drive → Launcher, rồi tải link đầu tiên tải được. File crack/bypass bị bỏ qua.
- **Google Drive khóa file** vì quá nhiều người tải: plugin tự thử lại mỗi 30 phút, tối đa 2 ngày. Bạn cũng có thể tải bằng trình duyệt: file trong `~/Downloads` hiện ở mục *Bản Việt hóa trong máy*, bấm một nút là cài.
- Hỗ trợ Google Drive, MediaFire và link file trực tiếp. Tự thử mật khẩu quen thuộc (`Theredteam.vn`, `Canhcutteam`…) hoặc dùng mật khẩu bạn nhập.
- Lần đầu gặp file `.7z`/`.rar` có mật khẩu, plugin tự tải 7-Zip (7zz) về dùng.
- **Gỡ Việt hóa**: trả lại file gốc, xóa file đã thêm. Giống launcher của Cánh Cụt, plugin ghi dấu từng file đã chép: file nào game đã tự cập nhật sau đó (Steam update) thì được giữ nguyên, không chép bản sao lưu cũ đè lên. Plugin cũng báo khi game đã được cập nhật sau lúc cài Việt hóa.
- **Ghi nguồn**: mỗi bản Việt hóa đã tải đều lưu tên nhóm dịch và trang gốc, rồi hiện "Nguồn: …" ở game đã cài.
- Sửa lỗi tên file tiếng Việt bị hỏng font trong file zip tạo trên Windows.

Không hỗ trợ tải trực tiếp: Fshare (cần tài khoản) và thư mục Google Drive. Hãy tải bằng trình duyệt rồi chép vào `~/VietHoa`. Plugin vẫn cài thẳng được từ đó.

## Tab eGPU

- Không đổi GPU cho toàn hệ thống (dễ gây màn hình đen). Mỗi game được gắn wrapper qua Launch Options: `~/.local/share/egpu-switcher/egpu-run %command%`. Tham số cũ được giữ nguyên.
- Mỗi lần mở game, wrapper tìm eGPU (GPU có driver và không phải `boot_vga`). Có eGPU thì đặt `DRI_PRIME` và `MESA_VK_DEVICE_SELECT` (thêm biến NVIDIA PRIME nếu dùng driver `nvidia`). Không có thì chạy game như thường.
- Tab gồm: danh sách GPU, nút **Quét lại eGPU (hotplug)** (cấp quyền Thunderbolt/USB4 rồi quét lại bus PCI), công tắc **Dùng eGPU khi có kết nối**, chọn eGPU ưu tiên, **Chế độ nghiêm ngặt** (ẩn hẳn GPU trong máy khỏi Vulkan), gắn/gỡ theo từng game hoặc tất cả game, và log lần chạy gần nhất.
- Cấu hình: `~/.config/egpu-switcher/env`. Log: `~/.cache/egpu-switcher/last-launch.log`.
- Giới hạn: hình vẫn xuất qua gamescope trên GPU trong máy. Steam Deck không có USB4 (cần adapter M.2/OCuLink). SteamOS gốc không có driver NVIDIA độc quyền. Game có anti-cheat/launcher riêng có thể bỏ qua biến môi trường.

## Tab DNS

- Hiện kết nối và DNS đang dùng, đánh dấu ✓ bộ đang áp dụng.
- 2 nút có sẵn: **Cloudflare (1.1.1.1)** và **Google (8.8.8.8)**, cả IPv4 và IPv6 (nhà mạng VN chặn Steam qua DNS, 2 bộ này vượt được).
- **Bộ DNS tuỳ chỉnh**: nhập tên + địa chỉ → Lưu, mỗi bộ thành một nút, có ✕ để xoá.
- **Mặc định** trả về DNS của router/nhà mạng. Gỡ plugin cũng tự trả về mặc định.
- Cách đổi (thử lần lượt): `nmcli connection modify` (IPv4+IPv6, lưu theo từng mạng) → chỉ IPv4 → `nmcli device modify` (tạm thời) → `resolvectl dns` (tạm thời). Khi đổi tạm thời, chọn lại DNS sau khi Wi-Fi kết nối lại.

## Ghi công và bản quyền

Plugin chỉ dùng cho **game bạn đã mua trên Steam**, và chỉ tải/cài bản Việt hóa: link crack, bypass hoặc emulator trên trang nhóm dịch đều bị bỏ qua.

Plugin **không chứa và không phân phối lại** bản dịch nào. Mọi bản Việt hóa thuộc về nhóm dịch, plugin chỉ tải từ trang và link chính thức họ đăng. Hãy ủng hộ các nhóm:

- The Red Team: <https://theredteam.vn>
- Cánh Cụt Team: <https://canhcutteam.com>
- Phù Sa Team: <https://phusa.team>

## Test

Mỗi lần push, GitHub Actions chạy 3 nhóm test, không cần Steam Deck:

- **Backend** (`tests/py`): thư viện Steam, `/sys` và `nmcli` giả lập; đổi chủ file khi chạy root; chuyển dữ liệu plugin cũ; giải nén có mật khẩu, áp dụng/gỡ, sao lưu, đọc Launch Options, chạy thử script trình cài với Proton giả.
- **Giao diện** (`tests/frontend`): Steam và Decky giả lập, bấm thử như người dùng (chuyển tab, gắn eGPU, đổi DNS, chọn game, tải & cài, chạy trình cài qua Steam, trả lại Launch Options).
- **Web thật** (`tests/py/test_live_sites.py`, `LIVE=1`): tìm trên The Red Team và Cánh Cụt Team, mở link Google Drive thật. Nếu web nhóm dịch đổi giao diện thì nhóm test này báo lỗi, nhưng không chặn bản build.

Chạy tại máy: `python -m pytest tests/py` và `npm test`.

## Build

Cần Node.js 18+:

```bash
bash build.sh        # tạo wesdecky.zip
```

Hoặc đẩy thư mục này lên GitHub, workflow *Build plugin* sẽ tạo `wesdecky.zip` trong mục Artifacts, và cập nhật bản phát hành `latest`.

## Cài lên Steam Deck

1. Đã cài [Decky Loader](https://decky.xyz).
2. Decky → Cài đặt (bánh răng) → **General** → bật **Developer mode**.
3. Tab **Developer** → **Install Plugin from ZIP** → chọn `wesdecky.zip`.
   Hoặc trong Desktop Mode: giải nén để có `~/homebrew/plugins/wesdecky/`, rồi khởi động lại Deck.

## Cách dùng tab Việt hóa

1. Bấm `...` → biểu tượng Decky → **Wesdecky** → tab **Việt hóa** → chọn game.
2. Bấm **Tìm Việt hóa cho …** → chọn kết quả → bấm **Tải & cài: …**.
   Hoặc chép file vào `/home/deck/VietHoa`, chọn nó rồi bấm **Áp dụng Việt hóa** / **Chạy trình cài vào game**.
3. Muốn về bản gốc: **Gỡ Việt hóa**.

### Lưu ý với trình cài `.exe`

- Phải thoát game trước khi cài.
- Khi trình cài hỏi thư mục game, chọn đường dẫn plugin hiển thị, dạng `Z:\home\deck\.local\share\Steam\steamapps\common\<Game>`.
- Bản cài bằng `.exe` không thể gỡ bằng nút *Gỡ Việt hóa*. Hãy dùng *Thuộc tính → Tệp đã cài đặt → Xác minh tính toàn vẹn* trong Steam.
- Cánh Cụt Team phát hành qua Launcher (ứng dụng Windows). Gói Việt hóa của nhóm được mã hóa, và chỉ Launcher (đã đăng nhập tài khoản có quyền) mới lấy được khóa từ máy chủ của nhóm, nên plugin chỉ tải và chạy Launcher chính thức trong prefix của game. Launcher cần WebView2, có thể không chạy được qua Proton. Khi đó hãy dùng Desktop Mode.

## Nhật ký lỗi

- Nhật ký plugin: `~/homebrew/logs/wesdecky/`
- Trình cài chạy qua Steam: `~/homebrew/data/wesdecky/installer.log`
- Trình cài chạy ngoài Steam: `~/homebrew/data/wesdecky/exe.log`

## Các thư mục plugin dùng (trên Steam Deck, người dùng `deck`)

| Thư mục | Dùng để |
|---|---|
| `~/homebrew/plugins/wesdecky/` | Code plugin (Decky giải nén zip vào đây) |
| `~/homebrew/data/wesdecky/` | Việt hóa: sao lưu file gốc (`backups/`), cài đặt nguồn, script chạy trình cài, 7-Zip tự tải |
| `~/homebrew/settings/wesdecky/dns.json` | DNS: bộ DNS tự lưu |
| `~/.config/egpu-switcher/`, `~/.local/share/egpu-switcher/` | eGPU: cấu hình và wrapper |
| `~/VietHoa/` | Bản Việt hóa đã tải hoặc bạn tự chép vào |
| `~/Downloads/` | Plugin chỉ đọc: liệt kê file tải bằng trình duyệt |
| `~/.local/share/Steam/` và thẻ nhớ | Thư viện game, đọc từ `steamapps/libraryfolders.vdf` |

`~` là `/home/deck`.
