"""
Wesdecky (by Weirdstore.vn) - Decky Loader plugin backend.

Gồm 3 phần: Việt hóa (file này), eGPU Switcher (py_modules/egpu.py) và
DNS Changer (py_modules/dns_changer.py). Plugin chạy bằng root vì eGPU và DNS cần,
nên phần Việt hóa đổi chủ mọi file nó tạo về người dùng (py_modules/userown.py).

Phần Việt hóa:

Đặt bản Việt hóa vào ~/VietHoa (file .zip/.7z/.rar, thư mục, hoặc .exe),
chọn game trong menu Quick Access, bấm Áp dụng. Plugin sao lưu mọi file
bị ghi đè để có thể gỡ Việt hóa và trả game về nguyên trạng.
"""
import asyncio
import glob
import json
import os
import re
import shutil
import stat
import subprocess
import tempfile
import time
import urllib.parse
import zipfile

import decky

import placement
import sources
import userown
from dns_changer import DnsMixin
from egpu import EgpuMixin
from nonsteam import NonSteamMixin

from downloader import NOT_TRANSLATION, JOB, start_download_best, search_sources, find_links, start_download, get_7z, KNOWN_PASSWORDS

PATCH_EXTS = {".zip", ".7z", ".rar", ".exe", ".msi"}
SOURCE_FILE = ".viethoa-source.json"
SKIP_APPS = re.compile(
    r"^(Proton|Steam Linux Runtime|Steamworks Common|SteamVR|Steam Audio)", re.I
)


# ----------------------------------------------------------------- paths ---
def _home() -> str:
    return decky.DECKY_USER_HOME


def patch_dir() -> str:
    return os.path.join(_home(), "VietHoa")


def backup_root() -> str:
    return os.path.join(decky.DECKY_PLUGIN_RUNTIME_DIR, "backups")


def _clean_env() -> dict:
    """Env sạch cho tiến trình con (Decky gắn LD_LIBRARY_PATH riêng, làm hỏng binary hệ thống)."""
    env = dict(os.environ)
    for k in ("LD_LIBRARY_PATH", "LD_PRELOAD", "PYTHONHOME", "PYTHONPATH"):
        env.pop(k, None)
    env["HOME"] = _home()
    return env


# ----------------------------------------------------------- steam scan ---
def steam_root():
    for p in (
        os.path.join(_home(), ".local/share/Steam"),
        os.path.join(_home(), ".steam/steam"),
        os.path.join(_home(), ".steam/root"),
    ):
        if os.path.isdir(os.path.join(p, "steamapps")):
            return os.path.realpath(p)
    return None


def library_paths() -> list:
    root = steam_root()
    if not root:
        return []
    found = [root]
    vdf = os.path.join(root, "steamapps", "libraryfolders.vdf")
    try:
        with open(vdf, encoding="utf-8", errors="ignore") as f:
            for m in re.finditer(r'"path"\s+"([^"]+)"', f.read()):
                found.append(m.group(1).replace("\\\\", "\\"))
    except OSError:
        pass
    out, seen = [], set()
    for p in found:
        rp = os.path.realpath(p)
        if rp not in seen and os.path.isdir(os.path.join(rp, "steamapps")):
            seen.add(rp)
            out.append(rp)
    return out


def _acf_value(text: str, key: str):
    m = re.search(r'"%s"\s+"([^"]*)"' % key, text)
    return m.group(1) if m else None


def scan_games() -> list:
    games = {}
    for lib in library_paths():
        sa = os.path.join(lib, "steamapps")
        try:
            entries = os.listdir(sa)
        except OSError:
            continue
        for fn in entries:
            if not (fn.startswith("appmanifest_") and fn.endswith(".acf")):
                continue
            try:
                with open(os.path.join(sa, fn), encoding="utf-8", errors="ignore") as f:
                    text = f.read()
            except OSError:
                continue
            appid = _acf_value(text, "appid")
            name = _acf_value(text, "name") or appid
            installdir = _acf_value(text, "installdir")
            if not appid or not installdir or SKIP_APPS.match(name or ""):
                continue
            path = os.path.join(sa, "common", installdir)
            if os.path.isdir(path):
                games[appid] = {"appid": appid, "name": name, "path": path, "library": lib,
                                "buildid": _acf_value(text, "buildid") or ""}
    return sorted(games.values(), key=lambda g: g["name"].lower())


def find_game(appid: str) -> dict:
    for g in scan_games():
        if g["appid"] == str(appid):
            return g
    raise RuntimeError(f"Không tìm thấy game có AppID {appid}")


def list_patches() -> list:
    d = patch_dir()
    if not os.path.isdir(d):
        os.makedirs(d, exist_ok=True)
        userown.own(d)
    out = []
    for fn in sorted(os.listdir(d), key=str.lower):
        if fn.startswith(".") or fn.lower().startswith("doc-toi") or fn.startswith("viethoa_dl_"):
            continue
        full = os.path.join(d, fn)
        ext = os.path.splitext(fn)[1].lower()
        if os.path.isdir(full):
            if not fn.startswith("_"):
                out.append({"name": fn, "kind": "folder"})
            for dp, dns, fns in os.walk(full):
                dns[:] = [x for x in dns if not x.startswith(".")]
                if dp.count(os.sep) - full.count(os.sep) >= 3:
                    dns[:] = []
                for f in sorted(fns, key=str.lower):
                    if f.lower().endswith((".exe", ".msi")) and not re.search(r"unins|vc_?redist|dxsetup|dotnet", f, re.I):
                        out.append({"name": os.path.relpath(os.path.join(dp, f), d), "kind": "exe"})
        elif ext in PATCH_EXTS:
            out.append({"name": fn, "kind": "exe" if ext in (".exe", ".msi") else "archive",
                        "size": os.path.getsize(full)})
    return out


def _patch_path(name: str) -> str:
    base = os.path.realpath(patch_dir())
    p = os.path.realpath(os.path.join(base, name))
    if not p.startswith(base + os.sep) or not os.path.exists(p):
        raise RuntimeError(f"Không thấy bản Việt hóa: {name}")
    return p


# ------------------------------------------------------------ extracting ---
def _safe_join(root: str, rel: str) -> str:
    rel = rel.replace("\\", "/").lstrip("/")
    target = os.path.normpath(os.path.join(root, rel))
    if os.path.commonpath([os.path.realpath(root), os.path.realpath(target)]) != os.path.realpath(root):
        raise RuntimeError(f"Đường dẫn không hợp lệ trong file nén: {rel}")
    return target


def _zip_name(info: zipfile.ZipInfo) -> str:
    """Sửa tên file tiếng Việt bị lỗi font trong zip tạo từ Windows."""
    name = info.filename
    if info.flag_bits & 0x800:
        return name
    try:
        raw = name.encode("cp437")
    except UnicodeEncodeError:
        return name
    for enc in ("utf-8", "cp1258"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return name


def _zip_extract(src: str, dest: str, pwd):
    with zipfile.ZipFile(src) as zf:
        for info in zf.infolist():
            name = _zip_name(info).replace("\\", "/")
            target = _safe_join(dest, name)
            if info.is_dir() or name.endswith("/"):
                os.makedirs(target, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with zf.open(info, pwd=pwd.encode() if pwd else None) as s, open(target, "wb") as d:
                shutil.copyfileobj(s, d)


def _clear(d: str):
    for n in os.listdir(d):
        p = os.path.join(d, n)
        shutil.rmtree(p, ignore_errors=True) if os.path.isdir(p) and not os.path.islink(p) else os.remove(p)


def _extract(src: str, dest: str, password: str = "") -> str:
    """Giải nén src vào dest, tự thử các mật khẩu quen thuộc (Theredteam.vn, Canhcutteam...)."""
    if os.path.isdir(src):
        return src
    ext = os.path.splitext(src)[1].lower()
    if ext not in (".zip", ".7z", ".rar"):
        raise RuntimeError(f"Không hỗ trợ định dạng {ext}")
    pwds = []
    for p in [password, ""] + KNOWN_PASSWORDS:
        if p is not None and p not in pwds:
            pwds.append(p)

    if ext == ".zip":
        for p in pwds:
            try:
                _zip_extract(src, dest, p)
                return dest
            except NotImplementedError:
                _clear(dest)
                break  # zip mã hóa AES -> dùng 7-Zip
            except (RuntimeError, zipfile.BadZipFile) as e:
                _clear(dest)
                if "password" not in str(e).lower() and "encrypted" not in str(e).lower():
                    raise RuntimeError(f"File zip lỗi: {e}")

    tool = get_7z()
    if not tool:
        raise RuntimeError("Không có 7-Zip và không tải được. Kiểm tra mạng rồi thử lại.")
    last = ""
    for p in pwds:
        r = subprocess.run([tool, "x", "-y", f"-p{p}", f"-o{dest}", src],
                           env=_clean_env(), capture_output=True, text=True)
        if r.returncode == 0:
            return dest
        last = (r.stderr or r.stdout)[-300:]
        _clear(dest)
        if "password" not in last.lower() and "encrypted" not in last.lower():
            break
    if "password" in last.lower():
        raise RuntimeError("Sai mật khẩu giải nén. Nhập mật khẩu ở ô 'Mật khẩu' rồi thử lại.")
    raise RuntimeError("Giải nén thất bại: " + last)


def _source_name(url: str) -> str:
    host = urllib.parse.urlparse(url or "").netloc.lower()
    if "theredteam" in host:
        return "The Red Team"
    if "canhcut" in host:
        return "Cánh Cụt Team"
    return host.replace("www.", "") or "Không rõ"


def read_source(patch: str):
    """Nguồn (nhóm dịch + trang) của một bản Việt hóa đã tải, nếu có."""
    try:
        top = patch.replace("\\", "/").split("/", 1)[0]
        with open(os.path.join(patch_dir(), top, SOURCE_FILE), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def save_to_library(path: str, password: str = "", page: str = "", file_url: str = "", mirror_info=None) -> str:
    """Đưa file vừa tải vào ~/VietHoa/<tên>/ (giải nén nếu là file nén) và ghi lại nguồn."""
    base = os.path.basename(path)
    stem = os.path.splitext(base)[0]
    dest = os.path.join(patch_dir(), stem)
    i = 2
    while os.path.exists(dest):
        dest = os.path.join(patch_dir(), f"{stem} ({i})")
        i += 1
    os.makedirs(dest)
    try:
        if base.lower().endswith((".zip", ".7z", ".rar")):
            _extract(path, dest, password)
            os.remove(path)
        else:
            shutil.move(path, os.path.join(dest, base))
    except Exception:
        shutil.rmtree(dest, ignore_errors=True)
        raise
    info = {"team": _source_name(page or file_url), "page": page, "file": file_url, "time": int(time.time())}
    if mirror_info:  # bản lưu trong kho chung: ghi nguồn là nhóm dịch và trang gốc
        info.update(team=mirror_info["team"], page=mirror_info["source"], via="mirror",
                    version=mirror_info.get("version", ""))
        if mirror_info.get("target") is not None:
            info["target"] = mirror_info["target"]
    with open(os.path.join(dest, SOURCE_FILE), "w", encoding="utf-8") as f:
        json.dump(info, f, ensure_ascii=False, indent=1)
    userown.own_tree(dest)
    return os.path.basename(dest)


# ---------------------------------------------------------------- backup ---
def _manifest_path(appid: str) -> str:
    return os.path.join(backup_root(), str(appid), "manifest.json")


def load_manifest(appid: str):
    try:
        with open(_manifest_path(appid), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _save_manifest(appid: str, man: dict):
    p = _manifest_path(appid)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(man, f, ensure_ascii=False, indent=1)


# --------------------------------------------------------------- actions ---
def _stamp(path: str) -> list:
    """Dấu vết của file sau khi chép (kích thước, thời gian sửa) để biết game có ghi đè nó sau này không."""
    st = os.stat(path)
    return [st.st_size, st.st_mtime_ns]


def _make_writable(path: str):
    """Như launcher của Cánh Cụt: bỏ thuộc tính chỉ-đọc trước khi ghi đè."""
    if os.path.exists(path) and not os.access(path, os.W_OK):
        os.chmod(path, os.stat(path).st_mode | stat.S_IWUSR)


def _with_patch_root(patch: str, password: str, fn):
    """Giải nén (nếu cần) rồi gọi fn(thư mục gốc của bản Việt hóa)."""
    src = _patch_path(patch)
    if src.lower().endswith((".exe", ".msi")):
        raise RuntimeError("File .exe phải dùng nút 'Chạy trình cài vào game'")
    if os.path.isdir(src):
        return fn(src)
    tmp = tempfile.mkdtemp(prefix="viethoa_")
    try:
        return fn(_extract(src, tmp, password))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def preview_patch(appid: str, patch: str, strip: bool = True, password: str = "", target=None) -> dict:
    """Cho xem trước bản Việt hóa sẽ được chép vào đâu trong game."""
    game = find_game(appid)
    return _with_patch_root(patch, password,
                            lambda root: placement.summary(placement.plan(root, game["path"], strip, target)))


def do_apply(appid: str, patch: str, strip: bool, password: str = "", target=None,
             require_confident: bool = False) -> dict:
    game = find_game(appid)
    gpath = game["path"]

    def apply(root):
        p = placement.plan(root, gpath, strip, target)
        if require_confident and not p["confident"]:
            return {"needs_confirm": True, **placement.summary(p)}
        man = load_manifest(appid) or {"game": game["name"], "replaced": [], "added": [], "patches": []}
        man.setdefault("stamps", {})
        known = set(man["replaced"]) | set(man["added"])
        bdir = os.path.join(backup_root(), str(appid), "files")
        copied = 0
        try:
            for src_rel, dst_rel in p["files"]:
                rel = dst_rel.replace("/", os.sep)
                dst = _safe_join(gpath, rel)
                if os.path.isdir(dst):
                    raise RuntimeError(f"Xung đột: {dst_rel} là thư mục trong game")
                if rel not in known:
                    if os.path.lexists(dst):
                        bk = os.path.join(bdir, rel)
                        os.makedirs(os.path.dirname(bk), exist_ok=True)
                        shutil.copy2(dst, bk)
                        man["replaced"].append(rel)
                    else:
                        man["added"].append(rel)
                    known.add(rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                _make_writable(dst)
                shutil.copy2(os.path.join(root, src_rel.replace("/", os.sep)), dst)
                userown.own_with_parents(dst, gpath)  # file mới phải thuộc user để Steam cập nhật được game
                man["stamps"][rel] = _stamp(dst)
                copied += 1
        finally:
            if copied:
                man["patches"].append({"name": patch, "time": int(time.time()), "files": copied,
                                       "mode": "files", "source": read_source(patch), "target": p["target"],
                                       "buildid": game.get("buildid", "")})
                _save_manifest(appid, man)
        decky.logger.info(f"Applied {patch} to {game['name']}: {copied} files -> /{p['target']} ({p['reason']})")
        return {"files": copied, "replaced": len(man["replaced"]), "added": len(man["added"]),
                "matched": p["matched"], "new": p["new"], "target": p["target"], "skipped": p["skipped"][:10],
                "reason": p["reason"]}

    return _with_patch_root(patch, password, apply)


def _changed_since_install(man: dict, rel: str, dst: str) -> bool:
    """File đã bị game/Steam ghi lại sau khi cài Việt hóa (ví dụ game cập nhật)?"""
    stamp = man.get("stamps", {}).get(rel)
    if not stamp or not os.path.exists(dst):
        return False
    return _stamp(dst) != list(stamp)


def do_restore(appid: str) -> dict:
    game = find_game(appid)
    man = load_manifest(appid)
    if not man:
        raise RuntimeError("Game này chưa có bản sao lưu nào")
    gpath = game["path"]
    bdir = os.path.join(backup_root(), str(appid), "files")
    kept = []
    for rel in man["replaced"]:
        bk = os.path.join(bdir, rel)
        dst = _safe_join(gpath, rel)
        if _changed_since_install(man, rel, dst):
            kept.append(rel)  # game đã cập nhật file này: giữ bản mới, không chép bản sao lưu cũ đè lên
            continue
        if os.path.exists(bk):
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            _make_writable(dst)
            shutil.copy2(bk, dst)
            userown.own_with_parents(dst, gpath)
    for rel in man["added"]:
        dst = _safe_join(gpath, rel)
        if _changed_since_install(man, rel, dst):
            kept.append(rel)
            continue
        if os.path.isfile(dst) or os.path.islink(dst):
            os.remove(dst)
        d = os.path.dirname(dst)
        while d.startswith(gpath + os.sep):
            try:
                os.rmdir(d)  # chỉ xóa thư mục rỗng
            except OSError:
                break
            d = os.path.dirname(d)
    shutil.rmtree(os.path.join(backup_root(), str(appid)), ignore_errors=True)
    decky.logger.info(f"Restored {game['name']} (giữ {len(kept)} file game đã cập nhật)")
    return {"replaced": len(man["replaced"]), "added": len(man["added"]), "kept": kept[:20],
            "installer": any(p.get("mode") == "installer" for p in man["patches"])}


def backup_info(appid: str):
    """Thông tin bản đã cài, kèm cờ game đã được Steam cập nhật sau khi cài Việt hóa."""
    man = load_manifest(appid)
    if not man:
        return None
    try:
        build = find_game(appid).get("buildid", "")
    except RuntimeError:
        build = ""
    builds = {p.get("buildid") for p in man["patches"] if p.get("buildid")}
    man = {k: v for k, v in man.items() if k != "stamps"}
    man["game_updated"] = bool(build and builds and build not in builds)
    return man


def _find_proton():
    cands = []
    root = steam_root()
    tool_dirs = [os.path.join(lib, "steamapps", "common") for lib in library_paths()]
    tool_dirs += [os.path.join(_home(), ".steam/root/compatibilitytools.d")]
    if root:
        tool_dirs.append(os.path.join(root, "compatibilitytools.d"))
    for d in tool_dirs:
        try:
            for n in os.listdir(d):
                if "proton" in n.lower() and os.path.isfile(os.path.join(d, n, "proton")):
                    cands.append(os.path.join(d, n))
        except OSError:
            pass
    if not cands:
        raise RuntimeError("Không tìm thấy Proton nào đã cài")

    def score(p):
        n = os.path.basename(p)
        if n == "Proton - Experimental":
            return (2, [])
        nums = [int(x) for x in re.findall(r"\d+", n)]
        return (1 if n.startswith("Proton") else 0, nums)

    return max(cands, key=score)


def do_run_exe(appid: str, patch: str) -> dict:
    game = find_game(appid)
    src = _patch_path(patch)
    compat = os.path.join(game["library"], "steamapps", "compatdata", str(appid))
    if not os.path.isdir(os.path.join(compat, "pfx")):
        raise RuntimeError("Game chưa có prefix Proton. Hãy chạy game 1 lần bằng Proton trước.")
    proton = _find_proton()
    env = _clean_env()
    env.update({
        "STEAM_COMPAT_DATA_PATH": compat,
        "STEAM_COMPAT_CLIENT_INSTALL_PATH": steam_root() or "",
        "SteamAppId": str(appid),
        "SteamGameId": str(appid),
    })
    env.setdefault("DISPLAY", ":0")
    env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{userown.user_uid()}")
    log = open(os.path.join(decky.DECKY_PLUGIN_RUNTIME_DIR, "exe.log"), "ab")
    subprocess.Popen(
        [os.path.join(proton, "proton"), "run"]
        + (["msiexec", "/i", src] if src.lower().endswith(".msi") else [src]),
        cwd=os.path.dirname(src), env=env, stdout=log, stderr=log, start_new_session=True,
        **userown.as_user_kwargs(),  # Proton phải chạy bằng user, không được ghi vào prefix bằng root
    )
    wine_path = "Z:" + game["path"].replace("/", "\\")
    decky.logger.info(f"Launched {patch} via {proton}")
    return {"proton": os.path.basename(proton), "wine_path": wine_path}


# ------------------------------------------------ cài thẳng qua Steam ---
INSTALLER_HINT = re.compile(r"setup|install|cai|viet|patch|vh|trt|launcher", re.I)


def _find_exes(folder: str) -> list:
    out = []
    for dp, dns, fns in os.walk(folder):
        if dp.count(os.sep) - folder.count(os.sep) >= 3:
            dns[:] = []
        for f in fns:
            if f.lower().endswith((".exe", ".msi")) and not re.search(r"unins|vc_?redist|dxsetup|dotnet", f, re.I):
                out.append(os.path.join(dp, f))
    return out


def analyze_patch(appid: str, patch: str) -> dict:
    """Đoán bản Việt hóa là bộ file chép đè hay là trình cài đặt."""
    game = find_game(appid)
    src = _patch_path(patch)
    if src.lower().endswith((".exe", ".msi")):
        return {"mode": "installer", "exe": patch}
    if not os.path.isdir(src):
        return {"mode": "files"}
    try:
        p = placement.plan(src, game["path"])
        confident = p["confident"]
    except RuntimeError:
        confident = False
    exes = _find_exes(src)
    if not confident and exes:
        exes.sort(key=lambda p: (not INSTALLER_HINT.search(os.path.basename(p)), p.count(os.sep), len(p)))
        return {"mode": "installer", "exe": os.path.relpath(exes[0], patch_dir())}
    return {"mode": "files"}


def _script_path() -> str:
    return os.path.join(decky.DECKY_PLUGIN_RUNTIME_DIR, "run-installer.sh")


def _pending_exe() -> str:
    return os.path.join(decky.DECKY_PLUGIN_RUNTIME_DIR, "pending-exe")


def _pending_restore() -> str:
    return os.path.join(decky.DECKY_PLUGIN_RUNTIME_DIR, "pending-restore.json")


def _write_script():
    rt = decky.DECKY_PLUGIN_RUNTIME_DIR
    script = f"""#!/bin/bash
# Viet Hoa: Steam gọi script này thay cho game (qua Launch Options) để chạy trình cài
# Việt hóa bằng đúng Proton + prefix của game. Chỉ chạy 1 lần, sau đó tự chạy game bình thường.
PENDING={shlex_quote(_pending_exe())}
LOG={shlex_quote(os.path.join(rt, "installer.log"))}
EXE="$(cat "$PENDING" 2>/dev/null)"
rm -f "$PENDING"
if [ -z "$EXE" ] || [ ! -f "$EXE" ]; then exec "$@"; fi
args=("$@"); idx=-1
for i in "${{!args[@]}}"; do
  a="${{args[$i],,}}"
  case "$a" in *.exe) idx=$i ;; esac
done
if [ "$idx" -lt 0 ]; then
  echo "$(date) Khong tim thay file .exe cua game trong lenh: $*" >> "$LOG"
  exec "$@"
fi
case "${{EXE,,}}" in
  *.msi) args=("${{args[@]:0:$idx}}" msiexec /i "$EXE" "${{args[@]:$((idx+1))}}") ;;
  *)     args=("${{args[@]:0:$idx}}" "$EXE") ;;
esac
case "${{args[0]}}" in /*) ;; */*) args[0]="$PWD/${{args[0]}}" ;; esac
cd "$(dirname "$EXE")"
echo "$(date) Chay: ${{args[*]}}" >> "$LOG"
exec "${{args[@]}}"
"""
    p = _script_path()
    with open(p, "w", encoding="utf-8") as f:
        f.write(script)
    os.chmod(p, 0o755)
    return p


def shlex_quote(s: str) -> str:
    return "'" + s.replace("'", "'\\''") + "'"


def _vdf_launch_options(appid: str):
    """Đọc Launch Options hiện tại của game từ localconfig.vdf (dự phòng)."""
    root = steam_root()
    if not root:
        return None
    best = None
    for cfg in glob.glob(os.path.join(root, "userdata", "*", "config", "localconfig.vdf")):
        if best is None or os.path.getmtime(cfg) > os.path.getmtime(best):
            best = cfg
    if not best:
        return None
    try:
        text = open(best, encoding="utf-8", errors="ignore").read()
    except OSError:
        return None
    for m in re.finditer(r'"%s"\s*\{' % re.escape(str(appid)), text):
        depth, i = 1, m.end()
        start = i
        while i < len(text) and depth:
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
            i += 1
        block = text[start:i]
        top = re.sub(r"\{[^{}]*\}", "", block)
        while re.search(r"\{[^{}]*\}", top):
            top = re.sub(r"\{[^{}]*\}", "", top)
        lo = re.search(r'"LaunchOptions"\s+"((?:[^"\\]|\\.)*)"', top)
        if lo:
            return lo.group(1).replace('\\"', '"').replace("\\\\", "\\")
    return None


def prepare_installer(appid: str, exe_rel: str, original: str) -> dict:
    game = find_game(appid)
    exe = _patch_path(exe_rel)
    if not exe.lower().endswith((".exe", ".msi")):
        raise RuntimeError("Không phải file .exe/.msi")
    compat = os.path.join(game["library"], "steamapps", "compatdata", str(appid))
    if not os.path.isdir(compat) and not _find_exes(game["path"]):
        raise RuntimeError("Game này là bản Linux nên không chạy được trình cài Windows. "
                           "Hãy dùng bản Việt hóa dạng file (zip) nếu có.")
    script = _write_script()
    # Launch Options cũ: ưu tiên giá trị giao diện gửi lên, rồi tới localconfig.vdf.
    if not original:
        original = _vdf_launch_options(appid) or ""
    if script in original or "run-installer.sh" in original:
        try:
            original = json.load(open(_pending_restore(), encoding="utf-8")).get("original", "")
        except (OSError, ValueError):
            original = ""
    with open(_pending_exe(), "w", encoding="utf-8") as f:
        f.write(exe)
    with open(_pending_restore(), "w", encoding="utf-8") as f:
        json.dump({"appid": str(appid), "original": original}, f, ensure_ascii=False)

    man = load_manifest(appid) or {"game": game["name"], "replaced": [], "added": [], "patches": []}
    man["patches"].append({"name": exe_rel, "time": int(time.time()), "files": 0,
                           "mode": "installer", "source": read_source(exe_rel)})
    _save_manifest(appid, man)
    decky.logger.info(f"Prepared installer {exe_rel} for {game['name']}")
    return {
        "launch_options": f'"{script}" %command%',
        "original": original,
        "wine_path": "Z:" + game["path"].replace("/", "\\"),
        "game_path": game["path"],
    }


def get_pending_restore():
    try:
        with open(_pending_restore(), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def clear_pending_restore():
    for p in (_pending_restore(), _pending_exe()):
        if os.path.exists(p):
            os.remove(p)
    return True


def downloads_dir() -> str:
    return os.path.join(_home(), "Downloads")


def list_downloads(days: int = 30) -> list:
    """File Việt hóa tải bằng trình duyệt (nằm trong ~/Downloads), mới nhất trước."""
    d = downloads_dir()
    out = []
    try:
        names = os.listdir(d)
    except OSError:
        return []
    limit = time.time() - days * 86400
    for fn in names:
        full = os.path.join(d, fn)
        if fn.startswith(".") or not os.path.isfile(full) or not fn.lower().endswith(tuple(PATCH_EXTS)):
            continue
        if NOT_TRANSLATION.search(fn):
            continue
        st = os.stat(full)
        if st.st_mtime >= limit:
            out.append({"name": fn, "size": st.st_size, "mtime": int(st.st_mtime)})
    return sorted(out, key=lambda x: -x["mtime"])


def import_download(name: str, password: str = "", page: str = "") -> str:
    """Chép 1 file từ ~/Downloads vào ~/VietHoa (giải nén nếu cần). File gốc được giữ nguyên."""
    if os.path.basename(name) != name or name.startswith("."):
        raise RuntimeError("Tên file không hợp lệ")
    src = os.path.join(downloads_dir(), name)
    if not os.path.isfile(src):
        raise RuntimeError(f"Không thấy {name} trong thư mục Downloads")
    if NOT_TRANSLATION.search(name):
        raise RuntimeError(f"'{name}' không phải bản Việt hóa (crack/bypass)")
    tmpdir = tempfile.mkdtemp(prefix="viethoa_dl_", dir=patch_dir())
    try:
        tmp = os.path.join(tmpdir, name)
        shutil.copy2(src, tmp)
        return save_to_library(tmp, password, page, "file://" + src)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def install_downloaded(appid: str, patch: str) -> dict:
    """Cài bản vừa tải: chép file (có sao lưu) hoặc báo giao diện chạy trình cài qua Steam."""
    a = analyze_patch(appid, patch)
    if a["mode"] == "files":
        hint = (read_source(patch) or {}).get("target")  # kho chung có thể ghi sẵn thư mục đích
        r = do_apply(appid, patch, True, "", hint, hint is None)
        if r.get("needs_confirm"):
            return {"mode": "confirm", "patch": patch, **r}
        return {"mode": "files", **r}
    return a


# ---------------------------------------------------------------- plugin ---
def _fix_runtime_owner():
    """Sao lưu, manifest, script cài... trong thư mục dữ liệu phải thuộc user
    (script run-installer.sh do Steam chạy bằng user và tự xóa file chờ)."""
    try:
        userown.own_tree(decky.DECKY_PLUGIN_RUNTIME_DIR)
    except Exception:  # noqa: BLE001
        decky.logger.exception("Không đổi được chủ file dữ liệu")


async def _safe(fn, *args):
    try:
        return {"ok": True, "data": await asyncio.to_thread(fn, *args)}
    except Exception as e:  # noqa: BLE001
        decky.logger.exception("Viet Hoa error")
        return {"ok": False, "error": str(e)}
    finally:
        await asyncio.to_thread(_fix_runtime_owner)


# Thư mục dữ liệu của plugin cũ: All in 1 (tên trước của Wesdecky) và Việt hóa riêng lẻ.
OLD_VIETHOA_DIRS = ("all-in-1-weirdstore", "All in 1 by Weirdstore.vn", "viet-hoa", "Viet Hoa")
MIGRATE_ITEMS = ("backups", "sources.json", "pending-restore.json")


def migrate_old_viethoa() -> list:
    """Lần đầu chạy Wesdecky: chuyển sao lưu Việt hóa (để còn gỡ được) và nguồn tìm từ plugin cũ."""
    rt = decky.DECKY_PLUGIN_RUNTIME_DIR
    parent = os.path.dirname(os.path.normpath(rt))
    moved = []
    for d in OLD_VIETHOA_DIRS:
        old = os.path.join(parent, d)
        if not os.path.isdir(old) or os.path.realpath(old) == os.path.realpath(rt):
            continue
        for item in MIGRATE_ITEMS:
            src = os.path.join(old, item)
            dst = os.path.join(rt, item)
            if not os.path.exists(src):
                continue
            if item == "backups" and os.path.isdir(src):
                os.makedirs(dst, exist_ok=True)
                for appid in os.listdir(src):
                    if not os.path.exists(os.path.join(dst, appid)):
                        shutil.move(os.path.join(src, appid), os.path.join(dst, appid))
                        moved.append(f"backups/{appid}")
            elif not os.path.exists(dst):
                shutil.move(src, dst)
                moved.append(item)
    if moved:
        decky.logger.info(f"Đã chuyển dữ liệu Việt hóa cũ: {moved}")
    return moved


class Plugin(EgpuMixin, DnsMixin, NonSteamMixin):
    async def get_state(self):
        return await _safe(lambda: {
            "patch_dir": patch_dir(),
            "games": scan_games(),
            "patches": list_patches(),
        })

    async def backup_info(self, appid: str):
        return await _safe(backup_info, appid)

    async def apply_patch(self, appid: str, patch: str, strip: bool = True, password: str = "", target=None):
        return await _safe(do_apply, appid, patch, strip, password, target)

    async def preview_patch(self, appid: str, patch: str, strip: bool = True, password: str = "", target=None):
        return await _safe(preview_patch, appid, patch, strip, password, target)

    # ---- tải về từ web ----
    async def set_mirror_index(self, url: str):
        return await _safe(sources.set_mirror_index, url)

    async def search_online(self, game_name: str, appid: str = ""):
        return await _safe(search_sources, game_name, appid)

    async def get_sources(self):
        return await _safe(sources.list_sources)

    async def set_source_enabled(self, source_id: str, enabled: bool):
        return await _safe(sources.set_enabled, source_id, enabled)

    async def add_source(self, url: str, name: str = ""):
        return await _safe(sources.add_source, url, name)

    async def remove_source(self, source_id: str):
        return await _safe(sources.remove_source, source_id)

    async def find_links(self, url: str):
        return await _safe(find_links, url)

    async def download(self, url: str, password: str = "", page: str = ""):
        def after(path, cand):
            if path.lower().endswith((".zip", ".7z", ".rar")):
                JOB["msg"] = "Đang giải nén..."
            pw = password or cand.get("password_hint") or ""
            return save_to_library(path, pw, cand.get("page") or page, cand["url"], cand.get("mirror"))
        return await _safe(start_download, url, patch_dir(), after, page)

    async def download_best(self, pages: list, password: str = ""):
        def after(path, cand):
            if path.lower().endswith((".zip", ".7z", ".rar")):
                JOB["msg"] = "Đang giải nén..."
            pw = password or cand.get("password_hint") or ""
            return save_to_library(path, pw, cand.get("page", ""), cand["url"], cand.get("mirror"))
        return await _safe(start_download_best, pages, patch_dir(), after)

    async def analyze_patch(self, appid: str, patch: str):
        return await _safe(analyze_patch, appid, patch)

    async def list_downloads(self):
        return await _safe(list_downloads)

    async def import_download(self, name: str, password: str = "", page: str = ""):
        return await _safe(import_download, name, password, page)

    async def install_downloaded(self, appid: str, patch: str):
        return await _safe(install_downloaded, appid, patch)

    async def prepare_installer(self, appid: str, exe: str, original: str = ""):
        return await _safe(prepare_installer, appid, exe, original)

    async def get_pending_restore(self):
        return await _safe(get_pending_restore)

    async def clear_pending_restore(self):
        return await _safe(clear_pending_restore)

    async def download_status(self):
        return {"ok": True, "data": dict(JOB)}

    async def cancel_download(self):
        JOB["cancel"] = True
        return {"ok": True}

    async def restore(self, appid: str):
        return await _safe(do_restore, appid)

    async def run_exe(self, appid: str, patch: str):
        return await _safe(do_run_exe, appid, patch)

    async def _main(self):
        await self._viethoa_main()
        await self._egpu_main()
        await self._dns_main()
        decky.logger.info("Wesdecky loaded")

    async def _viethoa_main(self):
        try:
            await asyncio.to_thread(self._viethoa_setup)
        except Exception:  # noqa: BLE001
            decky.logger.exception("Việt hóa: lỗi khi khởi động")

    def _viethoa_setup(self):
        migrate_old_viethoa()
        os.makedirs(patch_dir(), exist_ok=True)
        os.makedirs(backup_root(), exist_ok=True)
        readme = os.path.join(patch_dir(), "DOC-TOI.txt")
        if not os.path.exists(readme):
            with open(readme, "w", encoding="utf-8") as f:
                f.write(
                    "Chép bản Việt hóa vào thư mục này (.zip, .7z, .rar, thư mục đã giải nén, hoặc .exe).\n"
                    "Sau đó mở menu ... > Wesdecky > Việt hóa, chọn game và bản Việt hóa rồi bấm Áp dụng.\n"
                    "Nút 'Gỡ Việt hóa' sẽ khôi phục file gốc của game.\n"
                )
        userown.own_tree(patch_dir())
        _fix_runtime_owner()

    async def _unload(self):
        decky.logger.info("Wesdecky unloaded")

    async def _uninstall(self):
        await self._dns_uninstall()
