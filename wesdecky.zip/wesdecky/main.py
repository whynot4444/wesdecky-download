"""
Wesdecky (by Weirdstore.vn) - Decky Loader plugin backend.

Đây chỉ là phần khung. Mỗi plugin con nằm trong plugins/<tên>/ và có backend/<tên>.py
khai báo WD_MODULE (xem py_modules/wd_registry.py). Khi build, các file backend được chép
vào py_modules/ của zip; main.py tự tìm và ghép tất cả thành class Plugin.
"""
import decky

import wd_registry

MODULES = wd_registry.discover()


async def _run_hooks(self, hook: str):
    for m in MODULES:
        name = m.get(hook)
        if not name:
            continue
        try:
            await getattr(self, name)()
        except Exception:  # noqa: BLE001
            decky.logger.exception(f"Module {m['name']}: lỗi ở {hook}")


class Plugin(*[m["mixin"] for m in MODULES]):
    async def _main(self):
        await _run_hooks(self, "main")
        decky.logger.info(f"Wesdecky loaded: {[m['name'] for m in MODULES]}")

    async def _unload(self):
        await _run_hooks(self, "unload")
        decky.logger.info("Wesdecky unloaded")

    async def _uninstall(self):
        await _run_hooks(self, "uninstall")
