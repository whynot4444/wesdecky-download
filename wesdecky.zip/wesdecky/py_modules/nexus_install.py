"""Cài/gỡ mod vào thư mục game Steam cho tab Mod của Wesdecky.

- Tìm game Steam đã cài (libraryfolders.vdf + appmanifest_*.acf).
- Giải nén an toàn (zip bằng zipfile; 7z/rar bằng bsdtar hoặc 7z), bỏ symlink và file ra ngoài.
- Chọn chỗ chép theo profile từng game (Data/ của Bethesda, Mods/ của Stardew…).
- Sao lưu file gốc. Nhiều mod ghi đè cùng một file thì giữ chuỗi chủ sở hữu, gỡ theo
  thứ tự nào cũng trả đúng file của mod bên dưới (hoặc file gốc).
- File game tự cập nhật sau khi cài (kích thước/mtime khác) thì không chép đè khi gỡ.
"""
import os
import re
import shutil
import subprocess
import zipfile

import decky
import userown

SKIP_NAMES = {"proton", "steam linux runtime", "steamworks common redistributables", "steamvr"}

# Profile theo AppID Steam.
#   data: thư mục dữ liệu (Bethesda); plugins: (thư mục trong AppData/Local, kiểu dòng, tên file)
#   root_markers: tên ở gốc archive cho biết archive tính từ thư mục game
#   loose: đuôi file rời -> thư mục đích; manifest/mods_dir: kiểu SMAPI; prefix_dirs: thư mục bắt đầu bằng… -> đích
BETHESDA_MARKERS = {
    "meshes", "textures", "scripts", "interface", "sound", "music", "skse", "f4se", "nvse", "seq", "strings",
    "materials", "shadersfx", "lodsettings", "grass", "menus", "video", "facegen", "distantlod", "lsdata",
    "calientetools", "netscriptframework", "source", "dialogueviews", "shaders", "vis", "programs", "mcm",
    "tools", "platform", "trees", "lightplacer", "skypatcher", "bodyslide",
}
BETHESDA_EXT = {".esp", ".esm", ".esl", ".bsa", ".ba2"}
PLUGIN_EXT = {".esp", ".esm", ".esl"}

PROFILES = {
    489830: {"domain": "skyrimspecialedition", "data": "Data", "markers": BETHESDA_MARKERS,
             "exts": BETHESDA_EXT, "plugins": ("Skyrim Special Edition", "star", "Plugins.txt")},
    377160: {"domain": "fallout4", "data": "Data", "markers": BETHESDA_MARKERS,
             "exts": BETHESDA_EXT, "plugins": ("Fallout4", "star", "Plugins.txt")},
    22380: {"domain": "newvegas", "data": "Data", "markers": BETHESDA_MARKERS,
            "exts": BETHESDA_EXT, "plugins": ("FalloutNV", "plain", "plugins.txt")},
    1091500: {"domain": "cyberpunk2077", "root_markers": {"bin", "r6", "archive", "red4ext", "engine", "mods"},
              "loose": {".archive": "archive/pc/mod", ".xl": "archive/pc/mod"}},
    413150: {"domain": "stardewvalley", "manifest": "manifest.json", "mods_dir": "Mods"},
    292030: {"domain": "witcher3", "root_markers": {"mods", "dlc", "bin"},
             "prefix_dirs": {"mod": "mods", "dlc": "dlc"}},
}

DOC_RE = re.compile(r"^(readme|read me|changelog|change log|license|licence|credits|install|installation)[^/]*"
                    r"|.*\.(url|md|pdf|html?|jpe?g|png|gif|webp|bmp|rtf)$", re.I)
EXEC_EXT = {".exe", ".dll", ".asi"}


class InstallError(Exception):
    def __init__(self, code: str, msg: str = ""):
        super().__init__(msg or code)
        self.code = code


# ------------------------------------------------------------- Steam ---
def _vdf_values(text: str, key: str):
    return re.findall(r'"%s"\s+"((?:[^"\\]|\\.)*)"' % re.escape(key), text, re.I)


def steam_root() -> str:
    home = decky.DECKY_USER_HOME
    for p in (".local/share/Steam", ".steam/steam", ".steam/root"):
        d = os.path.join(home, p)
        if os.path.isdir(os.path.join(d, "steamapps")):
            return os.path.realpath(d)
    return os.path.join(home, ".local/share/Steam")


def libraries() -> list:
    root = steam_root()
    libs = [root]
    try:
        with open(os.path.join(root, "steamapps/libraryfolders.vdf"), encoding="utf-8", errors="replace") as f:
            for p in _vdf_values(f.read(), "path"):
                p = os.path.realpath(p.replace("\\\\", "\\"))
                if p not in libs and os.path.isdir(os.path.join(p, "steamapps")):
                    libs.append(p)
    except OSError:
        pass
    return libs


def installed_games() -> list:
    games, seen = [], set()
    for lib in libraries():
        sa = os.path.join(lib, "steamapps")
        try:
            names = sorted(os.listdir(sa))
        except OSError:
            continue
        for n in names:
            m = re.fullmatch(r"appmanifest_(\d+)\.acf", n)
            if not m:
                continue
            try:
                with open(os.path.join(sa, n), encoding="utf-8", errors="replace") as f:
                    t = f.read()
            except OSError:
                continue
            appid = int(m.group(1))
            name = (_vdf_values(t, "name") or [""])[0]
            idir = (_vdf_values(t, "installdir") or [""])[0]
            if appid in seen or not idir or any(name.lower().startswith(s) for s in SKIP_NAMES):
                continue
            path = os.path.join(sa, "common", idir)
            if not os.path.isdir(path):
                continue
            seen.add(appid)
            games.append({"appid": appid, "name": name or idir, "path": path, "library": lib,
                          "profile": appid in PROFILES})
    games.sort(key=lambda g: g["name"].lower())
    return games


def find_game(appid: int) -> dict:
    for g in installed_games():
        if g["appid"] == int(appid):
            return g
    raise InstallError("game_missing", str(appid))


def prefix_dir(appid: int):
    for lib in libraries():
        p = os.path.join(lib, "steamapps/compatdata", str(int(appid)), "pfx")
        if os.path.isdir(p):
            return p
    return None


# ----------------------------------------------------------- giải nén ---
def _clean_env():
    env = dict(os.environ)
    for k in ("LD_LIBRARY_PATH", "LD_PRELOAD", "PYTHONHOME", "PYTHONPATH"):
        env.pop(k, None)
    return env


def _inside(base: str, path: str) -> bool:
    base = os.path.realpath(base)
    p = os.path.realpath(path)
    return p == base or p.startswith(base + os.sep)


def extract(archive: str, dest: str):
    """Giải nén vào dest (thư mục trống). Sau đó xóa mọi symlink và thứ nằm ngoài dest."""
    os.makedirs(dest, exist_ok=True)
    if zipfile.is_zipfile(archive):
        with zipfile.ZipFile(archive) as z:
            for info in z.infolist():
                name = info.filename.replace("\\", "/")
                parts = [p for p in name.split("/") if p not in ("", ".")]
                if not parts or ".." in parts or name.startswith("/") or re.match(r"^[A-Za-z]:", name):
                    continue
                if (info.external_attr >> 16) & 0o170000 == 0o120000:  # symlink trong zip
                    continue
                target = os.path.join(dest, *parts)
                if not _inside(dest, target):
                    continue
                if info.is_dir() or name.endswith("/"):
                    os.makedirs(target, exist_ok=True)
                    continue
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with z.open(info) as src, open(target, "wb") as out:
                    shutil.copyfileobj(src, out, 1 << 20)
    else:
        tools = []
        if shutil.which("bsdtar"):
            tools.append(["bsdtar", "-x", "-f", archive, "-C", dest])
        for t in ("7z", "7za", "7zz"):
            if shutil.which(t):
                tools.append([t, "x", "-y", "-snl-", f"-o{dest}", archive])
                break
        if not tools:
            raise InstallError("no_extractor", "Không có bsdtar/7z để giải nén file này")
        err = ""
        for cmd in tools:
            r = subprocess.run(cmd, capture_output=True, text=True, env=_clean_env(), timeout=1800)
            if r.returncode == 0:
                err = ""
                break
            err = (r.stderr or r.stdout or "").strip()[-300:]
        if err:
            raise InstallError("extract_failed", err)
    # Dọn: bỏ symlink, đảm bảo không có gì lọt ra ngoài.
    for dp, dns, fns in os.walk(dest):
        for n in list(dns) + fns:
            p = os.path.join(dp, n)
            if os.path.islink(p):
                os.unlink(p)
                if n in dns:
                    dns.remove(n)
    if not any(os.scandir(dest)):
        raise InstallError("empty_archive")


# --------------------------------------------------- chọn chỗ chép ---
def _entries(d: str):
    """(thư mục, file) ở một cấp, bỏ file tài liệu và thư mục fomod."""
    dirs, files = [], []
    for e in sorted(os.scandir(d), key=lambda e: e.name.lower()):
        if e.is_dir(follow_symlinks=False):
            if e.name.lower() != "fomod":
                dirs.append(e.name)
        elif e.is_file(follow_symlinks=False) and not DOC_RE.match(e.name):
            files.append(e.name)
    return dirs, files


def has_fomod(root: str) -> bool:
    for dp, dns, fns in os.walk(root):
        if os.path.basename(dp).lower() == "fomod" and any(f.lower() == "moduleconfig.xml" for f in fns):
            return True
    return False


def plan(root: str, appid: int, stem: str = "mod") -> dict:
    """Trả {"items": [(src_dir, dest_rel)], "guess": bool, "where": str}.

    Mỗi item: chép mọi file trong src_dir (đệ quy, trừ tài liệu ở cấp đầu và fomod) vào dest_rel
    tính từ thư mục game.
    """
    prof = PROFILES.get(int(appid), {})
    # Kiểu SMAPI: mỗi thư mục có manifest.json là một mod -> Mods/<tên thư mục>.
    if prof.get("manifest"):
        found = []
        for dp, dns, fns in os.walk(root):
            if prof["manifest"] in (f.lower() for f in fns):
                name = os.path.basename(dp) if dp != root else stem
                found.append((dp, f"{prof['mods_dir']}/{name}"))
                dns[:] = []
        if found:
            return {"items": found, "guess": False, "where": prof["mods_dir"]}

    cur = root
    for _ in range(8):
        dirs, files = _entries(cur)
        low_d = {d.lower() for d in dirs}
        low_all = low_d | {f.lower() for f in files}
        exts = {os.path.splitext(f)[1].lower() for f in files}
        data = prof.get("data")
        if data and data.lower() in low_d:
            return {"items": [(cur, "")], "guess": False, "where": "thư mục game"}
        if low_all & set(prof.get("root_markers", ())):
            return {"items": [(cur, "")], "guess": False, "where": "thư mục game"}
        if data and (low_d & prof.get("markers", set()) or exts & prof.get("exts", set())):
            return {"items": [(cur, data)], "guess": False, "where": data}
        if exts & EXEC_EXT:
            return {"items": [(cur, "")], "guess": False, "where": "thư mục game"}
        loose = prof.get("loose") or {}
        if files and not dirs and loose and all(os.path.splitext(f)[1].lower() in loose for f in files):
            target = loose[os.path.splitext(files[0])[1].lower()]
            return {"items": [(cur, target)], "guess": False, "where": target}
        pref = prof.get("prefix_dirs") or {}
        if dirs and pref and not files:
            for p, target in pref.items():
                if all(d.lower().startswith(p) for d in dirs):
                    return {"items": [(cur, target)], "guess": False, "where": target}
        if len(dirs) == 1 and not files:
            cur = os.path.join(cur, dirs[0])
            continue
        break
    base = prof.get("data", "")
    if prof.get("prefix_dirs") and not base:
        # Witcher 3: mod rời (chỉ có content/…) -> mods/mod<tên>.
        name = "mod" + (re.sub(r"[^A-Za-z0-9_]", "", stem)[:40] or "Wesdecky")
        return {"items": [(cur, f"mods/{name}")], "guess": True, "where": f"mods/{name}"}
    if prof.get("mods_dir"):
        base = f"{prof['mods_dir']}/{stem}"
    return {"items": [(cur, base)], "guess": True, "where": base or "thư mục game"}


def collect(items) -> list:
    """Danh sách (src_file, dest_rel_file) theo plan, bỏ tài liệu ở cấp đầu và fomod."""
    out = []
    for src_dir, dest in items:
        for dp, dns, fns in os.walk(src_dir):
            dns[:] = [d for d in dns if d.lower() != "fomod" and not os.path.islink(os.path.join(dp, d))]
            rel_dir = os.path.relpath(dp, src_dir)
            for f in fns:
                p = os.path.join(dp, f)
                if os.path.islink(p) or not os.path.isfile(p):
                    continue
                if rel_dir == "." and DOC_RE.match(f):
                    continue
                rel = f if rel_dir == "." else f"{rel_dir}/{f}"
                rel = rel.replace(os.sep, "/")
                out.append((p, f"{dest}/{rel}" if dest else rel))
    return out


# ---------------------------------------------------- cài và gỡ file ---
def ci_resolve(root: str, rel: str) -> str:
    """Nối rel vào root, khớp không phân biệt hoa/thường với thư mục/file đã có (game Windows)."""
    cur = root
    parts = [p for p in rel.replace("\\", "/").split("/") if p not in ("", ".")]
    if any(p == ".." for p in parts):
        raise InstallError("bad_path", rel)
    for p in parts:
        nxt = os.path.join(cur, p)
        if not os.path.lexists(nxt) and os.path.isdir(cur):
            try:
                for e in os.listdir(cur):
                    if e.lower() == p.lower():
                        nxt = os.path.join(cur, e)
                        break
            except OSError:
                pass
        cur = nxt
    return cur


def fingerprint(path: str):
    try:
        st = os.stat(path)
        return [st.st_size, st.st_mtime_ns]
    except OSError:
        return None


def _make_writable(path: str):
    try:
        st = os.stat(path)
        if not st.st_mode & 0o200:
            os.chmod(path, st.st_mode | 0o200)
    except OSError:
        pass


def _mkdirs(game_root: str, d: str, created: list):
    missing = []
    while not os.path.isdir(d):
        if os.path.lexists(d):
            raise InstallError("bad_path", d)
        missing.append(d)
        d = os.path.dirname(d)
    for m in reversed(missing):
        os.mkdir(m)
        userown.own(m)
        created.append(os.path.relpath(m, game_root).replace(os.sep, "/"))


def install_files(game_root: str, files: list, key: str, gstate: dict, backup_dir: str, cancel=None,
                  rec: dict = None) -> dict:
    """Chép files [(src, rel)] vào game. Ghi vào gstate["owners"]. Trả bản ghi file của mod."""
    owners = gstate.setdefault("owners", {})
    if rec is None:
        rec = {}
    rec.setdefault("files", {})
    rec.setdefault("backed", {})
    rec.setdefault("dirs", [])
    game_root = os.path.realpath(game_root)
    for src, rel in files:
        if cancel and cancel():
            raise InstallError("cancelled")
        dest = ci_resolve(game_root, rel)
        if not _inside(game_root, os.path.dirname(dest)) or os.path.islink(dest):
            raise InstallError("bad_path", rel)
        real_rel = os.path.relpath(dest, game_root).replace(os.sep, "/")
        if real_rel in rec["files"]:
            continue  # trùng tên khác hoa/thường trong archive: giữ file đầu
        _mkdirs(game_root, os.path.dirname(dest), rec["dirs"])
        if os.path.isfile(dest):
            b = os.path.join(backup_dir, real_rel)
            os.makedirs(os.path.dirname(b), exist_ok=True)
            shutil.copy2(dest, b)
            rec["backed"][real_rel] = True
            _make_writable(dest)
        else:
            rec["backed"][real_rel] = False
        shutil.copyfile(src, dest + ".wdpart")
        os.replace(dest + ".wdpart", dest)
        userown.own(dest)
        rec["files"][real_rel] = fingerprint(dest)
        owners.setdefault(real_rel, [])
        if key in owners[real_rel]:
            owners[real_rel].remove(key)
        owners[real_rel].append(key)
    if os.path.isdir(backup_dir):
        userown.own_tree(backup_dir)
    return rec


def uninstall_files(game_root: str, key: str, rec: dict, gstate: dict, backup_dirs: dict) -> dict:
    """Gỡ file của mod `key`. backup_dirs: key -> thư mục backup của từng mod."""
    owners = gstate.setdefault("owners", {})
    mods = gstate.setdefault("mods", {})
    game_root = os.path.realpath(game_root)
    kept, restored, removed = [], 0, 0
    for rel, fp in rec.get("files", {}).items():
        chain = owners.get(rel, [])
        mine_backup = os.path.join(backup_dirs[key], rel)
        backed = rec.get("backed", {}).get(rel, False)
        if key not in chain:
            continue
        idx = chain.index(key)
        dest = os.path.join(game_root, rel)
        if idx < len(chain) - 1:
            # Mod phía trên đang giữ file: chuyển bản sao lưu của mình cho mod đó.
            upper = chain[idx + 1]
            urec = (mods.get(upper) or {}).get("install") or {}
            ub = os.path.join(backup_dirs[upper], rel)
            if backed and os.path.isfile(mine_backup):
                os.makedirs(os.path.dirname(ub), exist_ok=True)
                os.replace(mine_backup, ub)
                userown.own_with_parents(ub, backup_dirs[upper])
            elif os.path.isfile(ub):
                os.unlink(ub)
            urec.setdefault("backed", {})[rel] = bool(backed)
        else:
            if fingerprint(dest) == fp:
                if backed and os.path.isfile(mine_backup):
                    _make_writable(dest)
                    shutil.copy2(mine_backup, dest + ".wdpart")
                    os.replace(dest + ".wdpart", dest)
                    userown.own(dest)
                    restored += 1
                else:
                    try:
                        _make_writable(dest)
                        os.unlink(dest)
                        removed += 1
                    except FileNotFoundError:
                        pass
            elif os.path.exists(dest):
                kept.append(rel)  # game/người dùng đã đổi file này: giữ nguyên
        chain.remove(key)
        if not chain:
            owners.pop(rel, None)
    for d in sorted(rec.get("dirs", []), key=lambda x: -x.count("/")):
        try:
            os.rmdir(os.path.join(game_root, d))
        except OSError:
            pass
    shutil.rmtree(backup_dirs[key], ignore_errors=True)
    return {"restored": restored, "removed": removed, "kept": kept}


# ----------------------------------------------------------- Plugins.txt ---
def plugin_names(rec: dict, appid: int) -> list:
    prof = PROFILES.get(int(appid), {})
    data = (prof.get("data") or "").lower()
    if not prof.get("plugins") or not data:
        return []
    out = []
    for rel in rec.get("files", {}):
        parts = rel.split("/")
        if len(parts) == 2 and parts[0].lower() == data and os.path.splitext(parts[1])[1].lower() in PLUGIN_EXT:
            out.append(parts[1])
    return sorted(out, key=lambda n: (os.path.splitext(n)[1].lower() != ".esm", n.lower()))


def plugins_file(appid: int):
    prof = PROFILES.get(int(appid), {})
    if not prof.get("plugins"):
        return None
    pfx = prefix_dir(appid)
    if not pfx:
        return None
    folder, _, fname = prof["plugins"]
    local = ci_resolve(pfx, "drive_c/users/steamuser/AppData/Local")
    return ci_resolve(local, f"{folder}/{fname}"), local


def update_plugins(appid: int, add: list = (), remove: list = ()) -> str:
    """Thêm/bỏ dòng plugin. Trả 'ok', 'no_prefix' hoặc 'none'."""
    if not add and not remove:
        return "none"
    pf = plugins_file(appid)
    if not pf:
        return "no_prefix" if PROFILES.get(int(appid), {}).get("plugins") else "none"
    path, local = pf
    style = PROFILES[int(appid)]["plugins"][1]
    try:
        with open(path, encoding="utf-8-sig", errors="replace") as f:
            lines = f.read().splitlines()
    except FileNotFoundError:
        lines = []
    rm = {n.lower() for n in remove}
    lines = [ln for ln in lines if ln.lstrip("*").strip().lower() not in rm]
    have = {ln.lstrip("*").strip().lower() for ln in lines if ln.strip() and not ln.startswith("#")}
    for n in add:
        if n.lower() not in have:
            lines.append(("*" + n) if style == "star" else n)
            have.add(n.lower())
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path + ".wdpart", "w", encoding="utf-8", newline="\r\n") as f:
        f.write("\n".join(lines) + ("\n" if lines else ""))
    os.replace(path + ".wdpart", path)
    userown.own_with_parents(path, local)
    return "ok"
