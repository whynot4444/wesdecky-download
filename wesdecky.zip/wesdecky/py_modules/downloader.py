"""
Tìm và tải bản Việt hóa từ web (The Red Team, Cánh Cụt Team, Google Drive, MediaFire, link trực tiếp).
"""
import hashlib
import html
import http.cookiejar
import os
import re
import shutil
import ssl
import tarfile
import threading
import time
import unicodedata
import urllib.parse
import urllib.request

import decky

UA = ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/130.0 Safari/537.36")
KNOWN_PASSWORDS = ["Theredteam.vn", "theredteam.vn", "Canhcutteam", "canhcutteam", "canhcutteam.com"]
CANHCUT_LAUNCHER = "https://download.canhcutteam.com/Launcher/CanhCutTeam_Portable.zip"
SEVENZIP_URLS = [
    "https://github.com/ip7z/7zip/releases/download/24.09/7z2409-linux-x64.tar.xz",
    "https://www.7-zip.org/a/7z2409-linux-x64.tar.xz",
]
# Plugin chỉ cài bản Việt hóa: bỏ qua crack, bypass DRM và các bản game lậu.
NOT_TRANSLATION = re.compile(r"crack|bypass|steamless|goldberg|emu(lator)?\b|codex|empress|repack|unlock(er)?", re.I)
ARCHIVE_EXTS = (".zip", ".rar", ".7z", ".exe", ".msi")

JOB = {"state": "idle", "name": "", "done": 0, "total": 0, "msg": "", "result": "", "cancel": False, "used": None}


# ------------------------------------------------------------------ http ---
def _ssl_ctx():
    ctx = ssl.create_default_context()
    for ca in ("/etc/ssl/certs/ca-certificates.crt", "/etc/ca-certificates/extracted/tls-ca-bundle.pem"):
        if os.path.exists(ca):
            try:
                ctx.load_verify_locations(ca)
            except ssl.SSLError:
                pass
    return ctx


def _opener():
    return urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()),
        urllib.request.HTTPSHandler(context=_ssl_ctx()),
    )


def _open(opener, url, timeout=30):
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept-Language": "vi,en;q=0.8"})
    return opener.open(req, timeout=timeout)


def _get_text(url, opener=None):
    with _open(opener or _opener(), url) as r:
        return r.geturl(), r.read(3_000_000).decode("utf-8", errors="ignore")


def _title(page):
    m = re.search(r"<title[^>]*>(.*?)</title>", page, re.S | re.I)
    return html.unescape(re.sub(r"\s+", " ", m.group(1))).strip() if m else ""


def _slugify(text):
    text = unicodedata.normalize("NFKD", text.replace("đ", "d").replace("Đ", "D"))
    text = text.encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", text.replace("'", "")).strip("-")


# ---------------------------------------------------------------- search ---
def search_sources(game_name, appid=""):
    """Tìm trang Việt hóa của game ở mọi nguồn đang bật (xem sources.py)."""
    from sources import search_all  # tránh import vòng

    return search_all(game_name, appid)


# ----------------------------------------------------------------- links ---
def classify(url):
    u = url.strip()
    if re.search(r"drive\.google\.com/drive/(u/\d+/)?folders", u):
        return "gdrive_folder", False, "Thư mục Google Drive: hãy mở bằng trình duyệt và lấy link từng file"
    if re.search(r"(drive|docs)\.google\.com/.*(file/d/|[?&]id=)", u) or "drive.usercontent.google.com" in u:
        return "gdrive", True, ""
    if re.search(r"mediafire\.com/(file|download|file_premium)/", u):
        return "mediafire", True, ""
    if re.search(r"discord\.(com/channels|gg/|com/invite)", u) or re.search(r"/go/discord\b", u):
        return "discord", False, "Nhóm phát hành qua Discord: mở để vào Discord của nhóm tải bản Việt hóa"
    if re.search(r"nexusmods\.com/[^/]+/mods/\d+", u):
        return "nexus", False, "Nexus Mods cần đăng nhập: mở trang để tải bằng trình duyệt"
    if "fshare.vn" in u:
        return "fshare", False, "Fshare cần đăng nhập/VIP, hãy tải bằng trình duyệt rồi chép vào ~/VietHoa"
    path = urllib.parse.urlparse(u).path.lower()
    if path.endswith(ARCHIVE_EXTS):
        return "direct", True, ""
    return None, False, ""


def find_links(url):
    """Trả về danh sách link tải tìm thấy (hoặc chính link đó nếu là link tải)."""
    url = url.strip()
    if url.startswith("mirror:"):
        import mirror
        import sources

        return mirror.links(mirror.entry_for_ref(url, sources.mirror_index()))
    if not re.match(r"^https?://", url):
        url = "https://" + url
    kind, ok, note = classify(url)
    if kind:
        return [{"label": urllib.parse.unquote(url.rsplit("/", 1)[-1])[:60] or kind, "url": url,
                 "kind": kind, "supported": ok, "note": note}]

    final, page = _get_text(url)
    out, seen = [], set()
    for m in re.finditer(r"<a\b[^>]*href=[\"']([^\"']+)[\"'][^>]*>(.*?)</a>", page, re.S | re.I):
        href = html.unescape(m.group(1)).strip()
        if href.startswith("#") or href.lower().startswith("javascript"):
            continue
        href = urllib.parse.urljoin(final, href)
        kind, ok, note = classify(href)
        if not kind or href in seen:
            continue
        seen.add(href)
        label = html.unescape(re.sub(r"<[^>]+>|\s+", " ", m.group(2))).strip() or kind
        if NOT_TRANSLATION.search(label) or NOT_TRANSLATION.search(urllib.parse.unquote(href)):
            continue
        out.append({"label": label[:60], "url": href, "kind": kind, "supported": ok, "note": note})

    # Link Discord thường nằm ở chân trang: chỉ giữ khi trang không có link tải nào khác.
    if any(l["supported"] for l in out):
        out = [l for l in out if l["kind"] != "discord"]
    else:
        out = [l for l in out if l["kind"] != "discord"] + [l for l in out if l["kind"] == "discord"][:1]
    if "canhcutteam." in urllib.parse.urlparse(final).netloc:
        out.insert(0, {"label": "Cánh Cụt Team Launcher (portable)", "url": CANHCUT_LAUNCHER,
                       "kind": "launcher", "supported": True,
                       "note": "Cánh Cụt phát hành Việt hóa qua Launcher: tải về rồi chạy bằng Proton"})
    pw = find_password(page)
    if pw and out:
        out[0]["password_hint"] = pw
    return out


def _visible_text(page):
    text = re.sub(r"<(script|style)\b.*?</\1\s*>", " ", page, flags=re.S | re.I)
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", text))).strip()


def find_password(page):
    """Tìm mật khẩu giải nén trong phần chữ hiển thị của trang (bỏ qua script/style)."""
    text = _visible_text(page)
    m = re.search(r"(?:mật\s*khẩu|password|pass)(?:\s*(?:giải\s*nén|file|tải))?\s*(?:là|:|：)\s*[\"'“”]?"
                  r"([A-Za-z0-9][A-Za-z0-9._@#!$%&*+-]{2,39})", text, re.I)
    if not m:
        return None
    pw = m.group(1).rstrip(".")
    return pw if pw.lower() not in ("true", "false", "null", "undefined") else None


# -------------------------------------------------------------- download ---
def _filename(resp, url):
    cd = resp.headers.get("Content-Disposition", "")
    m = re.search(r"filename\*\s*=\s*[^']*''([^;]+)", cd) or re.search(r'filename\s*=\s*"?([^";]+)"?', cd)
    name = urllib.parse.unquote(m.group(1)) if m else urllib.parse.unquote(urllib.parse.urlparse(url).path.rsplit("/", 1)[-1])
    name = os.path.basename(name.replace("\\", "/")).strip() or "viethoa.bin"
    return re.sub(r'[<>:"|?*\x00-\x1f]', "_", name)


def _resolve(opener, url):
    """Trả về response đang mở của file thật."""
    kind, ok, note = classify(url)
    if kind and not ok:
        raise RuntimeError(note)

    if kind == "gdrive":
        m = re.search(r"(?:file/d/|[?&]id=)([\w-]{10,})", url)
        if not m:
            raise RuntimeError("Link Google Drive không hợp lệ")
        url = f"https://drive.usercontent.google.com/download?id={m.group(1)}&export=download"
        for _ in range(3):
            r = _open(opener, url, 60)
            if "text/html" not in r.headers.get("Content-Type", ""):
                return r
            page = r.read(2_000_000).decode("utf-8", errors="ignore")
            r.close()
            # Trang "file lớn, không quét virus được": có form xác nhận tải -> gửi lại form.
            form = re.search(r'<form[^>]*id="download-form"[^>]*action="([^"]+)"', page)
            if form:
                fields = re.findall(r"<input\b[^>]*>", page)
                inputs = {}
                for tag in fields:
                    n = re.search(r'name="([^"]+)"', tag)
                    v = re.search(r'value="([^"]*)"', tag)
                    if n:
                        inputs[n.group(1)] = html.unescape(v.group(1)) if v else ""
                url = html.unescape(form.group(1)) + "?" + urllib.parse.urlencode(inputs)
                continue
            visible = _visible_text(page)
            decky.logger.warning("Google Drive page: " + visible[:300])
            if re.search(r"quota|too many users|quá nhiều người|vượt quá hạn mức", visible, re.I):
                raise RuntimeError("Google Drive báo file đã bị tải quá nhiều, tạm khóa. Thử lại sau vài giờ "
                                   "hoặc dùng link khác trên trang của nhóm dịch.")
            raise RuntimeError("Google Drive không cho tải file này (file riêng tư hoặc đã bị xóa)")
        raise RuntimeError("Không lấy được file từ Google Drive")

    if kind == "mediafire":
        _, page = _get_text(url, opener)
        m = (re.search(r'id="downloadButton"[^>]*href="([^"]+)"', page)
             or re.search(r'href="(https?://download\d*\.mediafire\.com/[^"]+)"', page))
        if not m:
            raise RuntimeError("Không tìm thấy nút tải trên MediaFire")
        url = html.unescape(m.group(1))

    r = _open(opener, url, 60)
    if "text/html" in r.headers.get("Content-Type", ""):
        r.close()
        raise RuntimeError("Link trả về trang web chứ không phải file. Hãy mở link bằng trình duyệt.")
    return r


# Link không bị giới hạn lượt tải được thử trước; Launcher (không phải bản Việt hóa) để cuối.
KIND_ORDER = {"direct": 0, "mediafire": 1, "gdrive": 2, "launcher": 9}


def rank_links(cands):
    """Sắp xếp link: loại link tải được nhanh/ít bị khóa lên trước, giữ thứ tự trang (nhóm) khi ngang nhau."""
    ok = [c for c in cands if c.get("supported", True) and c.get("kind") in KIND_ORDER]
    seen, out = set(), []
    # Nhóm ưu tiên (trang đứng trước, ví dụ The Red Team) thử hết trước; Launcher luôn để cuối.
    for c in sorted(ok, key=lambda c: (c["kind"] == "launcher", c.get("rank", 0), KIND_ORDER[c["kind"]])):
        if c["url"] not in seen:
            seen.add(c["url"])
            out.append(c)
    return out


def gather_candidates(pages):
    """Lấy link tải từ nhiều trang Việt hóa (theo thứ tự ưu tiên của trang)."""
    cands = []
    for rank, page in enumerate(pages):
        if JOB["cancel"]:
            break
        try:
            for l in find_links(page):
                cands.append({**l, "page": page, "team": _team(page), "rank": rank})
        except Exception as e:  # noqa: BLE001
            decky.logger.warning(f"find_links {page}: {e}")
    return rank_links(cands)


def _team(url):
    if (url or "").startswith("mirror:"):
        return "Kho chung"
    host = urllib.parse.urlparse(url or "").netloc.lower()
    return "The Red Team" if "theredteam" in host else "Cánh Cụt Team" if "canhcut" in host else host


def _stream(r, dest_dir):
    name = _filename(r, r.geturl())
    JOB.update(name=name, total=int(r.headers.get("Content-Length") or 0), done=0)
    os.makedirs(dest_dir, exist_ok=True)
    path = os.path.join(dest_dir, name)
    part = path + ".part"
    try:
        with open(part, "wb") as f:
            while True:
                if JOB["cancel"]:
                    raise RuntimeError("Đã hủy tải")
                chunk = r.read(1 << 20)
                if not chunk:
                    break
                f.write(chunk)
                JOB["done"] += len(chunk)
        os.replace(part, path)
    finally:
        if os.path.exists(part):
            os.remove(part)
    return path


def _job(cands, dest_dir, after, pages=None):
    """Thử lần lượt từng link, tải link đầu tiên tải được."""
    try:
        opener = _opener()
        if pages:
            JOB["msg"] = "Đang tìm link tải trên các trang Việt hóa..."
            cands = gather_candidates(pages)
            if not cands:
                raise RuntimeError("Các trang Việt hóa không có link tải dùng được. Hãy mở trang trong trình duyệt.")
        reasons = []
        for i, c in enumerate(cands):
            if JOB["cancel"]:
                raise RuntimeError("Đã hủy tải")
            where = f"{c.get('label') or c['kind']}" + (f" ({c['team']})" if c.get("team") else "")
            JOB["msg"] = f"Đang thử {where}" + (f" – link {i + 1}/{len(cands)}" if len(cands) > 1 else "") + "..."
            try:
                r = _resolve(opener, c["url"])
            except Exception as e:  # noqa: BLE001
                reasons.append(f"{where}: {e}")
                continue
            with r:
                name = _filename(r, r.geturl())
                if NOT_TRANSLATION.search(name):
                    reasons.append(f"{where}: '{name}' không phải bản Việt hóa (crack/bypass), plugin không tải file này.")
                    continue
                JOB["msg"] = f"Đang tải từ {where}..."
                path = _stream(r, dest_dir)
            if c.get("sha256"):
                JOB["msg"] = "Đang kiểm tra file (SHA-256)..."
                if _sha256(path) != c["sha256"]:
                    os.remove(path)
                    reasons.append(f"{where}: file tải về không khớp mã SHA-256 (hỏng hoặc đã bị thay), đã xóa")
                    continue
            result = after(path, c) if after else os.path.basename(path)
            JOB.update(state="done", msg="Xong", result=result, used=c)
            decky.logger.info(f"Downloaded {c['url']} -> {result}")
            return
        if len(reasons) == 1:
            raise RuntimeError(reasons[0].split(": ", 1)[1])
        quota = all("tải quá nhiều" in x or "crack" in x for x in reasons) and any("tải quá nhiều" in x for x in reasons)
        head = ("Mọi link Google Drive đều đang bị tải quá nhiều, tạm khóa." if quota
                else "Không link nào tải được.")
        raise RuntimeError(head + "\n" + "\n".join("• " + x for x in reasons))
    except Exception as e:  # noqa: BLE001
        decky.logger.exception("download failed")
        JOB.update(state="error", msg=str(e))


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            if JOB["cancel"]:
                raise RuntimeError("Đã hủy tải")
            h.update(chunk)
    return h.hexdigest()


def _begin():
    if JOB["state"] == "running":
        raise RuntimeError("Đang có file khác đang tải")
    JOB.update(state="running", name="", done=0, total=0, msg="Bắt đầu...", result="", cancel=False, used=None)


def start_download(url, dest_dir, after=None, page=""):
    extra = {}
    if page.startswith("mirror:"):  # lấy mã SHA-256 và thông tin nguồn của file trong kho chung
        extra = next((l for l in find_links(page) if l["url"] == url), {})
    _begin()
    kind = classify(url)[0] or "direct"
    cand = {**extra, "url": url, "kind": kind, "label": extra.get("label", ""), "page": page,
            "team": _team(page) if page and not extra else ""}
    threading.Thread(target=_job, args=([cand], dest_dir, after), daemon=True).start()
    return {"started": True}


def start_download_best(pages, dest_dir, after=None):
    """Tự tìm và tải link tải được đầu tiên trên các trang Việt hóa."""
    if not pages:
        raise RuntimeError("Chưa có trang Việt hóa nào")
    _begin()
    threading.Thread(target=_job, args=([], dest_dir, after, list(pages)), daemon=True).start()
    return {"started": True}


# ----------------------------------------------------------------- 7-zip ---
def get_7z():
    for n in ("7zz", "7z", "7za"):
        p = shutil.which(n)
        if p:
            return p
    bin_dir = os.path.join(decky.DECKY_PLUGIN_RUNTIME_DIR, "bin")
    exe = os.path.join(bin_dir, "7zz")
    if os.access(exe, os.X_OK):
        return exe
    os.makedirs(bin_dir, exist_ok=True)
    opener = _opener()
    for url in SEVENZIP_URLS:
        tmp = os.path.join(bin_dir, "7z.tar.xz")
        try:
            with _open(opener, url, 60) as r, open(tmp, "wb") as f:
                shutil.copyfileobj(r, f)
            with tarfile.open(tmp, "r:xz") as tf:
                member = next(m for m in tf.getmembers() if os.path.basename(m.name) == "7zz")
                with tf.extractfile(member) as s, open(exe, "wb") as d:
                    shutil.copyfileobj(s, d)
            os.chmod(exe, 0o755)
            decky.logger.info(f"Installed 7zz from {url}")
            return exe
        except Exception as e:  # noqa: BLE001
            decky.logger.warning(f"7zz download failed from {url}: {e}")
        finally:
            if os.path.exists(tmp):
                os.remove(tmp)
    return None
