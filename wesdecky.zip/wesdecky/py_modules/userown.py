"""Giữ file thuộc quyền người dùng (deck) khi plugin chạy bằng root.

Plugin Wesdecky cần quyền root cho eGPU (ghi /sys) và DNS (nmcli). Phần Việt hóa thì
ghi vào thư mục game, ~/VietHoa và thư mục dữ liệu của plugin. Nếu để nguyên, các file
đó sẽ thuộc root và Steam (chạy bằng user deck) không cập nhật hay xóa được game.
Module này đổi chủ các file mới tạo về user, và cho tiến trình con chạy bằng user.
"""
import os

import decky


def is_root() -> bool:
    return hasattr(os, "geteuid") and os.geteuid() == 0


def user_ids():
    """(uid, gid) của người dùng, lấy theo chủ thư mục home. None nếu không xác định được."""
    try:
        st = os.stat(decky.DECKY_USER_HOME)
        return st.st_uid, st.st_gid
    except (OSError, AttributeError):
        return None


def _needs_fix(ids) -> bool:
    return bool(ids) and is_root() and ids[0] != 0


def own(path: str):
    """Đổi chủ một file/thư mục do root tạo về người dùng."""
    ids = user_ids()
    if not _needs_fix(ids):
        return
    try:
        st = os.lstat(path)
        if st.st_uid == 0:
            os.lchown(path, *ids)
    except OSError:
        pass


def own_with_parents(path: str, base: str):
    """Đổi chủ path và các thư mục cha của nó (dừng ở base, không đụng tới base)."""
    if not _needs_fix(user_ids()):
        return
    base = os.path.realpath(base)
    own(path)
    d = os.path.dirname(os.path.abspath(path))
    while d.startswith(base + os.sep):
        own(d)
        d = os.path.dirname(d)


def own_tree(root: str):
    """Đổi chủ mọi file/thư mục thuộc root nằm trong root (gồm cả root)."""
    if not _needs_fix(user_ids()) or not os.path.lexists(root):
        return
    own(root)
    for dp, dns, fns in os.walk(root):
        for n in dns + fns:
            own(os.path.join(dp, n))


def as_user_kwargs() -> dict:
    """Tham số cho subprocess để tiến trình con chạy bằng user thay vì root."""
    ids = user_ids()
    if not _needs_fix(ids):
        return {}
    return {"user": ids[0], "group": ids[1], "extra_groups": []}


def user_uid() -> int:
    ids = user_ids()
    return ids[0] if ids else os.getuid()
