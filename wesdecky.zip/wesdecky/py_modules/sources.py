"""
Các nguồn tìm bản Việt hóa.

- Nhóm dịch có sẵn (đáng tin): The Red Team, Cánh Cụt Team, Phù Sa Team.
- Nguồn người dùng tự thêm (đáng tin, vì người dùng chọn): tìm bằng công cụ tìm kiếm với site:<tên miền>.
- Tìm trên web (chưa kiểm chứng): kết quả từ trang lạ chỉ được tải về, không tự cài.
"""
import html
import json
import os
import re
import unicodedata
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

import decky

import downloader as dl
import mirror

BUILTIN = [
    {"id": "trt", "name": "The Red Team", "url": "https://theredteam.vn"},
    {"id": "mirror", "name": "Kho chung (bản lưu Việt hóa miễn phí)", "url": ""},
    {"id": "canhcut", "name": "Cánh Cụt Team", "url": "https://canhcutteam.com"},
    {"id": "phusa", "name": "Phù Sa Team", "url": "https://phusa.team"},
    {"id": "web", "name": "Tìm trên web (nguồn lạ, chỉ tải về)", "url": ""},
]

# Cánh Cụt mã hóa gói Việt hóa và chỉ cho cài qua launcher có đăng nhập: tắt sẵn, bật lại được.
DEFAULT_DISABLED = ["canhcut"]

# Trang không phải nơi phát hành bản Việt hóa (video, mạng xã hội, cửa hàng, bách khoa...)
SKIP_HOSTS = re.compile(
    r"(^|\.)(youtube\.com|youtu\.be|facebook\.com|fb\.com|tiktok\.com|instagram\.com|twitter\.com|x\.com|"
    r"wikipedia\.org|steampowered\.com|steamcommunity\.com|reddit\.com|google\.[a-z.]+|bing\.com|"
    r"duckduckgo\.com|epicgames\.com|gog\.com|pinterest\.[a-z.]+|threads\.net|zalo\.me)$",
    re.I,
)
VIET_WORDS = re.compile(r"vi[eệ]t\s*h[oó]a|viet-?hoa|vi[eệ]t\s*ng[uữ]|ti[eế]ng\s*vi[eệ]t|viethoa", re.I)


# -------------------------------------------------------------- cài đặt ---
def _settings_path():
    return os.path.join(decky.DECKY_PLUGIN_RUNTIME_DIR, "sources.json")


def load_settings():
    try:
        with open(_settings_path(), encoding="utf-8") as f:
            s = json.load(f)
    except (OSError, ValueError):
        s = {}
    s.setdefault("disabled", list(DEFAULT_DISABLED))
    s.setdefault("custom", [])
    s.setdefault("mirror_index", mirror.DEFAULT_INDEX)
    return s


def _save_settings(s):
    os.makedirs(os.path.dirname(_settings_path()), exist_ok=True)
    with open(_settings_path(), "w", encoding="utf-8") as f:
        json.dump(s, f, ensure_ascii=False, indent=1)


def list_sources():
    s = load_settings()
    out = []
    for b in BUILTIN:
        url = s["mirror_index"] if b["id"] == "mirror" else b["url"]
        out.append({**b, "url": url, "builtin": True, "trusted": b["id"] != "web",
                    "enabled": b["id"] not in s["disabled"]})
    for c in s["custom"]:
        out.append({**c, "builtin": False, "trusted": True, "enabled": c["id"] not in s["disabled"]})
    return out


def set_enabled(source_id, enabled):
    s = load_settings()
    s["disabled"] = [x for x in s["disabled"] if x != source_id]
    if not enabled:
        s["disabled"].append(source_id)
    _save_settings(s)
    return list_sources()


def _host(url):
    return urllib.parse.urlparse(url).netloc.lower().removeprefix("www.")


def add_source(url, name=""):
    url = url.strip()
    if not re.match(r"^https?://", url):
        url = "https://" + url
    host = _host(url)
    if not re.match(r"^[a-z0-9.-]+\.[a-z]{2,}$", host):
        raise RuntimeError("Địa chỉ trang không hợp lệ")
    if SKIP_HOSTS.search(host):
        raise RuntimeError("Trang này không phải nơi phát hành bản Việt hóa")
    if any(_host(b["url"]) == host for b in BUILTIN if b["url"]):
        raise RuntimeError("Nguồn này đã có sẵn")
    s = load_settings()
    sid = "custom:" + host
    s["custom"] = [c for c in s["custom"] if c["id"] != sid]
    s["custom"].append({"id": sid, "name": name.strip() or host, "url": f"https://{host}"})
    _save_settings(s)
    return list_sources()


def mirror_index():
    return load_settings()["mirror_index"]


def set_mirror_index(url):
    url = url.strip()
    if url and not url.startswith("https://"):
        raise RuntimeError("Link danh sách kho chung phải bắt đầu bằng https://")
    s = load_settings()
    s["mirror_index"] = url or mirror.DEFAULT_INDEX
    _save_settings(s)
    mirror._cache["url"] = None
    return list_sources()


def search_mirror(names, appid):
    games = mirror.load_index(mirror_index())
    out = []
    for e in mirror.find(games, appid, names):
        ver = f" {e['version']}" if e.get("version") else ""
        out.append({"title": f"{e['game']}{ver} – bản lưu của {e['team']}", "url": mirror.ref(e)})
    return out


def remove_source(source_id):
    s = load_settings()
    s["custom"] = [c for c in s["custom"] if c["id"] != source_id]
    s["disabled"] = [x for x in s["disabled"] if x != source_id]
    _save_settings(s)
    return list_sources()


# -------------------------------------------------------------- tìm kiếm ---
def _names(game_name):
    names = [game_name]
    short = re.split(r"\s*[:\-–]\s+", game_name)[0]
    if short != game_name:
        names.append(short)
    return [re.sub(r"[™®©]", "", n).strip() for n in names]


def _plain(text):
    text = re.sub(r"['’`]", "", text)  # Dragon's → Dragons
    text = unicodedata.normalize("NFKD", text.replace("đ", "d").replace("Đ", "D"))
    return re.sub(r"[^a-z0-9]+", " ", text.encode("ascii", "ignore").decode().lower()).strip()


def _mentions(text, name):
    """Chữ trên trang có nhắc tới tên game (bỏ dấu, không phân biệt hoa thường)."""
    words = [w for w in _plain(name).split() if len(w) > 1 or w.isdigit()]
    plain = " " + _plain(text) + " "
    return bool(words) and all(f" {w} " in plain for w in words)


def search_trt(names, opener):
    tried = set()
    for n in names:
        slug = dl._slugify(n)
        for cand in (f"{slug}-viet-hoa", slug):
            if not slug or cand in tried:
                continue
            tried.add(cand)
            try:
                final, page = dl._get_text(f"https://theredteam.vn/{cand}", opener)
            except Exception:  # noqa: BLE001
                continue
            t = dl._title(page)
            if "RED TEAM" in t.upper() and ("VIỆT" in t.upper() or "VIET" in t.upper()):
                return [{"title": t, "url": final}]
    return []


def search_canhcut(names, opener):
    out, seen = [], set()
    for n in names:
        q = urllib.parse.quote_plus(n)
        try:
            final, page = dl._get_text(f"https://canhcutteam.com/?s={q}&post_type=product", opener)
        except Exception:  # noqa: BLE001
            continue
        for link in re.findall(r"https://canhcutteam\.com/games/[^\"'#?\s<>]+/", final + " " + page):
            if link in seen or "/games/page/" in link:
                continue
            seen.add(link)
            slug = urllib.parse.unquote(link.rstrip("/").rsplit("/", 1)[-1])
            title = slug.replace("-", " ").title()
            if not _mentions(title, n):  # ô tìm kiếm của trang trả cả game không liên quan
                continue
            out.append({"title": title, "url": link})
            if len(out) >= 6:
                return out
        if out:
            return out
    return out


def search_phusa(names, opener):
    for n in names:
        slug = re.sub(r"[^a-z0-9]+", "_", _plain(n)).strip("_")
        if not slug:
            continue
        try:
            final, page = dl._get_text(f"https://phusa.team/games/{slug}", opener)
        except Exception:  # noqa: BLE001
            continue
        if _mentions(dl._visible_text(page), n):
            return [{"title": dl._title(page) or n, "url": final}]
    return []


def _unwrap(href):
    """Lấy link thật từ link chuyển hướng của công cụ tìm kiếm."""
    href = html.unescape(href)
    if href.startswith("//"):
        href = "https:" + href
    q = urllib.parse.urlparse(href)
    if "duckduckgo.com" in q.netloc and q.path.startswith("/l/"):
        return urllib.parse.parse_qs(q.query).get("uddg", [href])[0]
    ru = re.search(r"/RU=([^/]+)/", href)
    if "yahoo.com" in q.netloc and ru:
        return urllib.parse.unquote(ru.group(1))
    return href


def _clean_title(text):
    text = re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", text))).strip()
    # Yahoo ghi kèm "tên miền https://tên-miền › đường › dẫn" trước tiêu đề
    return re.sub(r"^\S+\s+https?://\S+(\s+›\s+\S+)*\s+", "", text).strip()


def _parse_ddg(page):
    for m in re.finditer(r'<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', page, re.S | re.I):
        yield m.group(1), m.group(2)


def _parse_yahoo(page):
    for m in re.finditer(r'<a\b([^>]*)>(.*?)</a>', page, re.S | re.I):
        attrs = m.group(1)
        h = re.search(r'href="([^"]+)"', attrs)
        if h and 'data-matarget="algo"' in attrs and "/RU=" in h.group(1):
            yield h.group(1), m.group(2)


def _parse_bing(page):
    for m in re.finditer(r'<li class="b_algo"[^>]*>.*?<h2[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>(.*?)</a>', page, re.S | re.I):
        yield m.group(1), m.group(2)


ENGINES = [
    ("https://html.duckduckgo.com/html/?q={q}", _parse_ddg),
    ("https://search.yahoo.com/search?p={q}", _parse_yahoo),
    ("https://www.bing.com/search?setlang=vi&q={q}", _parse_bing),
]


def web_search(query, opener, limit=10):
    """Tìm bằng DuckDuckGo → Yahoo → Bing (cái nào chạy được thì dùng). Trả về [(tiêu đề, link)]."""
    for url, parse in ENGINES:
        try:
            _, page = dl._get_text(url.format(q=urllib.parse.quote_plus(query)), opener)
        except Exception as e:  # noqa: BLE001
            decky.logger.warning(f"web search failed {url}: {e}")
            continue
        out = []
        for href, text in parse(page):
            link = _unwrap(href)
            title = _clean_title(text)
            host = _host(link)
            if link.startswith("http") and title and not re.search(r"(^|\.)(bing|yahoo|duckduckgo)\.com$", host):
                out.append((title, link))
            if len(out) >= limit:
                break
        if out:
            return out
    return []


def search_web(names, opener, known_hosts):
    out, seen = [], set()
    for title, link in web_search(f'"{names[-1]}" việt hóa', opener, 15):
        host = _host(link)
        if (host in known_hosts or SKIP_HOSTS.search(host) or link in seen
                or dl.NOT_TRANSLATION.search(title) or dl.NOT_TRANSLATION.search(link)):
            continue
        if not (VIET_WORDS.search(title) or VIET_WORDS.search(urllib.parse.unquote(link))):
            continue
        if not any(_mentions(title + " " + urllib.parse.unquote(link).replace("-", " "), n) for n in names):
            continue
        seen.add(link)
        out.append({"title": title, "url": link, "host": host})
        if len(out) >= 6:
            break
    return out


def search_custom(src, names, opener):
    host = _host(src["url"])
    out = []
    for title, link in web_search(f'site:{host} "{names[-1]}"', opener, 10):
        if _host(link) != host and not _host(link).endswith("." + host):
            continue
        if dl.NOT_TRANSLATION.search(title) or dl.NOT_TRANSLATION.search(link):
            continue
        if any(_mentions(title + " " + urllib.parse.unquote(link).replace("-", " "), n) for n in names):
            out.append({"title": title, "url": link})
        if len(out) >= 4:
            break
    return out


def search_all(game_name, appid=""):
    """Tìm ở mọi nguồn đang bật (chạy song song). Kết quả nguồn đáng tin đứng trước."""
    names = _names(game_name)
    sources = [s for s in list_sources() if s["enabled"]]
    sources.sort(key=lambda s: s["id"] == "web")  # nguồn lạ luôn xếp cuối
    known = {_host(s["url"]) for s in list_sources() if s["url"] and s["id"] != "mirror"}

    def run(src):
        opener = dl._opener()
        try:
            if src["id"] == "trt":
                res = search_trt(names, opener)
            elif src["id"] == "mirror":
                res = search_mirror(names, appid)
            elif src["id"] == "canhcut":
                res = search_canhcut(names, opener)
            elif src["id"] == "phusa":
                res = search_phusa(names, opener)
            elif src["id"] == "web":
                res = search_web(names, opener, known)
            else:
                res = search_custom(src, names, opener)
        except Exception as e:  # noqa: BLE001
            decky.logger.warning(f"search {src['id']} failed: {e}")
            res = []
        name = {"web": None, "mirror": "Kho chung"}.get(src["id"], src["name"])
        return [{"source": name or r.get("host", "web"), "title": r["title"], "url": r["url"],
                 "trusted": src["trusted"], "source_id": src["id"]} for r in res]

    with ThreadPoolExecutor(max_workers=max(1, len(sources))) as ex:
        groups = list(ex.map(run, sources))
    results, seen = [], set()
    for g in groups:  # giữ thứ tự nguồn: nhóm có sẵn → tự thêm → web
        for r in g:
            if r["url"] not in seen:
                seen.add(r["url"])
                results.append(r)
    return results
