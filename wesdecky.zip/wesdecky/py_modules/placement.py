"""
Tìm đúng chỗ đặt file Việt hóa trong thư mục game.

Bản Việt hóa thường được làm trên Windows, nơi tên file không phân biệt hoa/thường, và được
nén theo đủ kiểu: có/không có thư mục bọc ngoài, kèm file hướng dẫn, hoặc chỉ gồm vài file nằm
sâu trong thư mục con của game. Module này so khớp cấu trúc bản Việt hóa với file có thật trong
game để quyết định chép vào đâu, và báo khi không chắc chắn.
"""
import os
import re

SOURCE_FILE = ".viethoa-source.json"
MAX_DEPTH = 5

DOC_NAME = re.compile(
    r"read\s*me|huong\s*dan|hướng\s*dẫn|hdcai|hd[ _-]|cach\s*cai|cách\s*cài|credit|thong\s*tin|thông\s*tin|"
    r"changelog|license|ung\s*ho|ủng\s*hộ|donate|link|lien\s*he|liên\s*hệ|install(ation)?\s*guide|cai\s*dat|cài\s*đặt",
    re.I,
)
DOC_ALWAYS = (".url", ".lnk", ".webloc", ".desktop")
DOC_IF_NAMED = (".txt", ".pdf", ".doc", ".docx", ".rtf", ".html", ".htm", ".md", ".png", ".jpg", ".jpeg", ".gif", ".webp")
UNREAL_PAK = (".pak", ".utoc", ".ucas", ".sig")
# Tên thư mục thường có thật trong game: không coi là thư mục bọc ngoài.
GAME_DIRS = {
    "fonts", "font", "data", "content", "paks", "~mods", "mods", "streamingassets", "localization", "localisation",
    "loc", "text", "texts", "lang", "language", "languages", "managed", "plugins", "bepinex", "www", "assets",
    "resources", "bin", "binaries", "x64", "win64", "movies", "sound", "audio", "scripts", "translation", "i18n",
}


def is_doc(name: str) -> bool:
    low = name.lower()
    if low.endswith(DOC_ALWAYS):
        return True
    return low.endswith(DOC_IF_NAMED) and bool(DOC_NAME.search(os.path.splitext(name)[0]))


class GameIndex:
    """Danh sách file/thư mục trong game, tra cứu không phân biệt hoa/thường."""

    def __init__(self, game_path: str, limit: int = 300000):
        self.path = game_path
        self.entries = {}  # đường dẫn chữ thường -> đường dẫn thật (dùng "/")
        self.dirs = set()  # đường dẫn chữ thường của thư mục
        self.by_name = {}  # tên chữ thường -> [đường dẫn thật]
        n = 0
        for dp, dns, fns in os.walk(game_path):
            rel_dir = os.path.relpath(dp, game_path).replace(os.sep, "/")
            rel_dir = "" if rel_dir == "." else rel_dir
            for d in dns:
                real = f"{rel_dir}/{d}" if rel_dir else d
                self.entries[real.lower()] = real
                self.dirs.add(real.lower())
                self.by_name.setdefault(d.lower(), []).append(real)
            for f in fns:
                real = f"{rel_dir}/{f}" if rel_dir else f
                self.entries[real.lower()] = real
                self.by_name.setdefault(f.lower(), []).append(real)
            n += len(dns) + len(fns)
            if n > limit:
                break

    def has(self, rel: str) -> bool:
        return rel.lower() in self.entries

    def is_dir(self, rel: str) -> bool:
        return rel == "" or rel.lower() in self.dirs

    def resolve(self, rel: str) -> str:
        """Đổi đường dẫn sang đúng chữ hoa/thường của file/thư mục có thật; phần chưa có giữ nguyên."""
        parts = [p for p in rel.split("/") if p]
        out = []
        for i, part in enumerate(parts):
            cand = "/".join(out + [part])
            real = self.entries.get(cand.lower())
            if real is None:
                return "/".join(out + parts[i:])
            out = real.split("/")
        return "/".join(out)

    def subdirs(self, max_depth: int = 2, limit: int = 60) -> list:
        res = sorted((r for k, r in self.entries.items() if k in self.dirs and r.count("/") < max_depth),
                     key=lambda r: (r.count("/"), r.lower()))
        return res[:limit]


def _patch_files(root: str) -> list:
    out = []
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if not d.startswith(".")]
        rel_dir = os.path.relpath(dp, root).replace(os.sep, "/")
        rel_dir = "" if rel_dir == "." else rel_dir
        for f in fns:
            if f == SOURCE_FILE:
                continue
            out.append(f"{rel_dir}/{f}" if rel_dir else f)
    return out


def _join(a: str, b: str) -> str:
    return f"{a}/{b}" if a else b


def _under(files: list, prefix: str) -> list:
    if not prefix:
        return list(files)
    p = prefix + "/"
    return [f[len(p):] for f in files if f.startswith(p)]


def _wrapper_prefix(files: list, index: GameIndex) -> str:
    """Bỏ các thư mục bọc ngoài (bỏ qua file hướng dẫn) chừng nào chúng không phải thư mục có thật trong game."""
    prefix = ""
    while True:
        sub = _under(files, prefix)
        real = [f for f in sub if not ("/" not in f and is_doc(f))]
        tops = {f.split("/", 1)[0] for f in real}
        if len(tops) != 1 or any("/" not in f for f in real):
            return prefix
        top = tops.pop()
        if index.is_dir(top) or top.lower() in GAME_DIRS or top.lower().endswith("_data"):
            return prefix
        prefix = _join(prefix, top)


def _score(sub: list, target: str, index: GameIndex):
    """(số file trùng file có sẵn, số file nằm trong thư mục con có sẵn của game, số file nằm trong thư mục con)."""
    files = dirs = nested = 0
    for f in sub:
        if index.has(_join(target, f)):
            files += 1
        if "/" in f:
            nested += 1
            if index.is_dir(_join(target, f.rsplit("/", 1)[0])):
                dirs += 1
    return files, dirs, nested


def _targets_for(sub: list, index: GameIndex) -> list:
    """Các thư mục trong game có thể là nơi đặt bản Việt hóa."""
    targets = [""]
    tops = {f.split("/", 1)[0] for f in sub}
    for top in tops:
        for real in index.by_name.get(top.lower(), [])[:20]:
            parent = real.rsplit("/", 1)[0] if "/" in real else ""
            if parent not in targets:
                targets.append(parent)
    return targets


def plan(patch_root: str, game_path: str, auto: bool = True, target_override=None) -> dict:
    """
    Trả về kế hoạch chép:
      prefix  : thư mục bên trong bản Việt hóa được dùng làm gốc
      target  : thư mục bên trong game sẽ chép vào ("" = thư mục gốc của game)
      files   : [(đường dẫn trong bản Việt hóa, đường dẫn thật trong game)]
      matched : số file ghi đè file có sẵn của game
      skipped : file hướng dẫn không chép
      confident: True nếu chắc chắn đúng chỗ
      reason  : giải thích ngắn
    """
    index = GameIndex(game_path)
    files = _patch_files(patch_root)
    if not files:
        raise RuntimeError("Bản Việt hóa trống")

    best = None  # (điểm, -độ sâu prefix, -độ sâu target, prefix, target)
    reason = ""
    if auto:
        prefixes = {""}
        for f in files:
            parts = f.split("/")[:-1]
            for i in range(1, min(len(parts), MAX_DEPTH) + 1):
                prefixes.add("/".join(parts[:i]))
        for prefix in prefixes:
            sub = _under(files, prefix)
            if not sub:
                continue
            for target in _targets_for(sub, index):
                fm, dm, nested = _score(sub, target, index)
                key = (fm, dm, -prefix.count("/") - (1 if prefix else 0), -target.count("/") - (1 if target else 0))
                ok = fm > 0 or (dm > 0 and dm == nested)
                if best is None or key > best[0]:
                    best = (key, prefix, target, ok)

    if target_override is not None:
        prefix = best[1] if best and best[3] else (_wrapper_prefix(files, index) if auto else "")
        target = index.resolve(target_override.strip("/"))
        if target and not index.is_dir(target):
            raise RuntimeError(f"Không có thư mục '{target_override}' trong game")
        confident, reason = True, "Thư mục do bạn chọn"
    elif best and best[3]:
        _, prefix, target, _ok = best
        confident = True
        reason = "Khớp với file có sẵn trong game" if best[0][0] else "Khớp với thư mục có sẵn trong game"
    else:
        prefix = _wrapper_prefix(files, index) if auto else ""
        sub = _under(files, prefix)
        target, confident = "", False
        reason = "Không khớp file nào trong game"
        payload = [f for f in sub if not ("/" not in f and is_doc(f))]
        if auto and payload and all(f.lower().endswith(UNREAL_PAK) and "/" not in f for f in payload):
            paks = sorted({r.rsplit("/", 1)[0] for k, r in index.entries.items()
                           if k.endswith(".pak") and "/" in r and "/paks" in k})
            mods = [p for p in paks if p.lower().endswith("/paks/~mods")]
            base = [p for p in paks if p.lower().endswith("/content/paks")]
            pick = mods[0] if len(mods) == 1 else (base[0] if len(base) == 1 else None)
            if pick is None and len(base) == 1:
                pick = base[0]
            if pick:
                target, confident, reason = pick, True, "File .pak của Unreal Engine: đặt vào thư mục Paks của game"

    sub = _under(files, prefix)
    out, matched = [], 0
    skipped = [f for f in files if prefix and not f.startswith(prefix + "/")]
    for f in sub:
        dst_rel = _join(target, f)
        if "/" not in f and is_doc(f) and not index.has(dst_rel):
            skipped.append(f)
            continue
        if index.has(dst_rel):
            matched += 1
        out.append((_join(prefix, f), index.resolve(dst_rel)))
    if not out:
        raise RuntimeError("Bản Việt hóa chỉ có file hướng dẫn, không có gì để chép")
    return {
        "prefix": prefix,
        "target": target,
        "files": out,
        "matched": matched,
        "new": len(out) - matched,
        "skipped": skipped,
        "confident": confident,
        "reason": reason,
        "dirs": index.subdirs(),
    }


def summary(p: dict) -> dict:
    """Bản tóm tắt gửi lên giao diện."""
    return {
        "target": p["target"],
        "count": len(p["files"]),
        "matched": p["matched"],
        "new": p["new"],
        "skipped": p["skipped"][:10],
        "confident": p["confident"],
        "reason": p["reason"],
        "sample": [d for _s, d in p["files"][:6]],
        "dirs": p["dirs"],
    }
