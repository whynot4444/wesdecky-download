"""eGPU Switcher (phần backend trong plugin Wesdecky).

Không đổi GPU cho toàn hệ thống. Mỗi game được gắn wrapper `egpu-run` qua Launch Options;
mỗi lần mở game, wrapper tự tìm eGPU và đặt biến môi trường để game render trên eGPU.
Rút eGPU thì game chạy trên GPU trong máy như bình thường.
"""
import glob
import os
import shutil
import subprocess

import decky

import userown

VENDORS = {"0x1002": "AMD", "0x10de": "NVIDIA", "0x8086": "Intel"}
GPU_CLASSES = ("0x0300", "0x0302", "0x0380")
DEFAULT_CONF = {"EGPU_MODE": "auto", "EGPU_TARGET": "", "EGPU_STRICT": "0"}

# Đổi được trong test.
PCI_ROOT = "/sys/bus/pci"
TB_ROOT = "/sys/bus/thunderbolt/devices"


def _home() -> str:
    return decky.DECKY_USER_HOME


def conf_dir() -> str:
    return os.path.join(_home(), ".config", "egpu-switcher")


def conf_file() -> str:
    return os.path.join(conf_dir(), "env")


def bin_dir() -> str:
    return os.path.join(_home(), ".local", "share", "egpu-switcher")


def wrapper() -> str:
    return os.path.join(bin_dir(), "egpu-run")


def log_file() -> str:
    return os.path.join(_home(), ".cache", "egpu-switcher", "last-launch.log")


def _makedirs_user(path: str):
    """Tạo thư mục (và các cấp cha nằm trong home) thuộc quyền user, không phải root."""
    os.makedirs(path, exist_ok=True)
    userown.own_with_parents(path, _home())


def _read(path: str, default: str = "") -> str:
    try:
        with open(path) as f:
            return f.read().strip()
    except Exception:
        return default


def _lspci_name(slot: str) -> str:
    try:
        out = subprocess.run(["lspci", "-s", slot, "-mm"], capture_output=True,
                             text=True, timeout=3).stdout.strip()
        # "05:00.0" "VGA compatible controller" "Advanced Micro Devices..." "Navi 21 [Radeon RX 6800]" ...
        parts = [p.strip('"') for p in out.split('" "')]
        if len(parts) >= 4:
            return parts[3].strip('"')
    except Exception:
        pass
    return ""


def scan_gpus() -> list:
    gpus = []
    for dev in sorted(glob.glob(os.path.join(PCI_ROOT, "devices", "*"))):
        cls = _read(os.path.join(dev, "class"))
        if not cls.startswith(GPU_CLASSES):
            continue
        slot = os.path.basename(dev)
        vendor = _read(os.path.join(dev, "vendor"))
        device = _read(os.path.join(dev, "device"))
        drv_link = os.path.join(dev, "driver")
        driver = os.path.basename(os.path.realpath(drv_link)) if os.path.exists(drv_link) else ""
        boot_vga = _read(os.path.join(dev, "boot_vga")) == "1"
        real = os.path.realpath(dev)
        removable = _read(os.path.join(dev, "removable")) == "removable"
        vram = 0
        v = _read(os.path.join(dev, "mem_info_vram_total"))
        if v.isdigit():
            vram = int(v) // (1024 * 1024)
        cards = [os.path.basename(c) for c in glob.glob(os.path.join(dev, "drm", "card*"))]
        name = _lspci_name(slot) or f"{VENDORS.get(vendor, vendor)} {device}"
        gpus.append({
            "slot": slot,
            "vendor": vendor,
            "vendor_name": VENDORS.get(vendor, vendor),
            "device": device,
            "name": name,
            "driver": driver,
            "internal": boot_vga,
            "external": not boot_vga,
            "thunderbolt": removable or "thunderbolt" in real,
            "vram_mb": vram,
            "card": cards[0] if cards else "",
            "ready": bool(driver),
        })
    return gpus


def read_conf() -> dict:
    conf = dict(DEFAULT_CONF)
    try:
        with open(conf_file()) as f:
            for line in f:
                line = line.strip()
                if "=" in line and not line.startswith("#"):
                    k, v = line.split("=", 1)
                    conf[k.strip()] = v.strip().strip('"')
    except FileNotFoundError:
        pass
    return conf


def write_conf(conf: dict):
    _makedirs_user(conf_dir())
    with open(conf_file(), "w") as f:
        f.write("# eGPU Switcher — tự sinh bởi plugin Wesdecky (Weirdstore.vn)\n")
        for k in ("EGPU_MODE", "EGPU_TARGET", "EGPU_STRICT"):
            f.write(f'{k}="{conf.get(k, "")}"\n')
    userown.own(conf_file())


def install_wrapper():
    src = os.path.join(decky.DECKY_PLUGIN_DIR, "bin", "egpu-run")
    _makedirs_user(bin_dir())
    shutil.copyfile(src, wrapper())
    os.chmod(wrapper(), 0o755)
    userown.own(wrapper())


class EgpuMixin:
    """Các hàm eGPU gọi từ giao diện. Tên có tiền tố egpu_ để không trùng phần khác."""

    async def _egpu_main(self):
        try:
            install_wrapper()
            if not os.path.exists(conf_file()):
                write_conf(DEFAULT_CONF)
            decky.logger.info("eGPU: wrapper ở %s", wrapper())
        except Exception:
            decky.logger.exception("eGPU: không cài được wrapper")

    async def egpu_get_state(self):
        conf = read_conf()
        return {
            "gpus": scan_gpus(),
            "mode": conf.get("EGPU_MODE", "auto"),
            "target": conf.get("EGPU_TARGET", ""),
            "strict": conf.get("EGPU_STRICT", "0") == "1",
            "wrapper": wrapper(),
            "wrapper_ok": os.access(wrapper(), os.X_OK),
        }

    async def egpu_set_config(self, mode: str, target: str, strict: bool):
        conf = read_conf()
        conf["EGPU_MODE"] = "off" if mode == "off" else "auto"
        conf["EGPU_TARGET"] = target or ""
        conf["EGPU_STRICT"] = "1" if strict else "0"
        write_conf(conf)
        return True

    async def egpu_rescan_pci(self):
        try:
            with open(os.path.join(PCI_ROOT, "rescan"), "w") as f:
                f.write("1")
            return {"ok": True, "msg": "Đã quét lại bus PCI"}
        except Exception as e:
            return {"ok": False, "msg": str(e)}

    async def egpu_authorize_thunderbolt(self):
        count = 0
        errors = []
        for dev in glob.glob(os.path.join(TB_ROOT, "*")):
            auth = os.path.join(dev, "authorized")
            if os.path.exists(auth) and _read(auth) == "0":
                try:
                    with open(auth, "w") as f:
                        f.write("1")
                    count += 1
                except Exception as e:
                    errors.append(f"{os.path.basename(dev)}: {e}")
        if shutil.which("boltctl"):
            try:
                subprocess.run(["boltctl", "list"], capture_output=True, timeout=5)
            except Exception:
                pass
        msg = f"Đã cấp quyền {count} thiết bị Thunderbolt/USB4"
        if errors:
            msg += " — lỗi: " + "; ".join(errors)
        return {"ok": not errors, "msg": msg}

    async def egpu_get_last_log(self):
        return _read(log_file(), "Chưa có lần chạy game nào qua wrapper.")


# Đăng ký với Wesdecky (main.py tự tìm các module có WD_MODULE).
WD_MODULE = {"mixin": EgpuMixin, "order": 20, "main": "_egpu_main"}
