"""Tab "Mod" của Wesdecky: duyệt, tải và cài mod từ Nexus Mods ngay trong Game Mode.

Hàm giao diện gọi có tiền tố `nx_`. Phần gọi API ở nexus_api.py, phần cài/gỡ file ở
nexus_install.py.

Dữ liệu:
    <settings>/nexus.json        API key, tài khoản, domain Nexus đã chọn cho từng game
    <settings>/nexus_mods.json   mod đã cài theo từng game + chuỗi chủ sở hữu file
    ~/NexusMods/downloads/<domain>/   file tải về (giữ lại để bật lại mod)
    ~/NexusMods/backup/<appid>/<key>/ file gốc bị mod ghi đè
"""
import asyncio
import json
import os
import re
import shutil
import threading
import time
import urllib.parse
import urllib.request

import decky
import nexus_api as api
import nexus_install as inst
import userown
from nexus_api import NexusError
from nexus_install import InstallError

SETTINGS_FILE = "nexus.json"
STATE_FILE = "nexus_mods.json"
GAMES_CACHE = "nexus_games.json"
GAMES_TTL = 7 * 86400
KEY_RE = re.compile(r"^\d{1,10}-\d{1,12}$")
APIKEY_RE = re.compile(r"^[A-Za-z0-9+/=_\-.]{20,400}$")
DEFAULTS = {"api_key": "", "user": None, "show_adult": False, "domains": {}}

_lock = threading.RLock()
_job = {"state": "idle"}
_job_cancel = threading.Event()


# --------------------------------------------------------------- tiện ích ---
def _settings_path(name):
    return os.path.join(decky.DECKY_PLUGIN_SETTINGS_DIR, name)


def _read_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, type(default)) else default
    except (OSError, ValueError):
        return default


def _write_json(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)
    userown.own(path)


def get_settings() -> dict:
    s = dict(DEFAULTS)
    s.update(_read_json(_settings_path(SETTINGS_FILE), {}))
    if not isinstance(s.get("domains"), dict):
        s["domains"] = {}
    return s


def save_settings(s: dict):
    _write_json(_settings_path(SETTINGS_FILE), s)


def _key() -> str:
    k = get_settings().get("api_key") or ""
    if not k:
        raise NexusError("no_key", "Chưa nhập API key")
    return k


def load_state() -> dict:
    st = _read_json(_settings_path(STATE_FILE), {})
    st.setdefault("games", {})
    return st


def save_state(st: dict):
    _write_json(_settings_path(STATE_FILE), st)


def data_root() -> str:
    return os.path.join(decky.DECKY_USER_HOME, "NexusMods")


def _mkdir_user(path):
    os.makedirs(path, exist_ok=True)
    userown.own_with_parents(path, decky.DECKY_USER_HOME)


def backup_dir(appid, key) -> str:
    return os.path.join(data_root(), "backup", str(int(appid)), key)


def _gstate(st, appid) -> dict:
    g = st["games"].setdefault(str(int(appid)), {})
    g.setdefault("mods", {})
    g.setdefault("owners", {})
    return g


def domain_for(appid: int):
    appid = int(appid)
    d = get_settings()["domains"].get(str(appid))
    if d:
        return d
    prof = inst.PROFILES.get(appid)
    return prof["domain"] if prof else None


def _norm(name: str) -> str:
    name = re.sub(r"[™®©:'’\-]", " ", (name or "").lower())
    name = re.sub(r"\b(the|edition|special|definitive|remastered|goty|anniversary|enhanced)\b", " ", name)
    return re.sub(r"[^a-z0-9]+", "", name)


def nexus_games() -> list:
    path = os.path.join(decky.DECKY_PLUGIN_RUNTIME_DIR, GAMES_CACHE)
    c = _read_json(path, {})
    if c.get("time", 0) > time.time() - GAMES_TTL and c.get("games"):
        return c["games"]
    games = api.games(_key())
    try:
        _write_json(path, {"time": time.time(), "games": games})
    except OSError:
        pass
    return games


def guess_domain(name: str):
    n = _norm(name)
    if not n:
        return None
    for g in nexus_games():
        if _norm(g["name"]) == n:
            return g["domain"]
    return None


def _err(e) -> dict:
    code = getattr(e, "code", "error")
    return {"ok": False, "error": code, "detail": str(e)[:400]}


async def _nx_safe(fn, *args):
    try:
        return {"ok": True, "data": await asyncio.to_thread(fn, *args)}
    except (NexusError, InstallError) as e:
        return _err(e)
    except Exception as e:  # noqa: BLE001
        decky.logger.exception("Nexus: lỗi")
        return {"ok": False, "error": "error", "detail": str(e)[:400]}


# ----------------------------------------------------------- công việc ---
def settings_view() -> dict:
    s = get_settings()
    k = s.get("api_key") or ""
    return {"has_key": bool(k), "key_tail": k[-4:] if k else "", "user": s.get("user"),
            "show_adult": bool(s.get("show_adult")), "data_dir": data_root()}


def set_key(key: str) -> dict:
    key = (key or "").strip()
    if not APIKEY_RE.match(key):
        raise NexusError("bad_key_format", "API key không hợp lệ")
    user = api.validate(key)
    with _lock:
        s = get_settings()
        s["api_key"] = key
        s["user"] = {"name": user["name"], "is_premium": user["is_premium"]}
        save_settings(s)
    return settings_view()


def clear_key() -> dict:
    with _lock:
        s = get_settings()
        s["api_key"] = ""
        s["user"] = None
        save_settings(s)
    return settings_view()


def list_games() -> list:
    st = load_state()
    out = []
    for g in inst.installed_games():
        gs = st["games"].get(str(g["appid"]), {})
        out.append({"appid": g["appid"], "name": g["name"], "domain": domain_for(g["appid"]),
                    "profile": g["profile"], "mods": len(gs.get("mods", {}))})
    return out


def set_domain(appid: int, domain: str):
    domain = (domain or "").strip().lower()
    if domain and not api.DOMAIN_RE.match(domain):
        raise NexusError("bad_domain", domain)
    with _lock:
        s = get_settings()
        if domain:
            s["domains"][str(int(appid))] = domain
        else:
            s["domains"].pop(str(int(appid)), None)
        save_settings(s)
    return domain_for(appid)


def guess_for(appid: int):
    g = inst.find_game(appid)
    return guess_domain(g["name"])


def _filter(mods: list) -> list:
    adult = get_settings().get("show_adult")
    return [m for m in mods if m.get("mod_id") and m.get("available", True) and (adult or not m.get("adult"))]


def browse(domain: str, kind: str) -> list:
    return _filter(api.mod_list(_key(), domain, kind))


def search(domain: str, term: str) -> list:
    k = _key()
    ref = api.parse_mod_ref(term, domain)
    if ref:
        return _filter([api.mod_info(k, domain, ref)])
    return _filter(api.search(k, domain, term))


def mod_detail(domain: str, mod_id: int) -> dict:
    k = _key()
    info = api.mod_info(k, domain, int(mod_id))
    files = api.mod_files(k, domain, int(mod_id))
    return {"mod": info, "files": files["files"], "url": f"https://www.nexusmods.com/{domain}/mods/{int(mod_id)}?tab=files"}


def installed(appid: int) -> list:
    st = load_state()
    g = st["games"].get(str(int(appid)), {})
    out = []
    for key, m in g.get("mods", {}).items():
        out.append({k: m.get(k) for k in ("key", "mod_id", "file_id", "domain", "name", "file_name", "version",
                                          "enabled", "installed_at", "plugins", "where", "guess", "update")}
                   | {"files": len((m.get("install") or {}).get("files", {})) or m.get("file_count", 0)})
    out.sort(key=lambda m: m.get("installed_at") or 0)
    return out


def _safe_name(name: str, fallback: str) -> str:
    n = re.sub(r"[^\w .()+\-\[\]]", "_", os.path.basename(name or "")).strip(" .")
    return n[:150] or fallback


def _download(url: str, dest: str, progress):
    """Tải từ CDN. Không gửi API key."""
    req = urllib.request.Request(url, headers={"User-Agent": f"{api.APP_NAME}/{api.APP_VERSION}"})
    tmp = dest + ".part"
    with urllib.request.urlopen(req, timeout=60, context=api.ssl_context()) as r, open(tmp, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        while True:
            if _job_cancel.is_set():
                raise InstallError("cancelled")
            chunk = r.read(1 << 18)
            if not chunk:
                break
            f.write(chunk)
            done += len(chunk)
            progress(done, total)
    os.replace(tmp, dest)
    userown.own(dest)


def _place(appid: int, key: str, archive: str, stem: str, cancel=None) -> dict:
    """Giải nén và chép vào game. Trả về bản ghi install + thông tin plan."""
    game = inst.find_game(appid)
    work = os.path.join(data_root(), ".work", key)
    shutil.rmtree(work, ignore_errors=True)
    try:
        inst.extract(archive, work)
        if inst.has_fomod(work):
            raise InstallError("fomod", "Mod có trình cài FOMOD, bản này chưa hỗ trợ")
        p = inst.plan(work, appid, stem)
        files = inst.collect(p["items"])
        if not files:
            raise InstallError("empty_archive")
        st = load_state()
        g = _gstate(st, appid)
        bdir = backup_dir(appid, key)
        shutil.rmtree(bdir, ignore_errors=True)
        rec = {"files": {}, "backed": {}, "dirs": []}
        try:
            inst.install_files(game["path"], files, key, g, bdir, cancel, rec=rec)
        except Exception:
            inst.uninstall_files(game["path"], key, rec, g, {key: bdir})  # gỡ phần đã chép dở
            raise
        names = inst.plugin_names(rec, appid)
        plug = inst.update_plugins(appid, add=names)
        return {"rec": rec, "where": p["where"], "guess": p["guess"], "plugins": names, "plugins_status": plug,
                "owners": g["owners"]}
    finally:
        shutil.rmtree(work, ignore_errors=True)


def _commit_install(appid, key, meta, placed):
    with _lock:
        st = load_state()
        g = _gstate(st, appid)
        g["owners"] = placed["owners"]
        m = g["mods"].get(key, {})
        m.update(meta)
        m.update({"key": key, "enabled": True, "install": placed["rec"], "where": placed["where"],
                  "guess": placed["guess"], "plugins": placed["plugins"],
                  "file_count": len(placed["rec"]["files"])})
        m.setdefault("installed_at", time.time())
        m.pop("update", None)
        g["mods"][key] = m
        save_state(st)


def _remove_files(appid, key, keep_record: bool) -> dict:
    game = inst.find_game(appid)
    st = load_state()
    g = _gstate(st, appid)
    m = g["mods"].get(key)
    if not m:
        raise InstallError("not_installed", key)
    res = {"restored": 0, "removed": 0, "kept": []}
    if m.get("install"):
        bdirs = {k: backup_dir(appid, k) for k in g["mods"]}
        res = inst.uninstall_files(game["path"], key, m["install"], g, bdirs)
        inst.update_plugins(appid, remove=m.get("plugins") or [])
        m["install"] = None
    m["enabled"] = False
    if not keep_record:
        g["mods"].pop(key, None)
    save_state(st)
    return res


def set_enabled(appid: int, key: str, enabled: bool) -> dict:
    if not KEY_RE.match(key or ""):
        raise InstallError("bad_key", key)
    with _lock:
        m = load_state()["games"].get(str(int(appid)), {}).get("mods", {}).get(key)
        if not m:
            raise InstallError("not_installed", key)
        if not enabled:
            return _remove_files(appid, key, keep_record=True)
        if m.get("enabled"):
            return {}
        archive = m.get("archive") or ""
        if not os.path.isfile(archive):
            raise InstallError("archive_missing", "File tải về đã bị xóa, hãy tải lại mod")
        placed = _place(appid, key, archive, _stem(m))
        _commit_install(appid, key, {}, placed)
        return {"where": placed["where"], "guess": placed["guess"], "plugins_status": placed["plugins_status"]}


def remove(appid: int, key: str, delete_archive: bool) -> dict:
    if not KEY_RE.match(key or ""):
        raise InstallError("bad_key", key)
    with _lock:
        m = load_state()["games"].get(str(int(appid)), {}).get("mods", {}).get(key) or {}
        res = _remove_files(appid, key, keep_record=False)
        a = m.get("archive") or ""
        if delete_archive and a and inst._inside(os.path.join(data_root(), "downloads"), a):
            try:
                os.unlink(a)
            except OSError:
                pass
        return res


def _stem(m) -> str:
    base = os.path.splitext(m.get("file_name") or "")[0]
    return re.sub(r"[^\w]+", "", base)[:40] or f"mod{m.get('mod_id')}"


def check_updates(appid: int) -> list:
    k = _key()
    out = []
    with _lock:
        st = load_state()
        mods = dict(_gstate(st, appid)["mods"])
    for key, m in mods.items():
        try:
            files = api.mod_files(k, m["domain"], m["mod_id"])
        except NexusError as e:
            if e.code in ("bad_key", "rate_limited", "offline"):
                raise
            continue
        new = api.newest_replacement(files["updates"], m["file_id"])
        nf = next((f for f in files["files"] if f["file_id"] == new), None) if new else None
        if not nf:
            same_cat = [f for f in files["files"] if f["category"] == "MAIN" and f["file_id"] != m["file_id"]
                        and f["uploaded"] > (m.get("uploaded") or 0) and f["name"] == m.get("file_title")]
            nf = same_cat[0] if same_cat else None
        upd = {"file_id": nf["file_id"], "version": nf["version"], "name": nf["name"]} if nf else None
        with _lock:
            st = load_state()
            mm = _gstate(st, appid)["mods"].get(key)
            if mm is not None:
                mm["update"] = upd
                save_state(st)
        if upd:
            out.append({"key": key, "name": m.get("name"), **upd})
    return out


# -------------------------------------------------------- tải + cài nền ---
def _set_job(**kw):
    with _lock:
        _job.update(kw)


def _run_job(appid, domain, mod_id, file_id, nxm, replace):
    key = f"{mod_id}-{file_id}"
    try:
        k = _key()
        _set_job(phase="info")
        info = api.mod_info(k, domain, mod_id)
        files = api.mod_files(k, domain, mod_id, all_files=True)["files"]
        f = next((x for x in files if x["file_id"] == file_id), None)
        if not f:
            raise NexusError("not_found", "Không thấy file trên Nexus")
        _set_job(phase="link", name=info["name"])
        if nxm:
            links = api.download_links(k, domain, mod_id, file_id, nxm["key"], nxm["expires"])
        else:
            if not (get_settings().get("user") or {}).get("is_premium"):
                raise NexusError("need_premium", "Tài khoản free cần dán link nxm://")
            links = api.download_links(k, domain, mod_id, file_id)
        ddir = os.path.join(data_root(), "downloads", domain)
        _mkdir_user(ddir)
        archive = os.path.join(ddir, f"{mod_id}-{file_id}-" + _safe_name(f["file_name"], "mod.zip"))
        if not os.path.isfile(archive):
            _set_job(phase="download", done=0, total=f["size_kb"] * 1024)
            last = None
            for link in links:
                try:
                    _download(link["url"], archive, lambda d, t: _set_job(done=d, total=t or _job.get("total", 0)))
                    last = None
                    break
                except InstallError:
                    raise
                except Exception as e:  # noqa: BLE001
                    last = e
            if last:
                raise NexusError("download_failed", str(last))
        if _job_cancel.is_set():
            raise InstallError("cancelled")
        _set_job(phase="install")
        with _lock:
            if replace and KEY_RE.match(replace) and replace != key:
                old = load_state()["games"].get(str(appid), {}).get("mods", {}).get(replace)
                if old:
                    _remove_files(appid, replace, keep_record=False)
            existing = load_state()["games"].get(str(appid), {}).get("mods", {}).get(key)
            if existing and existing.get("install"):
                _remove_files(appid, key, keep_record=True)
            meta = {"mod_id": mod_id, "file_id": file_id, "domain": domain, "name": info["name"],
                    "file_name": f["file_name"], "file_title": f["name"], "version": f["version"] or info["version"],
                    "uploaded": f["uploaded"], "archive": archive, "installed_at": time.time()}
            placed = _place(int(appid), key, archive, _stem(meta), _job_cancel.is_set)
            _commit_install(int(appid), key, meta, placed)
        _set_job(state="done", phase="done", result={"key": key, "name": info["name"], "where": placed["where"],
                                                    "guess": placed["guess"], "plugins": placed["plugins"],
                                                    "plugins_status": placed["plugins_status"],
                                                    "files": len(placed["rec"]["files"])})
    except (NexusError, InstallError) as e:
        _set_job(state="error", error=e.code, detail=str(e)[:400])
    except Exception as e:  # noqa: BLE001
        decky.logger.exception("Nexus: cài lỗi")
        _set_job(state="error", error="error", detail=str(e)[:400])


def start_install(appid, domain, mod_id, file_id, nxm_link="", replace=""):
    appid = int(appid)
    nxm = None
    if nxm_link:
        nxm = api.parse_nxm(nxm_link)
        domain, mod_id, file_id = nxm["domain"], nxm["mod_id"], nxm["file_id"]
        want = domain_for(appid)
        if want and want != domain:
            raise NexusError("wrong_game", f"Link nxm là của game '{domain}', game đang chọn là '{want}'")
    if not domain or not api.DOMAIN_RE.match(domain):
        raise NexusError("bad_domain", str(domain))
    inst.find_game(appid)
    with _lock:
        if _job.get("state") == "running":
            raise InstallError("busy", "Đang tải mod khác")
        _job.clear()
        _job.update(state="running", phase="start", appid=appid, mod_id=int(mod_id), file_id=int(file_id),
                    name="", done=0, total=0, started=time.time())
        _job_cancel.clear()
    threading.Thread(target=_run_job, args=(appid, domain, int(mod_id), int(file_id), nxm, replace or ""),
                     daemon=True).start()
    return progress()


def progress() -> dict:
    with _lock:
        return dict(_job)


class NexusMixin:
    async def nx_get_settings(self):
        return await _nx_safe(settings_view)

    async def nx_set_key(self, key: str):
        return await _nx_safe(set_key, key)

    async def nx_clear_key(self):
        return await _nx_safe(clear_key)

    async def nx_set_show_adult(self, on: bool):
        def f():
            with _lock:
                s = get_settings()
                s["show_adult"] = bool(on)
                save_settings(s)
            return settings_view()
        return await _nx_safe(f)

    async def nx_games(self):
        return await _nx_safe(list_games)

    async def nx_set_domain(self, appid: int, domain: str):
        return await _nx_safe(set_domain, appid, domain)

    async def nx_guess_domain(self, appid: int):
        return await _nx_safe(guess_for, appid)

    async def nx_browse(self, domain: str, kind: str):
        return await _nx_safe(browse, domain, kind)

    async def nx_search(self, domain: str, term: str):
        return await _nx_safe(search, domain, term)

    async def nx_mod(self, domain: str, mod_id: int):
        return await _nx_safe(mod_detail, domain, mod_id)

    async def nx_install(self, appid: int, domain: str, mod_id: int, file_id: int, nxm: str = "", replace: str = ""):
        return await _nx_safe(start_install, appid, domain, mod_id, file_id, nxm, replace)

    async def nx_progress(self):
        return {"ok": True, "data": progress()}

    async def nx_cancel(self):
        _job_cancel.set()
        return {"ok": True, "data": progress()}

    async def nx_installed(self, appid: int):
        return await _nx_safe(installed, appid)

    async def nx_set_enabled(self, appid: int, key: str, enabled: bool):
        return await _nx_safe(set_enabled, appid, key, enabled)

    async def nx_remove(self, appid: int, key: str, delete_archive: bool = True):
        return await _nx_safe(remove, appid, key, delete_archive)

    async def nx_check_updates(self, appid: int):
        return await _nx_safe(check_updates, appid)

    async def _nx_unload(self):
        _job_cancel.set()


WD_MODULE = {"mixin": NexusMixin, "order": 60, "unload": "_nx_unload"}
