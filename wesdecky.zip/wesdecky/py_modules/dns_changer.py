"""DNS Changer (phần backend trong plugin Wesdecky).

Đổi DNS cho kết nối Wi-Fi/Ethernet đang dùng bằng nmcli. Cần quyền root.
"""
import asyncio
import ipaddress
import json
import os

import decky

# Thư mục cài đặt của plugin cũ (DNS Changer riêng lẻ, All in 1) (để chuyển bộ DNS đã lưu).
# Kèm tên file cài đặt DNS trong mỗi thư mục.
OLD_PLUGIN_DIRS = (
    ("all-in-1-weirdstore", "dns.json"),  # bản All in 1 (trước khi đổi tên thành Wesdecky)
    ("All in 1 by Weirdstore.vn", "dns.json"),
    ("DNS Changer by Weirdstore.vn", "settings.json"),
    ("decky-dns-changer", "settings.json"),
)


def settings_file() -> str:
    return os.path.join(decky.DECKY_PLUGIN_SETTINGS_DIR, "dns.json")


def migrate_old_settings():
    """Lần đầu chạy Wesdecky: lấy bộ DNS đã lưu từ plugin cũ (nếu có)."""
    if os.path.exists(settings_file()):
        return False
    parent = os.path.dirname(os.path.normpath(decky.DECKY_PLUGIN_SETTINGS_DIR))
    for d, fname in OLD_PLUGIN_DIRS:
        old = os.path.join(parent, d, fname)
        if os.path.isfile(old) and os.path.realpath(old) != os.path.realpath(settings_file()):
            try:
                with open(old) as f:
                    data = json.load(f)
            except (OSError, ValueError):
                continue
            os.makedirs(os.path.dirname(settings_file()), exist_ok=True)
            with open(settings_file(), "w") as f:
                json.dump(data, f)
            decky.logger.info(f"DNS: đã chuyển bộ DNS đã lưu từ {old}")
            return True
    return False


def _clean_env():
    """Decky's bundled Python sets LD_LIBRARY_PATH, which can break system
    binaries like nmcli. Strip it before calling out."""
    env = dict(os.environ)
    for key in ("LD_LIBRARY_PATH", "LD_PRELOAD", "PYTHONHOME", "PYTHONPATH"):
        env.pop(key, None)
    env["LANG"] = "C"
    env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:" + env.get("PATH", "")
    return env


async def _run(*args):
    decky.logger.debug("run: " + " ".join(repr(a) for a in args))
    try:
        proc = await asyncio.create_subprocess_exec(
            *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=_clean_env(),
        )
    except FileNotFoundError:
        return 127, "", f"Không tìm thấy lệnh {args[0]}"
    out, err = await proc.communicate()
    return proc.returncode, out.decode(errors="replace").strip(), err.decode(errors="replace").strip()


def _split_terse(line):
    """Split an `nmcli -t` line on unescaped ':' and unescape '\\:'."""
    parts, cur, i = [], "", 0
    while i < len(line):
        c = line[i]
        if c == "\\" and i + 1 < len(line):
            cur += line[i + 1]
            i += 2
            continue
        if c == ":":
            parts.append(cur)
            cur = ""
        else:
            cur += c
        i += 1
    parts.append(cur)
    return parts


def _parse_servers(servers):
    """Validate a list/str of DNS servers, return (v4_list, v6_list)."""
    if isinstance(servers, str):
        servers = servers.replace(",", " ").split()
    v4, v6 = [], []
    for s in servers:
        s = s.strip()
        if not s:
            continue
        ip = ipaddress.ip_address(s)  # raises ValueError if invalid
        (v4 if ip.version == 4 else v6).append(str(ip))
    if not v4 and not v6:
        raise ValueError("chưa nhập địa chỉ DNS nào")
    return v4, v6


class DnsMixin:
    """Các hàm DNS gọi từ giao diện. Tên có tiền tố dns_ để không trùng phần khác."""

    # ---------- helpers ----------
    async def _dns_active_connection(self):
        code, out, err = await _run(
            "nmcli", "-t", "-f", "NAME,UUID,TYPE,DEVICE", "connection", "show", "--active"
        )
        if code != 0:
            raise RuntimeError(err or "nmcli lỗi")
        for line in out.splitlines():
            name, uuid, ctype, device = (_split_terse(line) + ["", "", "", ""])[:4]
            if ctype in ("802-11-wireless", "802-3-ethernet", "wifi", "ethernet") and device:
                return {"name": name, "uuid": uuid, "type": ctype, "device": device}
        return None

    async def _dns_current_dns(self, device):
        code, out, _ = await _run("nmcli", "-t", "-f", "IP4.DNS,IP6.DNS", "device", "show", device)
        dns = []
        if code == 0:
            for line in out.splitlines():
                parts = line.split(":", 1)
                if len(parts) == 2 and parts[1]:
                    dns.append(parts[1].replace("\\:", ":"))
        return dns

    async def _dns_conn_setting(self, uuid, field):
        code, out, _ = await _run("nmcli", "-g", field, "connection", "show", uuid)
        return out if code == 0 else ""

    async def _dns_apply(self, conn):
        # reapply is seamless; fall back to bringing the connection up again
        code, _, err = await _run("nmcli", "device", "reapply", conn["device"])
        if code != 0:
            code, _, err = await _run("nmcli", "connection", "up", conn["uuid"])
            if code != 0:
                raise RuntimeError(err or "Không áp dụng được thay đổi")

    # ---------- settings ----------
    def _dns_load(self):
        try:
            with open(settings_file()) as f:
                return json.load(f)
        except Exception:
            return {}

    def _dns_save(self, data):
        os.makedirs(os.path.dirname(settings_file()), exist_ok=True)
        with open(settings_file(), "w") as f:
            json.dump(data, f)

    # ---------- callable from frontend ----------
    async def dns_get_status(self):
        try:
            conn = await self._dns_active_connection()
            if not conn:
                return {"ok": True, "connected": False}
            runtime = conn["uuid"] in self._dns_load().get("runtime", [])
            custom = runtime or bool(await self._dns_conn_setting(conn["uuid"], "ipv4.dns")) or bool(
                await self._dns_conn_setting(conn["uuid"], "ipv6.dns")
            )
            return {
                "ok": True,
                "connected": True,
                "connection": conn["name"],
                "device": conn["device"],
                "dns": await self._dns_current_dns(conn["device"]),
                "custom": custom,
                "runtime": runtime,
            }
        except Exception as e:
            decky.logger.exception("get_status")
            return {"ok": False, "error": str(e)}

    # ---------- DNS change strategies ----------
    @staticmethod
    def _dns_args(v4, v6, with_v6=True):
        args = ["ipv4.dns", " ".join(v4), "ipv4.ignore-auto-dns", "yes" if v4 else "no"]
        if with_v6:
            args += ["ipv6.dns", " ".join(v6), "ipv6.ignore-auto-dns", "yes" if v6 else "no"]
        return args

    async def _dns_change(self, conn, v4, v6):
        """Try progressively safer ways to change DNS.
        Returns (mode, None) on success or (None, error_text)."""
        errors = []

        # 1) Saved profile, IPv4 + IPv6 (persists across reboots)
        code, _, err = await _run("nmcli", "connection", "modify", conn["uuid"], *self._dns_args(v4, v6))
        if code == 0:
            await self._dns_apply(conn)
            return "profile", None
        errors.append(f"[1] {err}")
        decky.logger.warning(f"connection modify (v4+v6) failed: {err}")

        # 2) Saved profile, IPv4 only (some profiles reject IPv6 DNS, e.g. ipv6.method=disabled)
        if v4:
            code, _, err = await _run("nmcli", "connection", "modify", conn["uuid"], *self._dns_args(v4, v6, False))
            if code == 0:
                await self._dns_apply(conn)
                return "profile", None
            errors.append(f"[2] {err}")
            decky.logger.warning(f"connection modify (v4) failed: {err}")

        # 3) Running device only, profile untouched (lost when Wi-Fi reconnects)
        code, _, err = await _run("nmcli", "device", "modify", conn["device"], *self._dns_args(v4, v6, bool(v6)))
        if code == 0:
            return "runtime", None
        errors.append(f"[3] {err}")
        decky.logger.warning(f"device modify failed: {err}")

        # 4) systemd-resolved directly on the interface (also temporary)
        code, _, err = await _run("resolvectl", "dns", conn["device"], *(v4 + v6))
        if code == 0:
            await _run("resolvectl", "domain", conn["device"], "~.")
            await _run("resolvectl", "flush-caches")
            return "runtime", None
        errors.append(f"[4] {err}")
        decky.logger.error("All DNS change methods failed: " + " | ".join(errors))
        return None, " | ".join(e for e in errors if e.strip())

    def _dns_set_runtime_flag(self, uuid, on):
        data = self._dns_load()
        rt = set(data.get("runtime", []))
        (rt.add if on else rt.discard)(uuid)
        data["runtime"] = sorted(rt)
        self._dns_save(data)

    def _dns_root_error(self):
        if hasattr(os, "geteuid") and os.geteuid() != 0:
            return "Plugin không chạy bằng quyền root. Hãy cài lại plugin hoặc khởi động lại Decky."
        return None

    async def dns_set_dns(self, servers):
        try:
            v4, v6 = _parse_servers(servers)
            if self._dns_root_error():
                return {"ok": False, "error": self._dns_root_error()}
            conn = await self._dns_active_connection()
            if not conn:
                return {"ok": False, "error": "Không có kết nối mạng"}
            mode, err = await self._dns_change(conn, v4, v6)
            if not mode:
                return {"ok": False, "error": err or "Không đổi được DNS"}
            self._dns_set_runtime_flag(conn["uuid"], mode == "runtime")
            decky.logger.info(f"DNS set ({mode}) on {conn['name']}: {v4 + v6}")
            return {"ok": True, "mode": mode}
        except ValueError as e:
            return {"ok": False, "error": f"Địa chỉ không hợp lệ: {e}"}
        except Exception as e:
            decky.logger.exception("set_dns")
            return {"ok": False, "error": str(e)}

    async def dns_reset_dns(self):
        try:
            if self._dns_root_error():
                return {"ok": False, "error": self._dns_root_error()}
            conn = await self._dns_active_connection()
            if not conn:
                return {"ok": False, "error": "Không có kết nối mạng"}
            code, _, err = await _run(
                "nmcli", "connection", "modify", conn["uuid"],
                "ipv4.dns", "", "ipv4.ignore-auto-dns", "no",
                "ipv6.dns", "", "ipv6.ignore-auto-dns", "no",
            )
            if code != 0:
                decky.logger.warning(f"reset via connection modify failed: {err}")
                await _run("nmcli", "connection", "modify", conn["uuid"], "ipv4.dns", "", "ipv4.ignore-auto-dns", "no")
                await _run("resolvectl", "revert", conn["device"])
            # Re-activating discards any runtime-only change as well
            await self._dns_apply(conn)
            self._dns_set_runtime_flag(conn["uuid"], False)
            decky.logger.info(f"DNS reset on {conn['name']}")
            return {"ok": True}
        except Exception as e:
            decky.logger.exception("reset_dns")
            return {"ok": False, "error": str(e)}

    # ---------- saved custom profiles ----------
    def _dns_profiles(self):
        data = self._dns_load()
        profiles = data.get("profiles")
        if profiles is None:
            profiles = []
            # migrate the single custom entry from v1.0
            old = data.get("custom_servers", "").strip()
            if old:
                try:
                    v4, v6 = _parse_servers(old)
                    profiles.append({"name": "Tuỳ chỉnh", "servers": v4 + v6})
                except ValueError:
                    pass
            data["profiles"] = profiles
            data.pop("custom_servers", None)
            self._dns_save(data)
        return profiles

    async def dns_get_profiles(self):
        return self._dns_profiles()

    async def dns_save_profile(self, name, servers):
        name = (name or "").strip()
        if not name:
            return {"ok": False, "error": "Hãy đặt tên cho bộ DNS"}
        if len(name) > 32:
            return {"ok": False, "error": "Tên tối đa 32 ký tự"}
        try:
            v4, v6 = _parse_servers(servers)
        except ValueError as e:
            return {"ok": False, "error": f"Địa chỉ không hợp lệ: {e}"}
        profiles = [p for p in self._dns_profiles() if p["name"].lower() != name.lower()]
        profiles.append({"name": name, "servers": v4 + v6})
        data = self._dns_load()
        data["profiles"] = profiles
        self._dns_save(data)
        return {"ok": True, "profiles": profiles}

    async def dns_delete_profile(self, name):
        profiles = [p for p in self._dns_profiles() if p["name"] != name]
        data = self._dns_load()
        data["profiles"] = profiles
        self._dns_save(data)
        return {"ok": True, "profiles": profiles}

    # ---------- lifecycle ----------
    async def _dns_main(self):
        try:
            migrate_old_settings()
        except Exception:
            decky.logger.exception("DNS: không chuyển được cài đặt cũ")

    async def _dns_uninstall(self):
        # Trả mạng về như trước khi plugin đụng vào
        await self.dns_reset_dns()


# Đăng ký với Wesdecky (main.py tự tìm các module có WD_MODULE).
WD_MODULE = {"mixin": DnsMixin, "order": 30, "main": "_dns_main", "uninstall": "_dns_uninstall"}
