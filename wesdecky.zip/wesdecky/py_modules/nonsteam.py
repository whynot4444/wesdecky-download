"""
Thêm app Non-Steam - phần backend.

Việc tạo shortcut trong Steam do giao diện làm (SteamClient.Apps.AddShortcut).
Backend chỉ lo những việc cần hệ thống file / mạng:
  - kiểm tra file người dùng chọn, bật quyền chạy cho AppImage / .sh
  - liệt kê app Flatpak đã cài
  - tìm và tải ảnh bìa trên SteamGridDB (cần API key của người dùng)

Mọi hàm gọi từ giao diện có tiền tố `ns_` để gộp được vào plugin All-in-1
(class Plugin(..., NonSteamMixin)) mà không trùng tên với tab khác.
Plugin All-in-1 chạy root, nên lệnh flatpak chạy bằng user sở hữu thư mục home,
và file cài đặt được đổi chủ về user đó.
"""
import base64
import json
import os
import re
import shutil
import ssl
import stat
import subprocess
import urllib.error
import urllib.parse
import urllib.request

import decky

SGDB_API = "https://www.steamgriddb.com/api/v2"
SETTINGS_FILE = "nonsteam.json"
WINDOWS_EXTS = {".exe", ".msi", ".bat", ".lnk"}
UA = "decky-nonsteam-adder/1.0"
MAX_IMAGE = 15 * 1024 * 1024

# Loại ảnh trong Steam (ELibraryAssetType) -> tham số tìm trên SteamGridDB
ASSETS = {
    0: ("grids", {"dimensions": "600x900", "types": "static"}),          # bìa dọc
    1: ("heroes", {"types": "static"}),                                  # ảnh nền
    2: ("logos", {"types": "static"}),                                   # logo
    3: ("grids", {"dimensions": "920x430,460x215", "types": "static"}),  # bìa ngang
    4: ("icons", {"types": "static", "mimes": "image/png"}),             # biểu tượng
}


def _ok(data=None):
    return {"ok": True, "data": data}


def _err(msg):
    return {"ok": False, "error": str(msg)}


# ------------------------------------------------------------- người dùng ---
def _home() -> str:
    return decky.DECKY_USER_HOME


def _owner():
    """(uid, gid) của user sở hữu home; None nếu đang không chạy root."""
    if not hasattr(os, "geteuid") or os.geteuid() != 0:
        return None
    try:
        st = os.stat(_home())
        return st.st_uid, st.st_gid
    except OSError:
        return None


def _give_to_user(path: str):
    own = _owner()
    if own:
        try:
            os.chown(path, *own)
        except OSError:
            pass


def _clean_env() -> dict:
    env = dict(os.environ)
    for k in ("LD_LIBRARY_PATH", "LD_PRELOAD", "PYTHONHOME", "PYTHONPATH"):
        env.pop(k, None)
    env["HOME"] = _home()
    own = _owner()
    if own:
        env["XDG_RUNTIME_DIR"] = f"/run/user/{own[0]}"
    return env


def _run_as_user(cmd, timeout=30):
    kw = {}
    own = _owner()
    if own:
        kw = {"user": own[0], "group": own[1]}
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=_clean_env(), **kw)


# --------------------------------------------------------------- cài đặt ---
def _settings_path() -> str:
    return os.path.join(decky.DECKY_PLUGIN_SETTINGS_DIR, SETTINGS_FILE)


def load_settings() -> dict:
    try:
        with open(_settings_path(), encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def save_settings(data: dict):
    path = _settings_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)
    _give_to_user(path)


# ------------------------------------------------------------------ file ---
def nice_name(filename: str) -> str:
    """'My_Game-v1.2.AppImage' -> 'My Game v1.2'."""
    base = os.path.basename(filename.rstrip("/"))
    stem, ext = os.path.splitext(base)
    if ext.lower() in (".appimage", ".sh", ".exe", ".msi", ".bat", ".x86_64", ".bin", ".lnk"):
        base = stem
    base = re.sub(r"[-_ ]+(x86_64|x86-64|amd64|linux|win64|win32)$", "", base, flags=re.I)
    base = re.sub(r"_+", " ", base)
    base = re.sub(r"(?<=[A-Za-z])-(?=[A-Za-z0-9])", " ", base)
    return re.sub(r"\s+", " ", base).strip() or stem or base


def prepare_file(path: str) -> dict:
    if not path or not os.path.isfile(path):
        raise ValueError(f"Không tìm thấy file: {path}")
    ext = os.path.splitext(path)[1].lower()
    kind = "windows" if ext in WINDOWS_EXTS else "linux"
    if kind == "linux":
        mode = os.stat(path).st_mode
        if not mode & stat.S_IXUSR:
            try:
                os.chmod(path, mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
            except OSError as e:
                raise ValueError(f"Không bật được quyền chạy cho file: {e}")
    return {
        "kind": kind,
        "name": nice_name(path),
        "exe": path,
        "start_dir": os.path.dirname(path),
    }


# --------------------------------------------------------------- flatpak ---
def flatpak_bin():
    for p in ("/usr/bin/flatpak", shutil.which("flatpak") or ""):
        if p and os.path.exists(p):
            return p
    return None


def list_flatpaks() -> list:
    fp = flatpak_bin()
    if not fp:
        raise ValueError("Máy không có Flatpak")
    r = _run_as_user([fp, "list", "--app", "--columns=application,name"])
    if r.returncode != 0:
        raise ValueError((r.stderr or r.stdout).strip() or "flatpak list lỗi")
    apps, seen = [], set()
    for line in r.stdout.splitlines():
        parts = line.split("\t")
        app_id = parts[0].strip()
        if not app_id or app_id in seen or app_id.lower() == "application id":
            continue
        seen.add(app_id)
        name = parts[1].strip() if len(parts) > 1 and parts[1].strip() else app_id.split(".")[-1]
        apps.append({"id": app_id, "name": name})
    apps.sort(key=lambda a: a["name"].lower())
    return apps


def flatpak_shortcut(app_id: str, name: str) -> dict:
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", app_id or ""):
        raise ValueError("ID Flatpak không hợp lệ")
    fp = flatpak_bin() or "/usr/bin/flatpak"
    return {
        "kind": "flatpak",
        "name": name or app_id,
        "exe": fp,
        "start_dir": os.path.dirname(fp),
        "launch_options": f"run {app_id}",
    }


# ----------------------------------------------------------- SteamGridDB ---
def _ssl_ctx():
    ctx = ssl.create_default_context()
    for ca in ("/etc/ssl/certs/ca-certificates.crt", "/etc/ca-certificates/extracted/tls-ca-bundle.pem"):
        if os.path.exists(ca):
            try:
                ctx.load_verify_locations(ca)
            except ssl.SSLError:
                pass
    return ctx


def _http(url: str, key: str = "", limit: int = 2 * 1024 * 1024, timeout: int = 20) -> bytes:
    headers = {"User-Agent": UA}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout, context=_ssl_ctx()) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError("File quá lớn")
    return data


def _sgdb(path: str, key: str, params: dict = None):
    url = SGDB_API + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    try:
        body = json.loads(_http(url, key))
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise ValueError("API key SteamGridDB không đúng")
        if e.code == 404:
            return []
        raise ValueError(f"SteamGridDB lỗi HTTP {e.code}")
    if not body.get("success", False):
        raise ValueError("SteamGridDB: " + "; ".join(body.get("errors") or ["lỗi không rõ"]))
    return body.get("data") or []


def search_game(name: str, key: str):
    term = urllib.parse.quote(name.strip(), safe="")
    found = _sgdb(f"/search/autocomplete/{term}", key)
    return found[0] if found else None


def fetch_artwork(name: str, key: str) -> dict:
    if not key:
        raise ValueError("Chưa nhập API key SteamGridDB")
    game = search_game(name, key)
    if not game:
        raise ValueError(f"Không thấy \"{name}\" trên SteamGridDB")
    images, errors = {}, []
    for asset, (kind, params) in ASSETS.items():
        try:
            items = _sgdb(f"/{kind}/game/{game['id']}", key, params)
            for it in items[:3]:
                url = it.get("url") or ""
                ext = "jpg" if url.lower().endswith((".jpg", ".jpeg")) else "png"
                if not url.lower().endswith((".png", ".jpg", ".jpeg")):
                    continue
                raw = _http(url, limit=MAX_IMAGE, timeout=40)
                images[str(asset)] = {"b64": base64.b64encode(raw).decode("ascii"), "ext": ext}
                break
        except Exception as e:  # một loại ảnh lỗi thì vẫn lấy các loại khác
            errors.append(f"{kind}: {e}")
    if not images:
        raise ValueError("Không tải được ảnh nào" + (f" ({errors[0]})" if errors else ""))
    return {"game": game.get("name", name), "sgdb_id": game.get("id"), "images": images}


# ------------------------------------------------------- hàm cho giao diện ---
class NonSteamMixin:
    async def ns_get_settings(self):
        key = load_settings().get("sgdb_key", "")
        return _ok({
            "sgdb_key_set": bool(key),
            "sgdb_key_hint": ("…" + key[-4:]) if len(key) >= 8 else "",
            "auto_artwork": load_settings().get("auto_artwork", True),
            "flatpak": flatpak_bin() is not None,
            "home": _home(),
        })

    async def ns_set_sgdb_key(self, key: str):
        key = (key or "").strip()
        if key and not re.fullmatch(r"[A-Za-z0-9]{16,64}", key):
            return _err("API key không đúng dạng (chỉ gồm chữ và số)")
        s = load_settings()
        s["sgdb_key"] = key
        save_settings(s)
        return _ok({"sgdb_key_set": bool(key)})

    async def ns_set_auto_artwork(self, on: bool):
        s = load_settings()
        s["auto_artwork"] = bool(on)
        save_settings(s)
        return _ok()

    async def ns_prepare_file(self, path: str):
        try:
            return _ok(prepare_file(path))
        except Exception as e:
            return _err(e)

    async def ns_list_flatpaks(self):
        try:
            return _ok(list_flatpaks())
        except Exception as e:
            decky.logger.warning("flatpak list: %s", e)
            return _err(e)

    async def ns_flatpak_shortcut(self, app_id: str, name: str):
        try:
            return _ok(flatpak_shortcut(app_id, name))
        except Exception as e:
            return _err(e)

    async def ns_fetch_artwork(self, name: str):
        try:
            return _ok(fetch_artwork(name, load_settings().get("sgdb_key", "")))
        except Exception as e:
            decky.logger.warning("artwork %s: %s", name, e)
            return _err(e)


# Đăng ký với Wesdecky (main.py tự tìm các module có WD_MODULE).
WD_MODULE = {"mixin": NonSteamMixin, "order": 40}
