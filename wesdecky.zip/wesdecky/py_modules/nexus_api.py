"""Gọi Nexus Mods API (v1 REST + v2 GraphQL) cho tab Mod của Wesdecky.

Chỉ dùng thư viện chuẩn. API key chỉ được gửi tới api.nexusmods.com, không bao giờ
gửi cho CDN tải file.
"""
import json
import os
import re
import ssl
import urllib.error
import urllib.parse
import urllib.request

API_HOST = "api.nexusmods.com"
API_V1 = "https://api.nexusmods.com/v1"
API_V2 = "https://api.nexusmods.com/v2/graphql"
APP_NAME = "Wesdecky"
APP_VERSION = "2.0.0"
TIMEOUT = 30

DOMAIN_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")
NXM_RE = re.compile(r"^nxm://([a-z0-9][a-z0-9_-]{0,63})/mods/(\d{1,10})/files/(\d{1,12})(?:\?(.*))?$", re.I)
MOD_URL_RE = re.compile(r"nexusmods\.com/([a-z0-9][a-z0-9_-]{0,63})/mods/(\d{1,10})", re.I)

_ctx = None


class NexusError(Exception):
    """Lỗi có mã ngắn để giao diện hiện thông báo dễ hiểu."""

    def __init__(self, code: str, msg: str = "", status: int = 0):
        super().__init__(msg or code)
        self.code = code
        self.status = status


def ssl_context():
    """Python của Decky đôi khi không thấy kho chứng chỉ hệ thống: thử thêm file của Arch."""
    global _ctx
    if _ctx is None:
        ctx = ssl.create_default_context()
        if not ctx.get_ca_certs():
            for f in ("/etc/ssl/certs/ca-certificates.crt", "/etc/ca-certificates/extracted/tls-ca-bundle.pem"):
                if os.path.isfile(f):
                    ctx.load_verify_locations(cafile=f)
                    break
        _ctx = ctx
    return _ctx


def _headers(api_key: str) -> dict:
    return {
        "apikey": api_key,
        "Application-Name": APP_NAME,
        "Application-Version": APP_VERSION,
        "Accept": "application/json",
        "User-Agent": f"{APP_NAME}/{APP_VERSION} (Decky Loader; SteamOS)",
    }


def _request(method: str, url: str, api_key: str, body=None):
    """Gửi một request tới API Nexus, trả về JSON. Tách riêng để test thay thế được."""
    if urllib.parse.urlsplit(url).hostname != API_HOST:
        raise NexusError("bad_host", url)
    data = None
    headers = _headers(api_key)
    if body is not None:
        data = json.dumps(body).encode()
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT, context=ssl_context()) as r:
            return json.loads(r.read().decode("utf-8") or "null")
    except urllib.error.HTTPError as e:
        code = {401: "bad_key", 403: "forbidden", 404: "not_found", 429: "rate_limited"}.get(e.code, "http")
        detail = ""
        try:
            detail = json.loads(e.read().decode("utf-8", "replace")).get("message", "")
        except Exception:  # noqa: BLE001
            pass
        raise NexusError(code, detail or f"HTTP {e.code}", e.code) from None
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise NexusError("offline", str(e)) from None


def v1(path: str, api_key: str, **query):
    q = {k: v for k, v in query.items() if v is not None}
    url = f"{API_V1}/{path}" + (("?" + urllib.parse.urlencode(q)) if q else "")
    return _request("GET", url, api_key)


def _check_domain(domain: str):
    if not DOMAIN_RE.match(domain or ""):
        raise NexusError("bad_domain", domain)


# ------------------------------------------------------------ v1 REST ---
def validate(api_key: str) -> dict:
    d = v1("users/validate.json", api_key)
    return {"name": d.get("name", ""), "user_id": d.get("user_id"), "is_premium": bool(d.get("is_premium"))}


def games(api_key: str) -> list:
    return [
        {"domain": g.get("domain_name", ""), "name": g.get("name", ""), "id": g.get("id")}
        for g in v1("games.json", api_key) or []
        if g.get("domain_name")
    ]


def _mod_summary(m: dict) -> dict:
    return {
        "mod_id": m.get("mod_id"),
        "name": m.get("name") or "",
        "summary": m.get("summary") or "",
        "version": m.get("version") or "",
        "author": m.get("author") or m.get("uploaded_by") or "",
        "picture": m.get("picture_url") or "",
        "endorsements": m.get("endorsement_count") or 0,
        "downloads": m.get("mod_downloads") or 0,
        "updated": m.get("updated_timestamp") or 0,
        "adult": bool(m.get("contains_adult_content")),
        "available": m.get("available", True) and m.get("status", "published") == "published",
    }


LISTS = {"trending": "trending.json", "updated": "latest_updated.json", "added": "latest_added.json"}


def mod_list(api_key: str, domain: str, kind: str) -> list:
    _check_domain(domain)
    if kind not in LISTS:
        raise NexusError("bad_list", kind)
    return [_mod_summary(m) for m in v1(f"games/{domain}/mods/{LISTS[kind]}", api_key) or []]


def mod_info(api_key: str, domain: str, mod_id: int) -> dict:
    _check_domain(domain)
    return _mod_summary(v1(f"games/{domain}/mods/{int(mod_id)}.json", api_key) or {})


FILE_CATS = {"MAIN", "UPDATE", "OPTIONAL", "MISCELLANEOUS"}


def mod_files(api_key: str, domain: str, mod_id: int, all_files: bool = False) -> dict:
    _check_domain(domain)
    d = v1(f"games/{domain}/mods/{int(mod_id)}/files.json", api_key) or {}
    files = []
    for f in d.get("files") or []:
        cat = (f.get("category_name") or "").upper()
        if not all_files and cat not in FILE_CATS:
            continue
        files.append({
            "file_id": f.get("file_id"),
            "name": f.get("name") or f.get("file_name") or "",
            "file_name": f.get("file_name") or "",
            "version": f.get("version") or f.get("mod_version") or "",
            "category": cat,
            "size_kb": f.get("size_kb") or 0,
            "uploaded": f.get("uploaded_timestamp") or 0,
            "primary": bool(f.get("is_primary")),
            "description": f.get("description") or "",
        })
    order = {"MAIN": 0, "UPDATE": 1, "OPTIONAL": 2, "MISCELLANEOUS": 3}
    files.sort(key=lambda f: (order.get(f["category"], 9), -f["uploaded"]))
    updates = [
        {"old": u.get("old_file_id"), "new": u.get("new_file_id"), "time": u.get("uploaded_timestamp") or 0}
        for u in d.get("file_updates") or []
    ]
    return {"files": files, "updates": updates}


def newest_replacement(updates: list, file_id: int):
    """Theo chuỗi file_updates (cũ -> mới) để tìm file mới nhất thay cho file_id."""
    nxt = {}
    for u in updates:
        if u.get("old") and u.get("new"):
            nxt[u["old"]] = u["new"]
    cur, seen = file_id, set()
    while cur in nxt and cur not in seen:
        seen.add(cur)
        cur = nxt[cur]
    return cur if cur != file_id else None


def download_links(api_key: str, domain: str, mod_id: int, file_id: int, key: str = None, expires: str = None) -> list:
    """Link tải từ CDN. Không có key/expires thì chỉ tài khoản Premium mới được."""
    _check_domain(domain)
    d = v1(f"games/{domain}/mods/{int(mod_id)}/files/{int(file_id)}/download_link.json", api_key,
           key=key, expires=expires)
    out = []
    for x in d or []:
        uri = x.get("URI") or ""
        if urllib.parse.urlsplit(uri).scheme == "https":
            out.append({"name": x.get("name") or x.get("short_name") or "", "url": uri})
    if not out:
        raise NexusError("no_link")
    return out


# --------------------------------------------------------- v2 GraphQL ---
# Schema GraphQL của Nexus chưa được kiểm chứng ở đây, nên thử vài cách viết và nhớ cách nào chạy.
_SEARCH_VARIANTS = [
    ("gameDomainName", "author"),
    ("gameDomain", "author { name }"),
    ("gameDomainName", "uploader { name }"),
]
_search_ok = None


def _search_query(dom_field: str, author: str) -> str:
    return (
        "query WdSearch($domain: String!, $term: String!, $count: Int!) {"
        f" mods(filter: {{ {dom_field}: [{{ value: $domain, op: EQUALS }}], name: [{{ value: $term, op: WILDCARD }}] }},"
        "  count: $count) { nodes { modId name summary version pictureUrl endorsements downloads " + author + " } } }"
    )


def search(api_key: str, domain: str, term: str, count: int = 20) -> list:
    global _search_ok
    _check_domain(domain)
    term = (term or "").strip()[:80]
    if not term:
        return []
    variants = [_search_ok] if _search_ok else _SEARCH_VARIANTS
    last = None
    for dom_field, author in variants:
        body = {"query": _search_query(dom_field, author),
                "variables": {"domain": domain, "term": f"*{term}*", "count": int(count)}}
        d = _request("POST", API_V2, api_key, body) or {}
        nodes = ((d.get("data") or {}).get("mods") or {}).get("nodes")
        if nodes is None:
            last = d.get("errors")
            continue
        _search_ok = (dom_field, author)
        out = []
        for n in nodes:
            a = n.get("author")
            if isinstance(a, dict):
                a = a.get("name")
            if not a and isinstance(n.get("uploader"), dict):
                a = n["uploader"].get("name")
            out.append({
                "mod_id": n.get("modId"), "name": n.get("name") or "", "summary": n.get("summary") or "",
                "version": n.get("version") or "", "author": a or "", "picture": n.get("pictureUrl") or "",
                "endorsements": n.get("endorsements") or 0, "downloads": n.get("downloads") or 0,
                "updated": 0, "adult": False, "available": True,
            })
        return out
    raise NexusError("search_failed", json.dumps(last)[:300] if last else "")


# ---------------------------------------------------------------- nxm ---
def parse_nxm(link: str) -> dict:
    """nxm://<domain>/mods/<mod>/files/<file>?key=..&expires=..&user_id=.."""
    m = NXM_RE.match((link or "").strip())
    if not m:
        raise NexusError("bad_nxm", link)
    q = urllib.parse.parse_qs(m.group(4) or "")
    out = {"domain": m.group(1).lower(), "mod_id": int(m.group(2)), "file_id": int(m.group(3)),
           "key": (q.get("key") or [None])[0], "expires": (q.get("expires") or [None])[0]}
    if not out["key"] or not out["expires"]:
        raise NexusError("bad_nxm", "thiếu key/expires")
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", out["key"]) or not out["expires"].isdigit():
        raise NexusError("bad_nxm", "key/expires lạ")
    return out


def parse_mod_ref(text: str, domain: str):
    """Nhận số mod ID hoặc URL trang mod. Trả về mod_id hoặc None."""
    t = (text or "").strip()
    if t.isdigit() and len(t) <= 10:
        return int(t)
    m = MOD_URL_RE.search(t)
    if m and m.group(1).lower() == (domain or "").lower():
        return int(m.group(2))
    return None
