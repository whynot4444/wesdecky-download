"""
Kho chung: bản lưu các bản Việt hóa MIỄN PHÍ (file trên Google Drive, danh sách index.json trên GitHub).

- Tra theo AppID của Steam, nên luôn đúng game.
- Mỗi mục ghi rõ nhóm dịch và trang gốc; plugin luôn thử link gốc của nhóm trước, kho chung chỉ là dự phòng.
- File có mã SHA-256 để kiểm tra sau khi tải.

Định dạng index.json (xem mirror-template/README.md):
{
  "version": 1,
  "games": [
    {
      "appid": "1623730", "game": "Palworld",
      "team": "The Red Team", "source": "https://theredteam.vn/palworld-viet-hoa",
      "version": "v1.2", "updated": "2026-11-08", "password": "Theredteam.vn",
      "install": {"type": "files", "target": ""},
      "files": [{"name": "Palworld_VietHoa.zip", "url": "https://drive.google.com/file/d/ID/view",
                 "size": 123, "sha256": "..."}]
    }
  ]
}
"""
import json
import re
import time
import urllib.parse

import decky

import downloader as dl

DEFAULT_INDEX = "https://raw.githubusercontent.com/whynot4444/viet-hoa-mirror/main/index.json"
CACHE_SECONDS = 600
_cache = {"url": None, "at": 0.0, "games": []}

SHA256 = re.compile(r"^[0-9a-f]{64}$")


def _valid_entry(e):
    if not isinstance(e, dict):
        return False
    if not re.fullmatch(r"\d+", str(e.get("appid", ""))) or not e.get("game") or not e.get("files"):
        return False
    src = str(e.get("source", ""))
    if not src.startswith("https://") or not e.get("team"):
        return False  # bắt buộc ghi nguồn
    for f in e["files"]:
        if not isinstance(f, dict) or not str(f.get("url", "")).startswith("https://"):
            return False
        if f.get("sha256") and not SHA256.match(str(f["sha256"]).lower()):
            return False
    return True


def load_index(url, force=False):
    if not url:
        return []
    now = time.time()
    if not force and _cache["url"] == url and now - _cache["at"] < CACHE_SECONDS:
        return _cache["games"]
    final, text = dl._get_text(url)
    try:
        data = json.loads(text)
    except ValueError as e:
        raise RuntimeError(f"Danh sách kho chung không phải JSON hợp lệ: {e}")
    games = [g for g in data.get("games", []) if _valid_entry(g)]
    skipped = len(data.get("games", [])) - len(games)
    if skipped:
        decky.logger.warning(f"mirror: bỏ qua {skipped} mục thiếu thông tin (appid/nguồn/file)")
    _cache.update(url=url, at=now, games=games)
    return games


def find(games, appid, names):
    """Mục của game: ưu tiên khớp AppID, không có thì khớp tên."""
    from sources import _mentions

    by_id = [g for g in games if appid and str(g["appid"]) == str(appid)]
    if by_id:
        return by_id
    return [g for g in games if any(_mentions(g["game"], n) and _mentions(n, g["game"]) for n in names)]


def ref(entry):
    return f"mirror:{entry['appid']}:{urllib.parse.quote(entry.get('version', ''), safe='')}"


def entry_for_ref(url, index_url):
    m = re.match(r"^mirror:(\d+):(.*)$", url)
    if not m:
        return None
    version = urllib.parse.unquote(m.group(2))
    for g in load_index(index_url):
        if str(g["appid"]) == m.group(1) and g.get("version", "") == version:
            return g
    raise RuntimeError("Bản lưu này không còn trong kho chung (có thể đã được gỡ theo yêu cầu của nhóm dịch)")


def links(entry):
    """Các file của một mục, ở dạng link tải như find_links trả về."""
    out = []
    for f in entry["files"]:
        kind, ok, note = dl.classify(f["url"])
        out.append({
            "label": f"Kho chung: {f.get('name') or entry['game']}",
            "url": f["url"],
            "kind": kind or "direct",
            "supported": ok if kind else True,
            "note": note or f"Bản lưu của {entry['team']} – trang gốc: {entry['source']}",
            "password_hint": entry.get("password") or None,
            "sha256": (f.get("sha256") or "").lower() or None,
            "mirror": {"team": entry["team"], "source": entry["source"], "version": entry.get("version", ""),
                       "target": (entry.get("install") or {}).get("target")},
        })
    return out
