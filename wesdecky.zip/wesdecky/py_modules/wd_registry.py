"""Tự tìm các module của Wesdecky.

Mỗi file py_modules/<tên>.py có biến WD_MODULE là một module (một tab):

    WD_MODULE = {
        "mixin": EgpuMixin,      # class chứa các hàm giao diện gọi (đặt tiền tố riêng, vd egpu_)
        "order": 20,             # thứ tự khởi động (giống thứ tự tab)
        "main": "_egpu_main",    # (tuỳ chọn) tên hàm async chạy khi plugin khởi động
        "unload": "...",         # (tuỳ chọn) khi plugin dừng
        "uninstall": "...",      # (tuỳ chọn) khi gỡ plugin
    }

main.py ghép mọi mixin vào class Plugin, nên thêm module mới không cần sửa main.py.
"""
import importlib
import os

HERE = os.path.dirname(os.path.abspath(__file__))


def discover() -> list:
    mods = []
    for fn in sorted(os.listdir(HERE)):
        if not fn.endswith(".py") or fn.startswith("_") or fn == "wd_registry.py":
            continue
        path = os.path.join(HERE, fn)
        with open(path, encoding="utf-8") as f:
            if "\nWD_MODULE" not in f.read():  # không import file không phải module (downloader, sources…)
                continue
        m = importlib.import_module(fn[:-3])
        info = dict(getattr(m, "WD_MODULE"))
        info["name"] = fn[:-3]
        mods.append(info)
    mods.sort(key=lambda i: (i.get("order", 100), i["name"]))
    return mods


def public_names(cls) -> set:
    return {n for n in vars(cls) if not n.startswith("__")}


def check_conflicts(mods: list, base: set) -> list:
    """Hai module trùng tên hàm thì hàm của module sau bị che mất: báo lỗi để test bắt được."""
    seen = {n: "main.py" for n in base}
    errors = []
    for i in mods:
        for n in public_names(i["mixin"]):
            if n in seen:
                errors.append(f"{n}: trùng giữa {seen[n]} và {i['name']}")
            seen[n] = i["name"]
    return errors
