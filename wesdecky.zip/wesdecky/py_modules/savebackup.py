"""
Backup Save by Weirdstore.vn - backend.

Tự backup save game khi thoát game và khôi phục bản cũ ngay trong Game Mode.
Hỗ trợ: game Steam chạy Proton, game Non-Steam (Proton), port game (tab Game Port),
giả lập EmuDeck.

Tab "Save" của Wesdecky: mọi hàm gọi từ giao diện có tiền tố `sb_` và nằm trong
`SaveBackupMixin` (thêm vào `class Plugin(...)` trong main.py).

Lưu trữ:
    <dest>/<key>/<YYYYmmdd-HHMMSS>.tar.gz
    <dest>/<key>/info.json
key: steam-<appid> | ns-<appid> | port-<id> | emu-<tên>
Trong tar: <nhãn gốc>/<đường dẫn tương đối>.
"""
import asyncio
import hashlib
import json
import os
import re
import shutil
import stat
import struct
import tarfile
import tempfile
import threading
import time

import decky

# ------------------------------------------------------------- hằng số ---
DEFAULTS = {"auto": True, "dest": "", "keep": 10, "max_mb": 2048, "exit_delay": 5}
SETTINGS_FILE = "savebackup.json"
INFO_FILE = "info.json"

KEY_RE = re.compile(r"^(?:(?:steam|ns)-\d{1,10}|port-[a-z0-9][a-z0-9_.-]{0,63}|emu-[a-z0-9][a-z0-9_.-]{0,63})$")
FILE_RE = re.compile(r"^\d{8}-\d{6}(?:-\d{1,3})?\.tar\.gz$")
LABEL_RE = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9 _.()+-]{0,127}$")
PORT_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_.-]{0,63}$")

SHORTCUT_APP_TYPE = 1073741824

# Thư mục rác trong prefix Proton (so khớp chữ thường, ở mọi cấp).
PROTON_JUNK_DIRS = {
    "temp", "tmp", "microsoft", "cache", "caches", "shadercache", "shader cache", "shadercaches",
    "gpucache", "dxcache", "d3dscache", "glcache", "code cache", "webcache", "cefcache", "htmlcache",
    "logs", "log", "crashdumps", "crashes", "crashreports", "crash reports", "nvidia", "nvidia corporation",
    "amd", "steam", "deriveddatacache", "intermediate", "webkit", "unrealengine", "epicgameslauncher",
}
PROTON_JUNK_EXT = {".dmp", ".tmp", ".log", ".etl"}

# Các mục lấy trong drive_c/users: (nhãn, đường dẫn tương đối từ users/).
PROTON_ROOTS = [
    ("Roaming", "steamuser/AppData/Roaming"),
    ("Local", "steamuser/AppData/Local"),
    ("LocalLow", "steamuser/AppData/LocalLow"),
    ("Documents", "steamuser/Documents"),
    ("SavedGames", "steamuser/Saved Games"),
    ("PublicDocuments", "Public/Documents"),
]

# Port: bỏ ROM/dữ liệu gốc, file chạy và thư mục không phải save.
PORT_SKIP_EXT = {
    ".o2r", ".otr", ".z64", ".n64", ".v64", ".mpq", ".appimage", ".so", ".zip", ".7z", ".tar", ".gz",
    ".xz", ".rar", ".iso", ".dll", ".exe",
}
PORT_SKIP_DIRS = {"mods", "dynos", "cache", "logs", "shaders", "lib", "libs"}
# Thư mục dữ liệu ngoài thư mục cài (chưa kiểm chứng trên máy thật).
PORT_EXTRA = {
    "sm64coopdx": [".local/share/sm64coopdx"],
    "zelda64recomp": [".config/Zelda64Recompiled"],
    "devilutionx": [".local/share/diasurgical/devilution"],
    "openrct2": [".config/OpenRCT2"],
}
HARBOURMASTERS = {"soh", "2ship", "starship", "ghostship"}

# Giả lập: tên chuẩn -> từ khóa nhận diện (exe, launch options) và bí danh thư mục save.
EMULATORS = {
    "retroarch": ["retroarch"],
    "pcsx2": ["pcsx2"],
    "rpcs3": ["rpcs3"],
    "ryujinx": ["ryujinx", "ryubing"],
    "yuzu": ["yuzu", "citron", "eden", "suyu", "sudachi"],
    "citra": ["citra", "azahar", "lime3ds"],
    "dolphin": ["dolphin"],
    "primehack": ["primehack"],
    "duckstation": ["duckstation"],
    "ppsspp": ["ppsspp"],
    "melonds": ["melonds"],
    "cemu": ["cemu"],
    "xemu": ["xemu"],
    "xenia": ["xenia"],
    "vita3k": ["vita3k"],
    "mame": ["mame"],
    "scummvm": ["scummvm"],
    "flycast": ["flycast"],
    "shadps4": ["shadps4"],
    "mgba": ["mgba"],
    "model2": ["model2"],
    "supermodel": ["supermodel"],
}
FRONTENDS = ["es-de", "esde", "emulationstation", "pegasus"]

_LOCK = threading.RLock()


# ---------------------------------------------------------- tiện ích chung ---
def _home() -> str:
    return decky.DECKY_USER_HOME


def _settings_dir() -> str:
    return getattr(decky, "DECKY_PLUGIN_SETTINGS_DIR", None) or decky.DECKY_PLUGIN_RUNTIME_DIR


def _within(path: str, root: str) -> bool:
    path, root = os.path.realpath(path), os.path.realpath(root)
    return path == root or path.startswith(root.rstrip(os.sep) + os.sep)


def _owner():
    """uid/gid của chủ thư mục home (dùng khi plugin chạy root)."""
    try:
        st = os.stat(_home())
        return st.st_uid, st.st_gid
    except OSError:
        return None


def _chown(path: str):
    """Khi chạy root: trả file/thư mục do plugin tạo về chủ thư mục home. Chỉ đổi mục đang thuộc root."""
    if not hasattr(os, "geteuid") or os.geteuid() != 0:
        return
    own = _owner()
    if not own or own[0] == 0:
        return
    try:
        if os.lstat(path).st_uid == 0:
            os.lchown(path, *own)
    except OSError:
        pass


def _makedirs(path: str, stop: str = ""):
    """os.makedirs rồi chown các thư mục mới tạo (đến `stop`)."""
    created = []
    p = os.path.abspath(path)
    while not os.path.exists(p):
        created.append(p)
        parent = os.path.dirname(p)
        if parent == p or (stop and os.path.abspath(p) == os.path.abspath(stop)):
            break
        p = parent
    os.makedirs(path, exist_ok=True)
    for c in created:
        _chown(c)


def _write_json(path: str, data):
    d = os.path.dirname(path)
    _makedirs(d)
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".tmp-", suffix=".json")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)
    _chown(path)


def _read_json(path: str, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


# --------------------------------------------------------------- cài đặt ---
def _default_dest() -> str:
    return os.path.join(_home(), "SaveBackups")


def _allowed_dest(path: str) -> bool:
    real = os.path.realpath(path)
    return any(_within(real, r) for r in (_home(), "/run/media", "/media", "/mnt"))


def get_settings() -> dict:
    s = dict(DEFAULTS)
    data = _read_json(os.path.join(_settings_dir(), SETTINGS_FILE), {}) or {}
    for k in DEFAULTS:
        if k in data:
            s[k] = data[k]
    if not s["dest"]:
        s["dest"] = _default_dest()
    return s


def set_settings(changes: dict) -> dict:
    if not isinstance(changes, dict):
        raise ValueError("Cài đặt không hợp lệ")
    s = get_settings()
    for k, v in changes.items():
        if k == "auto":
            s["auto"] = bool(v)
        elif k == "keep":
            v = int(v)
            if not 1 <= v <= 100:
                raise ValueError("Số bản giữ lại phải từ 1 đến 100")
            s["keep"] = v
        elif k == "max_mb":
            v = int(v)
            if not 1 <= v <= 1024 * 1024:
                raise ValueError("Giới hạn dung lượng không hợp lệ")
            s["max_mb"] = v
        elif k == "exit_delay":
            v = int(v)
            if not 0 <= v <= 120:
                raise ValueError("Thời gian chờ phải từ 0 đến 120 giây")
            s["exit_delay"] = v
        elif k == "dest":
            v = os.path.abspath(os.path.expanduser(str(v).strip())) if str(v).strip() else _default_dest()
            if not _allowed_dest(v):
                raise ValueError("Chỉ được lưu trong thư mục home hoặc thẻ nhớ/ổ ngoài (/run/media, /media, /mnt)")
            if os.path.exists(v) and not os.path.isdir(v):
                raise ValueError("Đường dẫn không phải thư mục")
            _makedirs(v)
            s["dest"] = v
        else:
            raise ValueError(f"Không có cài đặt {k}")
    _write_json(os.path.join(_settings_dir(), SETTINGS_FILE), s)
    return s


# ------------------------------------------------------------------ Steam ---
def steam_roots() -> list:
    out, seen = [], set()
    for p in (".local/share/Steam", ".steam/steam", ".steam/root"):
        full = os.path.join(_home(), p)
        if os.path.isdir(os.path.join(full, "steamapps")) or os.path.isdir(os.path.join(full, "userdata")):
            real = os.path.realpath(full)
            if real not in seen:
                seen.add(real)
                out.append(full)
    return out


def steam_libraries() -> list:
    """Các thư mục steamapps của mọi thư viện (đọc libraryfolders.vdf)."""
    libs, seen = [], set()

    def add(p):
        real = os.path.realpath(p)
        if os.path.isdir(p) and real not in seen:
            seen.add(real)
            libs.append(p)

    for root in steam_roots():
        sa = os.path.join(root, "steamapps")
        add(sa)
        try:
            with open(os.path.join(sa, "libraryfolders.vdf"), encoding="utf-8", errors="replace") as f:
                text = f.read()
        except OSError:
            continue
        for m in re.finditer(r'"path"\s+"((?:[^"\\]|\\.)*)"', text):
            add(os.path.join(m.group(1).replace("\\\\", "\\"), "steamapps"))
    return libs


def find_prefix_users(appid: str):
    """drive_c/users của prefix Proton theo appid, hoặc None."""
    for lib in steam_libraries():
        users = os.path.join(lib, "compatdata", str(appid), "pfx", "drive_c", "users")
        if os.path.isdir(users):
            return users
    return None


def steam_game_name(appid: str):
    for lib in steam_libraries():
        try:
            with open(os.path.join(lib, f"appmanifest_{appid}.acf"), encoding="utf-8", errors="replace") as f:
                m = re.search(r'"name"\s+"([^"]*)"', f.read())
                if m:
                    return m.group(1)
        except OSError:
            pass
    return None


def steam_installed_games() -> list:
    """Game Steam đã cài có prefix Proton (để hiện trong danh sách backup ngay)."""
    out, seen = [], set()
    skip = re.compile(r"^(Proton|Steam Linux Runtime|Steamworks Common|SteamVR|Steam Audio)", re.I)
    for lib in steam_libraries():
        try:
            names = os.listdir(lib)
        except OSError:
            continue
        for n in names:
            m = re.match(r"^appmanifest_(\d+)\.acf$", n)
            if not m or m.group(1) in seen:
                continue
            appid = m.group(1)
            name = steam_game_name(appid) or appid
            if skip.match(name) or not find_prefix_users(appid):
                continue
            seen.add(appid)
            out.append({"key": f"steam-{appid}", "name": name, "kind": "steam"})
    return out


def proton_roots(users: str) -> dict:
    return {label: os.path.join(users, rel) for label, rel in PROTON_ROOTS}


# -------------------------------------------------------- shortcuts.vdf ---
def _parse_binary_vdf(data: bytes):
    """Đọc VDF nhị phân (shortcuts.vdf). Trả về dict lồng nhau."""
    pos = 0

    def read_str():
        nonlocal pos
        end = data.index(b"\x00", pos)
        s = data[pos:end].decode("utf-8", errors="replace")
        pos = end + 1
        return s

    def read_map():
        nonlocal pos
        out = {}
        while pos < len(data):
            t = data[pos]
            pos += 1
            if t == 0x08:
                return out
            name = read_str()
            if t == 0x00:
                out[name] = read_map()
            elif t == 0x01:
                out[name] = read_str()
            elif t == 0x02:
                out[name] = struct.unpack_from("<i", data, pos)[0]
                pos += 4
            elif t == 0x03:
                out[name] = struct.unpack_from("<f", data, pos)[0]
                pos += 4
            elif t == 0x07:
                out[name] = struct.unpack_from("<Q", data, pos)[0]
                pos += 8
            else:
                raise ValueError(f"Kiểu VDF lạ {t}")
        return out

    return read_map()


def _get_ci(d: dict, *names):
    low = {k.lower(): v for k, v in d.items()}
    for n in names:
        if n.lower() in low:
            return low[n.lower()]
    return None


def read_shortcuts() -> list:
    """Mọi shortcut Non-Steam của mọi tài khoản: appid (unsigned), name, exe, startdir, options."""
    out, seen = [], set()
    for root in steam_roots():
        base = os.path.join(root, "userdata")
        try:
            users = os.listdir(base)
        except OSError:
            continue
        for u in users:
            p = os.path.join(base, u, "config", "shortcuts.vdf")
            try:
                with open(p, "rb") as f:
                    tree = _parse_binary_vdf(f.read())
            except (OSError, ValueError, struct.error, IndexError):
                continue
            items = _get_ci(tree, "shortcuts") or {}
            for sc in items.values():
                if not isinstance(sc, dict):
                    continue
                appid = _get_ci(sc, "appid")
                if not isinstance(appid, int):
                    continue
                appid &= 0xFFFFFFFF
                if appid in seen:
                    continue
                seen.add(appid)
                out.append({
                    "appid": str(appid),
                    "name": str(_get_ci(sc, "AppName", "appname") or ""),
                    "exe": str(_get_ci(sc, "Exe", "exe") or "").strip(),
                    "startdir": str(_get_ci(sc, "StartDir", "startdir") or "").strip(),
                    "options": str(_get_ci(sc, "LaunchOptions", "launchoptions") or ""),
                })
    return out


def find_shortcut(appid: str):
    for sc in read_shortcuts():
        if sc["appid"] == str(appid):
            return sc
    return None


# ---------------------------------------------------------------- port ---
def ports_dir() -> str:
    return os.path.join(_home(), "Games", "Ports")


def installed_ports() -> list:
    try:
        names = sorted(os.listdir(ports_dir()))
    except OSError:
        return []
    return [n for n in names if PORT_ID_RE.match(n) and os.path.isdir(os.path.join(ports_dir(), n))]


def port_roots(pid: str) -> dict:
    roots = {"install": os.path.join(ports_dir(), pid)}
    extra = list(PORT_EXTRA.get(pid, []))
    if pid in HARBOURMASTERS:
        extra.append(f".local/share/{pid}")
    for i, rel in enumerate(extra):
        roots["data" if i == 0 else f"data{i + 1}"] = os.path.join(_home(), rel)
    return roots


def _port_name(pid: str) -> str:
    st = _read_json(os.path.join(_settings_dir(), "ports.json"), {}) or {}
    info = (st.get("installed") or st.get("ports") or {}).get(pid) if isinstance(st, dict) else None
    if isinstance(info, dict) and info.get("name"):
        return str(info["name"])
    return pid


# ------------------------------------------------------------- giả lập ---
def emulation_paths() -> list:
    """Thư mục Emulation của EmuDeck: emulationPath trong settings.sh, rồi ~/Emulation, rồi thẻ SD."""
    out = []
    try:
        with open(os.path.join(_home(), ".config/EmuDeck/settings.sh"), encoding="utf-8", errors="replace") as f:
            for line in f:
                m = re.match(r'^\s*(?:export\s+)?emulationPath\s*=\s*["\']?([^"\'\n#]+?)["\']?\s*$', line)
                if m:
                    out.append(os.path.expanduser(m.group(1).strip().rstrip("/")))
    except OSError:
        pass
    out.append(os.path.join(_home(), "Emulation"))
    for media in ("/run/media", "/run/media/" + os.path.basename(_home())):
        try:
            for d in sorted(os.listdir(media)):
                out.append(os.path.join(media, d, "Emulation"))
        except OSError:
            pass
    res, seen = [], set()
    for p in out:
        if os.path.isdir(os.path.join(p, "saves")):
            real = os.path.realpath(p)
            if real not in seen:
                seen.add(real)
                res.append(p)
    return res


def emu_saves_dirs() -> dict:
    """tên thư mục (chữ thường) -> đường dẫn, trong mọi Emulation/saves."""
    out = {}
    for em in emulation_paths():
        saves = os.path.join(em, "saves")
        try:
            names = sorted(os.listdir(saves))
        except OSError:
            continue
        for n in names:
            p = os.path.join(saves, n)
            key = n.lower()
            if os.path.isdir(p) and re.match(r"^[a-z0-9][a-z0-9_.-]{0,63}$", key) and key not in out:
                out[key] = p
    return out


def emu_roots(name: str) -> dict:
    """Mỗi thư mục con của saves/<tên> là một gốc (đã phân giải symlink của EmuDeck).
    File nằm thẳng trong saves/<tên> đi theo nhãn `_top` (không đệ quy)."""
    base = emu_saves_dirs().get(name)
    if not base:
        return {}
    roots = {"_top": os.path.realpath(base)}
    try:
        names = sorted(os.listdir(base))
    except OSError:
        return roots
    for n in names:
        p = os.path.join(base, n)
        if os.path.isdir(p) and LABEL_RE.match(n) and n != "_top":
            roots[n] = os.path.realpath(p)
    return roots


def detect_emulators(text: str) -> list:
    """Nhận giả lập từ exe + launch options. Trả về danh sách thư mục save có thật."""
    low = text.lower()
    saves = emu_saves_dirs()
    if not low.strip():
        return []
    found = []
    for canon, kws in EMULATORS.items():
        if any(re.search(r"(?<![a-z0-9])" + re.escape(k) + r"(?![a-z])", low) for k in kws):
            for alias in [canon] + kws:
                if alias in saves and alias not in found:
                    found.append(alias)
            if not any(a in saves for a in [canon] + kws) and canon not in found:
                found.append(canon)  # chưa có thư mục save: báo là trống
    return found


def classify_shortcut(sc: dict) -> dict:
    """port / emu / emu_all / ns (Proton) / unsupported."""
    exe = sc.get("exe", "").strip('"')
    start = sc.get("startdir", "").strip('"')
    pdir = ports_dir()
    for p in (exe, start):
        if p and _within(p, pdir) and os.path.realpath(p) != os.path.realpath(pdir):
            rel = os.path.relpath(os.path.realpath(p), os.path.realpath(pdir)).split(os.sep)[0]
            if PORT_ID_RE.match(rel):
                return {"kind": "port", "id": rel}
    # Chỉ xét tên file chạy + launch options (không xét cả đường dẫn, tránh nhận nhầm theo tên thư mục).
    text = f"{os.path.basename(exe)} {sc.get('options', '')}"
    emus = detect_emulators(text)
    if emus:
        return {"kind": "emu", "names": emus}
    low = text.lower() + " " + start.lower()
    if any(f in low for f in FRONTENDS):
        return {"kind": "emu_all"}
    for em in emulation_paths():
        if any(p and _within(p, em) for p in (exe, start)):
            return {"kind": "emu_all"}
    if find_prefix_users(sc["appid"]):
        return {"kind": "ns"}
    return {"kind": "unsupported"}


# --------------------------------------------------------- nguồn & gốc ---
def source_for_key(key: str) -> dict:
    if not KEY_RE.match(key or ""):
        raise ValueError("Mã backup không hợp lệ")
    kind, ident = key.split("-", 1)
    if kind == "steam":
        return {"kind": "steam", "appid": ident}
    if kind == "ns":
        sc = find_shortcut(ident) or {}
        return {"kind": "ns", "appid": ident, "exe": sc.get("exe", ""), "startdir": sc.get("startdir", "")}
    if kind == "port":
        return {"kind": "port", "id": ident}
    return {"kind": "emu", "name": ident}


def resolve_roots(src: dict) -> dict:
    """Nhãn -> đường dẫn theo trạng thái hiện tại của máy (có thể chưa tồn tại)."""
    kind = src.get("kind")
    if kind in ("steam", "ns"):
        users = find_prefix_users(src["appid"])
        return proton_roots(users) if users else {}
    if kind == "port":
        return port_roots(src["id"])
    if kind == "emu":
        return emu_roots(src["name"])
    return {}


def _skip_dir(kind: str, name: str) -> bool:
    low = name.lower()
    if kind in ("steam", "ns"):
        return low in PROTON_JUNK_DIRS
    if kind == "port":
        return low in PORT_SKIP_DIRS or low.startswith(".work-")
    return False


def _is_elf_exec(path: str, st) -> bool:
    if not st.st_mode & 0o111:
        return False
    try:
        with open(path, "rb") as f:
            return f.read(4) == b"\x7fELF"
    except OSError:
        return False


def _skip_file(kind: str, path: str, st) -> bool:
    ext = os.path.splitext(path)[1].lower()
    if kind in ("steam", "ns"):
        return ext in PROTON_JUNK_EXT
    if kind == "port":
        return ext in PORT_SKIP_EXT or _is_elf_exec(path, st)
    return False


def collect_files(kind: str, roots: dict) -> list:
    """[(arcname, đường dẫn, stat)] - không theo symlink, bỏ rác theo loại nguồn."""
    out = []
    for label, root in sorted(roots.items()):
        if not LABEL_RE.match(label) or not os.path.isdir(root):
            continue
        if label == "_top":  # chỉ file nằm thẳng trong thư mục
            try:
                for n in sorted(os.listdir(root)):
                    p = os.path.join(root, n)
                    st = os.lstat(p)
                    if stat.S_ISREG(st.st_mode):
                        out.append((f"{label}/{n}", p, st))
            except OSError:
                pass
            continue
        for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
            dirnames[:] = sorted(d for d in dirnames
                                 if not _skip_dir(kind, d) and not os.path.islink(os.path.join(dirpath, d)))
            for n in sorted(filenames):
                p = os.path.join(dirpath, n)
                try:
                    st = os.lstat(p)
                except OSError:
                    continue
                if not stat.S_ISREG(st.st_mode) or _skip_file(kind, p, st):
                    continue
                rel = os.path.relpath(p, root).replace(os.sep, "/")
                out.append((f"{label}/{rel}", p, st))
    return out


def fingerprint(files: list) -> str:
    h = hashlib.sha1()
    for arc, _p, st in files:
        h.update(f"{arc}\0{st.st_size}\0{st.st_mtime_ns}\n".encode("utf-8", "surrogateescape"))
    return h.hexdigest()


# ---------------------------------------------------------- lưu trữ ---
def _key_dir(dest: str, key: str) -> str:
    if not KEY_RE.match(key or ""):
        raise ValueError("Mã backup không hợp lệ")
    return os.path.join(dest, key)


def _load_info(dest: str, key: str) -> dict:
    info = _read_json(os.path.join(_key_dir(dest, key), INFO_FILE), None)
    if not isinstance(info, dict):
        info = {}
    info.setdefault("snapshots", [])
    info.setdefault("roots", {})
    return info


def _new_name(kdir: str) -> str:
    base = time.strftime("%Y%m%d-%H%M%S")
    name, i = f"{base}.tar.gz", 1
    while os.path.exists(os.path.join(kdir, name)):
        name = f"{base}-{i}.tar.gz"
        i += 1
    return name


def _display_name(key: str, src: dict, hint: str = "") -> str:
    kind = src.get("kind")
    if hint:
        return hint
    if kind == "steam":
        return steam_game_name(src["appid"]) or f"Steam {src['appid']}"
    if kind == "ns":
        sc = find_shortcut(src["appid"])
        return (sc or {}).get("name") or f"Non-Steam {src['appid']}"
    if kind == "port":
        return _port_name(src["id"])
    if kind == "emu":
        return f"Giả lập: {src['name']}"
    return key


def backup_key(key: str, reason: str = "manual", name: str = "", protect: str = "") -> dict:
    """Backup một mục. Trả về {key, name, status, ...}.
    status: ok | unchanged | empty | too_big | unsupported."""
    with _LOCK:
        s = get_settings()
        src = source_for_key(key)
        roots = {k: v for k, v in resolve_roots(src).items() if os.path.isdir(v)}
        dest = s["dest"]
        kdir = _key_dir(dest, key)
        info = _load_info(dest, key)
        disp = info.get("name") if (not name and info.get("name")) else _display_name(key, src, name)
        res = {"key": key, "name": disp}
        if not roots:
            return {**res, "status": "unsupported" if src["kind"] in ("steam", "ns") else "empty"}
        files = collect_files(src["kind"], roots)
        if not files:
            return {**res, "status": "empty"}
        raw = sum(st.st_size for _a, _p, st in files)
        if raw > int(s["max_mb"]) * 1024 * 1024:
            return {**res, "status": "too_big", "raw_size": raw}
        fp = fingerprint(files)
        snaps = info["snapshots"]
        if snaps and snaps[-1].get("fingerprint") == fp and os.path.exists(os.path.join(kdir, snaps[-1]["file"])):
            return {**res, "status": "unchanged", "file": snaps[-1]["file"]}

        _makedirs(kdir, dest)
        fname = _new_name(kdir)
        final = os.path.join(kdir, fname)
        part = final + ".part"
        count = 0
        try:
            with tarfile.open(part, "w:gz", compresslevel=6) as tar:
                for arc, p, st in files:
                    # Chép ra bộ đệm trước, để file đổi kích thước giữa chừng không làm hỏng tar.
                    try:
                        buf = tempfile.SpooledTemporaryFile(max_size=32 * 1024 * 1024)
                        with open(p, "rb") as f:
                            shutil.copyfileobj(f, buf)
                    except OSError:
                        continue  # file bị xóa giữa chừng
                    with buf:
                        ti = tarfile.TarInfo(arc)
                        ti.size = buf.tell()
                        ti.mtime = st.st_mtime
                        ti.mode = stat.S_IMODE(st.st_mode)
                        buf.seek(0)
                        tar.addfile(ti, buf)
                        count += 1
            os.replace(part, final)
        finally:
            if os.path.exists(part):
                os.remove(part)
        _chown(final)
        size = os.path.getsize(final)
        snaps.append({"file": fname, "time": int(time.time()), "size": size, "raw_size": raw,
                      "files": count, "fingerprint": fp, "reason": reason})
        info.update({"name": disp, "kind": src["kind"], "source": src, "roots": roots})
        # Giữ `keep` bản mới nhất, không xóa bản đang được khôi phục.
        keep = int(s["keep"])
        removable = [x for x in snaps[:-1] if x["file"] != protect]
        while len(snaps) > keep and removable:
            old = removable.pop(0)
            snaps.remove(old)
            try:
                os.remove(os.path.join(kdir, old["file"]))
            except OSError:
                pass
        _write_json(os.path.join(kdir, INFO_FILE), info)
        decky.logger.info(f"Save backup {key} ({reason}): {count} file, {size} byte")
        return {**res, "status": "ok", "file": fname, "size": size, "files": count}


def backup_emulators(reason: str = "manual", names=None) -> list:
    saves = emu_saves_dirs()
    targets = names if names is not None else list(saves)
    out = []
    for n in targets:
        if n not in saves:
            out.append({"key": f"emu-{n}", "name": f"Giả lập: {n}", "status": "empty"})
            continue
        out.append(backup_key(f"emu-{n}", reason))
    return out


def on_game_exit(appid: str, name: str = "", is_shortcut: bool = False) -> dict:
    s = get_settings()
    if not s["auto"]:
        return {"status": "disabled", "results": []}
    appid = str(appid)
    if not re.match(r"^\d{1,10}$", appid):
        raise ValueError("appid không hợp lệ")
    if not is_shortcut:
        r = backup_key(f"steam-{appid}", "exit", name)
        return {"status": "done", "results": [r]}
    sc = find_shortcut(appid)
    if not sc:
        return {"status": "done", "results": [{"key": f"ns-{appid}", "name": name, "status": "unsupported"}]}
    c = classify_shortcut(sc)
    if c["kind"] == "port":
        res = [backup_key(f"port-{c['id']}", "exit", name or sc["name"])]
    elif c["kind"] == "emu":
        res = backup_emulators("exit", c["names"])
    elif c["kind"] == "emu_all":
        res = backup_emulators("exit")
    elif c["kind"] == "ns":
        res = [backup_key(f"ns-{appid}", "exit", name or sc["name"])]
    else:
        res = [{"key": f"ns-{appid}", "name": name or sc["name"], "status": "unsupported"}]
    return {"status": "done", "results": res}


# ------------------------------------------------------------ danh sách ---
def list_all() -> dict:
    s = get_settings()
    dest = s["dest"]
    entries, keys = [], set()
    try:
        names = sorted(os.listdir(dest))
    except OSError:
        names = []
    for k in names:
        if not KEY_RE.match(k):
            continue
        info = _load_info(dest, k)
        snaps = [x for x in info["snapshots"] if os.path.exists(os.path.join(dest, k, x.get("file", "")))]
        if not snaps:
            continue
        keys.add(k)
        entries.append({"key": k, "name": info.get("name") or k, "kind": info.get("kind") or k.split("-")[0],
                        "snapshots": list(reversed(snaps))})
    entries.sort(key=lambda e: -e["snapshots"][0]["time"])

    cands = []
    for g in steam_installed_games():
        if g["key"] not in keys:
            cands.append(g)
    for sc in read_shortcuts():
        c = classify_shortcut(sc)
        if c["kind"] == "ns" and f"ns-{sc['appid']}" not in keys:
            cands.append({"key": f"ns-{sc['appid']}", "name": sc["name"] or sc["appid"], "kind": "ns"})
    for pid in installed_ports():
        if f"port-{pid}" not in keys:
            cands.append({"key": f"port-{pid}", "name": _port_name(pid), "kind": "port"})
    for n in emu_saves_dirs():
        if f"emu-{n}" not in keys:
            cands.append({"key": f"emu-{n}", "name": f"Giả lập: {n}", "kind": "emu"})
    cands.sort(key=lambda c: c["name"].lower())
    total = sum(x.get("size", 0) for e in entries for x in e["snapshots"])
    return {"settings": s, "entries": entries, "candidates": cands, "total_size": total,
            "has_emulation": bool(emulation_paths())}


# ------------------------------------------------------------- khôi phục ---
def _check_file(dest: str, key: str, file: str) -> str:
    if not FILE_RE.match(file or ""):
        raise ValueError("Tên bản backup không hợp lệ")
    p = os.path.join(_key_dir(dest, key), file)
    if not os.path.isfile(p):
        raise ValueError("Không tìm thấy bản backup")
    return p


def _safe_parts(name: str):
    if name.startswith("/") or "\\" in name:
        return None
    parts = [x for x in name.split("/") if x not in ("", ".")]
    if len(parts) < 2 or any(x == ".." for x in parts):
        return None
    return parts


def restore(key: str, file: str) -> dict:
    with _LOCK:
        s = get_settings()
        dest = s["dest"]
        arch = _check_file(dest, key, file)
        info = _load_info(dest, key)
        src = source_for_key(key)
        roots = resolve_roots(src)
        stored = info.get("roots") or {}
        for label, p in stored.items():  # dự phòng: nhãn không còn theo nguồn hiện tại
            if label not in roots and isinstance(p, str) and LABEL_RE.match(label):
                if src["kind"] in ("steam", "ns") and roots:
                    continue  # prefix hiện tại có rồi, không ghi vào prefix cũ
                roots[label] = p
        if not roots:
            raise ValueError("Không tìm thấy thư mục save của game này. Hãy chạy game một lần rồi thử lại.")

        before = backup_key(key, "before_restore", protect=file)

        written, skipped = 0, []
        with tarfile.open(arch, "r:gz") as tar:
            for m in tar:
                parts = _safe_parts(m.name)
                if parts is None or parts[0] not in roots:
                    skipped.append(m.name)
                    continue
                if not m.isfile():
                    continue
                root = roots[parts[0]]
                if parts[0] == "_top" and len(parts) != 2:
                    skipped.append(m.name)
                    continue
                target = os.path.join(root, *parts[1:])
                parent = os.path.dirname(target)
                if not _within(parent, root) or os.path.islink(target) or (
                        os.path.exists(target) and not os.path.isfile(target)):
                    skipped.append(m.name)
                    continue
                if not os.path.isdir(root):
                    _makedirs(root)
                _makedirs(parent, root)
                if not _within(parent, root):  # kiểm tra lại sau khi tạo
                    skipped.append(m.name)
                    continue
                f = tar.extractfile(m)
                if f is None:
                    continue
                fd, tmp = tempfile.mkstemp(dir=parent, prefix=".sbrestore-")
                try:
                    with os.fdopen(fd, "wb") as out:
                        shutil.copyfileobj(f, out)
                    os.chmod(tmp, (m.mode & 0o777) or 0o644)
                    os.utime(tmp, (m.mtime, m.mtime))
                    os.replace(tmp, target)
                finally:
                    if os.path.exists(tmp):
                        os.remove(tmp)
                _chown(target)
                written += 1
        decky.logger.info(f"Save restore {key} <- {file}: {written} file, bỏ qua {len(skipped)}")
        return {"key": key, "file": file, "written": written, "skipped": skipped[:20],
                "before": before.get("file") if before.get("status") in ("ok", "unchanged") else None}


def delete(key: str, file: str) -> dict:
    with _LOCK:
        dest = get_settings()["dest"]
        p = _check_file(dest, key, file)
        os.remove(p)
        kdir = _key_dir(dest, key)
        info = _load_info(dest, key)
        info["snapshots"] = [x for x in info["snapshots"] if x.get("file") != file]
        if info["snapshots"]:
            _write_json(os.path.join(kdir, INFO_FILE), info)
        else:
            shutil.rmtree(kdir, ignore_errors=True)
        return {"key": key, "file": file, "left": len(info["snapshots"])}


# ------------------------------------------------- chuyển cài đặt cũ ---
# Cài đặt của bản plugin chạy riêng "Backup Save by Weirdstore.vn" (thư mục backup dùng chung).
OLD_SETTINGS_DIRS = ("Backup Save by Weirdstore.vn", "save-backup")


def migrate_old_settings() -> bool:
    own = os.path.join(_settings_dir(), SETTINGS_FILE)
    if os.path.exists(own):
        return False
    parent = os.path.dirname(os.path.abspath(_settings_dir()))
    for name in OLD_SETTINGS_DIRS:
        data = _read_json(os.path.join(parent, name, SETTINGS_FILE), None)
        if isinstance(data, dict):
            _write_json(own, {k: data[k] for k in DEFAULTS if k in data})
            decky.logger.info(f"Save: đã chuyển cài đặt từ {name}")
            return True
    return False


# ---------------------------------------------------------------- plugin ---
async def _sb_safe(fn, *args):
    try:
        return {"ok": True, "data": await asyncio.to_thread(fn, *args)}
    except Exception as e:  # noqa: BLE001
        decky.logger.exception("Save Backup error")
        return {"ok": False, "error": str(e)}


class SaveBackupMixin:
    async def _sb_main(self):
        try:
            await asyncio.to_thread(migrate_old_settings)
            await asyncio.to_thread(lambda: _makedirs(get_settings()["dest"]))
        except Exception:  # noqa: BLE001
            decky.logger.exception("Save: lỗi khi khởi động")

    async def sb_get_settings(self):
        return await _sb_safe(get_settings)

    async def sb_set_settings(self, changes: dict):
        return await _sb_safe(set_settings, changes)

    async def sb_list(self):
        return await _sb_safe(list_all)

    async def sb_on_game_exit(self, appid: str, name: str = "", is_shortcut: bool = False):
        try:
            delay = int(get_settings().get("exit_delay", 5))
        except Exception:  # noqa: BLE001
            delay = 5
        if delay > 0:
            await asyncio.sleep(delay)  # chờ game ghi xong save
        return await _sb_safe(on_game_exit, appid, name, is_shortcut)

    async def sb_backup_now(self, key: str):
        return await _sb_safe(backup_key, key, "manual")

    async def sb_backup_emulators(self):
        return await _sb_safe(backup_emulators, "manual")

    async def sb_restore(self, key: str, file: str):
        return await _sb_safe(restore, key, file)

    async def sb_delete(self, key: str, file: str):
        return await _sb_safe(delete, key, file)
